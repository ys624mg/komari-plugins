// Komari 资源监控报警插件
// 功能：定时检测所有节点 CPU 使用率、系统负载(load1/5/15)、TCP/UDP 连接数，
//       超过阈值时通过 Komari 自带通知渠道(admin:sendNotification)或自定义 Webhook 报警；
//       另支持「IP 被墙检测」：引用 Komari 自带延迟监测任务的 ping 数据，
//       选中任务持续超时达到设定时长即判定被墙并通知，恢复后发送恢复消息。
// 所有阈值参数在插件配置中调整，保存后插件会自动 reload 生效。
//
// v1.12.0 逻辑与代码优化：
//   1. runCheck / refreshValues 统一走 collectSnapshot()，两条路径采集与状态合并逻辑一致
//   2. 节点列表(10s)与最近记录(4s)带 TTL 缓存，记录拉取并发化(池 6)，多节点巡检更快
//   3. runCheck 增加 running 哨兵：慢巡检不会与下一轮重叠，杜绝重复报警
//   4. 巡检失败保留上一次节点快照(表格不再被清空)，错误信息单独展示
//   5. STATE.firing 按存活指标自动清理，节点删除/关闭检测后不再残留状态
//   6. 持续确认模式增加数据中断检测：缺口超过 max(2×持续时长, 3×巡检间隔) 重新计时，
//      避免节点长时间离网后一次采样就误报
//   7. 通知投递 Komari / Webhook 双通道并行(allSettled)，单通道失败互不影响
//   8. Webhook 请求增加 10s 超时(AbortController)，不再无限挂起
//   9. 单节点记录拉取失败按「保持旧值 + 跳过本轮评估」处理，不再误判离线

const server = require("server");
const ipb = require("./lib/ip-block.js");

/* ---------- 常量 ---------- */

// 指标 -> 报警文案中的中文名
const METRIC_LABELS = {
  cpu: "CPU",
  load: "负载",
  connections: "TCP连接数",
  connections_udp: "UDP连接数",
  connections_merge: "总连接数(TCP+UDP)",
};

const NODES_TTL_MS = 10000;  // 节点列表缓存时长
const RECENT_TTL_MS = 4000;  // 最近记录缓存时长(状态页高频刷新不重复打库)
const FETCH_POOL = 6;        // 记录/指标查询并发池大小
const WEBHOOK_TIMEOUT_MS = 10000;

// metric -> 快照中的状态字段名(兼容既有前端字段)
const METRIC_STATE_FIELD = {
  cpu: "cpuState",
  load: "loadState",
  connections: "connState",
  connections_udp: "udpState",
  connections_merge: "totalState",
};

const STATE = {
  config: null,      // 合并后的配置
  clients: [],       // [{uuid, name}]
  clientMap: {},     // uuid -> {uuid, name}(精简对象，避免向通知泄露 token 等字段)
  firing: {},        // key = "uuid:metric" -> {ok, since, lastSent, value, firstAbove, lastSeen}
  lastCheck: null,   // 最近一次巡检时间(ISO)
  lastError: "",
  node: [],          // 供状态页展示的节点快照
  valuesAt: null,    // 快照数值采集时间(ISO)
  notifyLog: [],     // 通知投递日志 [{time, channel, title, ok, error/status}]
  ipBlock: {         // IP 被墙检测状态(基于延迟监测任务 ping 数据)
    targets: [],     // 任务展示列表(含各监测线明细)
    states: {},      // taskId -> 状态机状态
    lastCheck: null,
    lastError: "",
    running: false,
  },
};

/* ---------- 工具函数 ---------- */

function toNum(v, def) {
  const n = Number(v);
  return isFinite(n) ? n : def;
}

function toBool(v, def) {
  return v === undefined || v === null ? def : !!v;
}

function fmt(v) {
  if (v === null || v === undefined || v === "") return "-";
  return Math.round(v * 100) / 100;
}

// 读取 cpu 使用率(百分比)：兼容 Record 扁平字段和 WebSocket 嵌套结构
function getCpu(rec) {
  if (rec === null || typeof rec !== "object") return null;
  if (typeof rec.cpu === "number") return rec.cpu;
  if (rec.cpu && typeof rec.cpu === "object" && typeof rec.cpu.usage === "number") {
    return rec.cpu.usage;
  }
  return null;
}

// 读取负载：rec.load 可能是数字(load1)或 {load1,load5,load15}
// 负载窗口说明：
//   load1  = 最近 1 分钟平均负载(抓突发尖峰，反应快，但瞬时波动容易误报)
//   load5  = 最近 5 分钟平均负载(折中，过滤短暂毛刺，插件默认)
//   load15 = 最近 15 分钟平均负载(最平滑，只反映持续性高负载)
// 判断标准：负载 ≈ CPU 核心数为刚好满载，持续高于核心数说明任务在排队、CPU 不够用
function getLoad(rec, win) {
  if (rec === null || typeof rec !== "object") return null;
  const w = win || "load5";
  if (rec.load !== undefined && rec.load !== null && typeof rec.load === "object") {
    const v = rec.load[w];
    if (v !== undefined && v !== null) return toNum(v, null);
    // 回退到 load1
    if (rec.load.load1 !== undefined) return toNum(rec.load.load1, null);
    return null;
  }
  if (typeof rec.load === "number") return rec.load;
  return null;
}

// 读取 TCP 连接数：rec.connections 数字或 {tcp, udp}
function getConnections(rec) {
  if (rec === null || typeof rec !== "object") return null;
  if (rec.connections !== undefined && rec.connections !== null && typeof rec.connections === "object") {
    if (typeof rec.connections.tcp === "number") return rec.connections.tcp;
    return null;
  }
  if (typeof rec.connections === "number") return rec.connections;
  return null;
}

// 读取 UDP 连接数：rec.connections.udp 嵌套或 rec.connections_udp 扁平字段
function getUdp(rec) {
  if (rec === null || typeof rec !== "object") return null;
  if (rec.connections !== undefined && rec.connections !== null && typeof rec.connections === "object") {
    if (typeof rec.connections.udp === "number") return rec.connections.udp;
  }
  if (typeof rec.connections_udp === "number") return rec.connections_udp;
  return null;
}

// 解析自定义负载阈值映射："节点名=8,节点B=2"(支持中英文逗号/分号、等号/冒号)
function parseCustomMap(text) {
  const map = {};
  if (!text || typeof text !== "string") return map;
  const parts = text.split(/[,，;；]/);
  for (const part of parts) {
    const seg = part.trim();
    if (!seg) continue;
    const m = seg.match(/^(.+?)[=:：]\s*(\d+(?:\.\d+)?)$/);
    if (m) {
      map[m[1].trim()] = Number(m[2]);
    }
  }
  return map;
}

// 计算某节点的有效负载阈值，优先级：自定义覆盖 > 自动按核心数(水位%) > 固定值
function effectiveLoadThreshold(client, cfg, customMap) {
  // 1) 单节点自定义覆盖
  if (customMap && customMap[client.name] !== undefined) {
    return customMap[client.name];
  }
  // 2) 自动按核心数：阈值 = 逻辑核心数 × 水位% ÷ 100
  //    水位 100 = 满载即报警；130 = 过载 30% 才报警；30 = 负载到满载 30% 就报警(灵敏预警)
  if (toBool(cfg.load_auto_enabled, true) && client.cores > 0) {
    return client.cores * toNum(cfg.load_pct, 100) / 100;
  }
  // 3) 固定阈值(核心数未知或关闭自动模式)
  return toNum(cfg.load_threshold, 4);
}

// 从最近记录数组中取最新一条
function latestRecord(records) {
  if (!Array.isArray(records) || records.length === 0) return null;
  return records[records.length - 1];
}

/* ---------- 并发池 ---------- */

// 简易并发池：最多 limit 个任务并行，单个任务失败不影响其他任务
async function pool(items, limit, fn) {
  const n = Math.max(1, Math.min(limit, items.length));
  let idx = 0;
  const workers = [];
  for (let i = 0; i < n; i++) {
    workers.push((async () => {
      while (idx < items.length) {
        const cur = idx++;
        await fn(items[cur], cur);
      }
    })());
  }
  await Promise.all(workers);
}

/* ---------- 数据获取(带缓存) ---------- */

// 节点列表缓存：10s TTL + 在途请求合并，避免巡检/状态页/IP检测重复拉取
const nodesCache = { at: 0, list: null, inflight: null };

async function fetchClientsRaw() {
  // 优先 admin 视角(包含 hidden 节点)；失败则回退到公开接口
  let list;
  try {
    list = await server.call("admin:listClients");
  } catch (e) {
    list = await server.call("public:getNodesInformation");
  }
  if (!Array.isArray(list)) {
    // 兼容 data 包装
    if (list && Array.isArray(list.data)) list = list.data;
  }
  const out = [];
  const map = {};
  for (const c of Array.isArray(list) ? list : []) {
    if (c && c.uuid) {
      // cores = 逻辑核心数，用于负载阈值自动适配；weight = 面板拖拽排序权重
      const item = {
        uuid: c.uuid,
        name: c.name || c.uuid,
        cores: toNum(c.cpu_cores, 0),
        weight: toNum(c.weight, 0),
        ipv4: c.ipv4 || c.ip || c.server || c.host || "",
        ipv6: c.ipv6 || "",
      };
      out.push(item);
      map[c.uuid] = item;
    }
  }
  // 与管理面板节点列表排序保持一致：按 weight 升序(面板拖拽后 weight 即为 0,1,2...)
  // 同 weight 时按接口原始顺序，保证确定性
  for (let i = 0; i < out.length; i++) out[i]._idx = i;
  out.sort(function (a, b) { return (a.weight - b.weight) || (a._idx - b._idx); });
  for (let i = 0; i < out.length; i++) delete out[i]._idx;
  STATE.clientMap = map;
  return out;
}

// force=true 跳过 TTL(巡检等权威路径使用)；并发调用共享同一次在途请求
async function getClients(force) {
  const now = Date.now();
  if (!force && nodesCache.list && now - nodesCache.at < NODES_TTL_MS) {
    return nodesCache.list;
  }
  if (nodesCache.inflight) return nodesCache.inflight;
  nodesCache.inflight = fetchClientsRaw().then(function (list) {
    nodesCache.list = list;
    nodesCache.at = Date.now();
    nodesCache.inflight = null;
    return list;
  }).catch(function (e) {
    nodesCache.inflight = null;
    throw e;
  });
  return nodesCache.inflight;
}

// 最近记录缓存：4s TTL，状态页 5s 级刷新大部分命中缓存
const recentCache = { at: 0, map: {} }; // uuid -> {rec, error}

async function fetchRecentOne(uuid) {
  const data = await server.call("public:getClientRecentRecords", { uuid: uuid });
  // 返回可能是数组，也可能是 {data: [...]}
  if (Array.isArray(data)) return data;
  if (data && Array.isArray(data.data)) return data.data;
  return [];
}

// 返回 Map(uuid -> {rec, error})；失败的节点 rec=null、error=字符串(调用方保持旧值)
// force=true(巡检路径)：本次请求的节点一律重新拉取，避免 TTL 长于巡检间隔时读到旧快照
async function getRecentMap(uuids, force) {
  const now = Date.now();
  if (force || now - recentCache.at >= RECENT_TTL_MS) {
    for (const u of uuids) delete recentCache.map[u];
    recentCache.at = now;
  }
  const missing = [];
  for (const u of uuids) {
    if (!(u in recentCache.map)) missing.push(u);
  }
  if (missing.length) {
    await pool(missing, FETCH_POOL, async function (uuid) {
      try {
        const rec = latestRecord(await fetchRecentOne(uuid));
        recentCache.map[uuid] = { rec: rec, error: null };
      } catch (e) {
        recentCache.map[uuid] = { rec: null, error: e && e.message ? e.message : String(e) };
      }
    });
  }
  const out = new Map();
  for (const u of uuids) out.set(u, recentCache.map[u] || { rec: null, error: null });
  return out;
}

// 延迟监测任务列表(缓存 60s，任务变更极少)
const pingTasksCache = { at: 0, map: null, inflight: null };

async function fetchPingTasksMap() {
  const now = Date.now();
  if (pingTasksCache.map && now - pingTasksCache.at < 60000) return pingTasksCache.map;
  if (pingTasksCache.inflight) return pingTasksCache.inflight;
  pingTasksCache.inflight = (async function () {
    // admin:getAllPingTasks(完整字段) 优先，失败回退 public:getPublicPingTasks
    let list;
    try {
      list = await server.call("admin:getAllPingTasks");
    } catch (e) {
      list = await server.call("public:getPublicPingTasks");
    }
    if (list && Array.isArray(list.data)) list = list.data;
    const map = {};
    for (const t of Array.isArray(list) ? list : []) {
      if (t && t.id !== undefined && t.id !== null) {
        map[Number(t.id)] = {
          id: Number(t.id),
          name: t.name || ("任务 " + t.id),
          target: t.target || "",
          type: t.type || "icmp",
          interval: toNum(t.interval, 60),
          clients: Array.isArray(t.clients) ? t.clients : [],
        };
      }
    }
    pingTasksCache.map = map;
    pingTasksCache.at = Date.now();
    pingTasksCache.inflight = null;
    return map;
  })().catch(function (e) {
    pingTasksCache.inflight = null;
    throw e;
  });
  return pingTasksCache.inflight;
}

/* ---------- 报警投递 ---------- */

function pushNotifyLog(entry) {
  entry.time = new Date().toISOString();
  STATE.notifyLog.unshift(entry);
  if (STATE.notifyLog.length > 30) {
    STATE.notifyLog.length = 30;
  }
}

// Komari 自带通知渠道(后台已配置的 Telegram/SMTP 等 Provider)
async function sendKomari(title, message, clients, emoji) {
  // event.clients 要求 models.Client 对象数组，不能传 uuid 字符串
  const clientObjs = [];
  for (const u of clients) {
    if (STATE.clientMap && STATE.clientMap[u]) clientObjs.push(STATE.clientMap[u]);
  }
  try {
    await server.call("admin:sendNotification", {
      event: {
        event: title,
        clients: clientObjs,
        time: new Date().toISOString(),
        message: message,
        emoji: emoji,
      },
    });
    pushNotifyLog({ channel: "komari", title: title, ok: true });
  } catch (e) {
    STATE.lastError = "komari notify failed: " + e.message;
    pushNotifyLog({ channel: "komari", title: title, ok: false, error: e.message });
  }
}

// 自定义 Webhook(POST JSON)，带 10s 超时
async function sendWebhook(title, level, message, payload) {
  const cfg = STATE.config || {};
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(function () { ctrl.abort(); }, WEBHOOK_TIMEOUT_MS);
    let res;
    try {
      res = await fetch(cfg.webhook_url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          level: level,
          title: title,
          message: message,
          node: payload.node || "",
          metric: payload.metric || "",
          value: payload.value,
          threshold: payload.threshold,
          time: new Date().toISOString(),
        }),
        signal: ctrl.signal,
      });
    } finally {
      clearTimeout(timer);
    }
    if (!res.ok) {
      STATE.lastError = "webhook status " + res.status;
      pushNotifyLog({ channel: "webhook", title: title, ok: false, error: "HTTP " + res.status });
    } else {
      pushNotifyLog({ channel: "webhook", title: title, ok: true });
    }
  } catch (e) {
    const msg = e && e.name === "AbortError" ? "timeout after " + WEBHOOK_TIMEOUT_MS + "ms" : e.message;
    STATE.lastError = "webhook failed: " + msg;
    pushNotifyLog({ channel: "webhook", title: title, ok: false, error: msg });
  }
}

// 双通道并行投递：单通道失败互不影响，也不阻塞巡检主流程
function deliver(level, title, message, payload) {
  const cfg = STATE.config || {};
  const jobs = [];
  if (toBool(cfg.use_komari_notify, true)) {
    jobs.push(sendKomari(title, message, payload.clients || [], level === "alert" ? "🚨" : "✅"));
  }
  if (cfg.webhook_url) {
    jobs.push(sendWebhook(title, level, message, payload));
  }
  if (!jobs.length) return;
  Promise.allSettled(jobs);
}

/* ---------- 单指标检测与状态机 ---------- */

// metric：cpu | load | connections(TCP) | connections_udp(UDP) | connections_merge(TCP+UDP合并)
// sustainSeconds：持续确认时长(秒)。>0 时需连续超标达到该时长才报警(按巡检周期采样)；0 表示立即报警。
// 状态机：ok ->(首次超标) pending ->(持续超标达到时长) firing ->(回落) ok
function evaluateMetric(uuid, name, metric, value, threshold, cfg, sustainSeconds) {
  if (value === null || value === undefined || !isFinite(value)) return;
  const key = uuid + ":" + metric;
  const st = STATE.firing[key] || { state: "ok", since: 0, lastSent: 0, value: 0, firstAbove: 0, lastSeen: 0 };
  const now = Date.now();
  const sustain = toNum(sustainSeconds, 0);

  // 数据中断检测：距上次采样间隔过大(节点长时间离网/指标缺失)时重置持续计时，
  // 避免一次迟到采样把「中断前」的计时续上，造成误报
  const gapLimitMs = Math.max(sustain * 2000, toNum(cfg.check_interval, 60) * 3000);
  if (st.firstAbove && st.lastSeen && now - st.lastSeen > gapLimitMs) {
    st.firstAbove = 0;
  }
  st.lastSeen = now;

  const above = value >= threshold;
  const label = METRIC_LABELS[metric] || metric;

  if (above) {
    if (st.state === "firing") {
      // 已处于报警态：按冷却时间重复提醒
      const cool = toNum(cfg.cooldown_seconds, 300) * 1000;
      if (now - st.lastSent >= cool) {
        st.lastSent = now;
        st.value = value;
        deliver(
          "alert",
          name + " " + label + " 持续过高",
          name + " " + label + " 仍为 " + fmt(value) + "，超过阈值 " + fmt(threshold) + "（持续 " + Math.round((now - st.since) / 1000) + "s）",
          { clients: [uuid], node: name, metric: metric, value: value, threshold: threshold }
        );
      }
    } else if (sustain > 0) {
      // 持续确认模式：首次超标只记录时间并进入 pending，连续超标达到 sustain 秒后才真正报警
      if (!st.firstAbove) {
        st.firstAbove = now;
        st.state = "pending";
      } else if (now - st.firstAbove >= sustain * 1000) {
        st.state = "firing";
        st.since = st.firstAbove;
        st.lastSent = now;
        st.value = value;
        st.firstAbove = 0;
        deliver(
          "alert",
          name + " " + label + " 过高",
          name + " " + label + " 达到 " + fmt(value) + "，超过阈值 " + fmt(threshold) + "（已持续超标 " + Math.round((now - st.since) / 1000) + "s）",
          { clients: [uuid], node: name, metric: metric, value: value, threshold: threshold }
        );
      } else {
        st.state = "pending";
      }
    } else {
      // 立即报警(持续确认关闭或未启用)
      st.state = "firing";
      st.since = now;
      st.lastSent = now;
      st.value = value;
      deliver(
        "alert",
        name + " " + label + " 过高",
        name + " " + label + " 达到 " + fmt(value) + "，超过阈值 " + fmt(threshold),
        { clients: [uuid], node: name, metric: metric, value: value, threshold: threshold }
      );
    }
  } else {
    // 回落到阈值以下：清空持续确认计时
    st.firstAbove = 0;
    if (st.state === "firing") {
      st.state = "ok";
      st.value = value;
      deliver(
        "recover",
        name + " " + label + " 已恢复",
        name + " " + label + " 已回落至 " + fmt(value) + "（阈值 " + fmt(threshold) + "），持续 " + Math.round((now - st.since) / 1000) + "s",
        { clients: [uuid], node: name, metric: metric, value: value, threshold: threshold }
      );
    } else if (st.state === "pending") {
      st.state = "ok";
    }
  }
  STATE.firing[key] = st;
  return st.state;
}

/* ---------- 快照采集(巡检与状态页刷新共用) ---------- */

// 计算某节点本轮应检测的指标列表(已按配置开关与数据可用性过滤)
// 持续确认(sustain)只作用于连接数检测(避免测速等瞬时尖峰误报)，CPU/负载立即报警
function collectMetrics(c, rec, cfg) {
  const cpu = rec ? getCpu(rec) : null;
  const load = rec ? getLoad(rec, cfg.load_window) : null;
  const tcp = rec ? getConnections(rec) : null;
  const udp = rec ? getUdp(rec) : null;
  const total = tcp !== null && udp !== null ? tcp + udp : null;
  const loadTh = effectiveLoadThreshold(c, cfg, parseCustomMap(cfg.load_custom_map));
  const sustain = toBool(cfg.sustain_enabled, true) ? toNum(cfg.sustain_seconds, 60) : 0;

  const out = [];
  const add = function (metric, enabled, value, threshold, sustainSeconds) {
    if (enabled && value !== null && value !== undefined && isFinite(value)) {
      out.push({ metric: metric, value: value, threshold: threshold, sustain: sustainSeconds });
    }
  };
  add("cpu", toBool(cfg.cpu_enabled, true), cpu, toNum(cfg.cpu_threshold, 90), 0);
  add("load", toBool(cfg.load_enabled, true), load, loadTh, 0);
  add("connections", toBool(cfg.connections_enabled, true), tcp, toNum(cfg.tcp_threshold, 1000), sustain);
  add("connections_udp", toBool(cfg.udp_enabled, true), udp, toNum(cfg.udp_threshold, 100), sustain);
  add("connections_merge", toBool(cfg.connections_merge_enabled, true), total, toNum(cfg.connections_merge_threshold, 1000), sustain);

  return {
    metrics: out,
    display: { cpu: cpu, load: load, conn: tcp, udp: udp, total: total, loadTh: loadTh },
  };
}

// 采集全量节点快照。
//   advance=true  巡检：推进报警状态机(可能触发通知)
//   advance=false 状态页刷新：只更新数值，保留上一轮巡检评估出的状态
//   单节点记录拉取失败：保留上一次快照的数值与状态，不误判离线
async function collectSnapshot(advance) {
  const cfg = STATE.config || {};
  const clients = await getClients(advance);
  // 巡检(advance)强制拉取最新记录；状态页刷新走 TTL 缓存
  const recentMap = await getRecentMap(clients.map(function (c) { return c.uuid; }), advance);

  const prevByUuid = {};
  for (const n of STATE.node) {
    if (n && n.uuid) prevByUuid[n.uuid] = n;
  }

  const result = [];
  const liveKeys = new Set();
  const errors = [];

  for (const c of clients) {
    const entry = recentMap.get(c.uuid) || { rec: null, error: null };
    const prev = prevByUuid[c.uuid];
    let nodeState;

    if (entry.error) {
      // 记录拉取失败：沿用上一次快照(数值+状态)，仅刷新排序位
      nodeState = prev ? Object.assign({}, prev) : {
        uuid: c.uuid, name: c.name, online: false,
        cpu: null, load: null, conn: null, udp: null, total: null, loadTh: null,
      };
      errors.push(c.name + ": " + entry.error);
      nodeState.order = result.length;
      result.push(nodeState);
      continue;
    }

    nodeState = { uuid: c.uuid, name: c.name, online: !!entry.rec };
    nodeState.order = result.length;

    if (entry.rec) {
      const m = collectMetrics(c, entry.rec, cfg);
      nodeState.cpu = fmt(m.display.cpu);
      nodeState.load = fmt(m.display.load);
      nodeState.conn = fmt(m.display.conn);
      nodeState.udp = fmt(m.display.udp);
      nodeState.total = m.display.total !== null ? fmt(m.display.total) : null;
      nodeState.loadTh = fmt(m.display.loadTh);

      if (advance) {
        for (const item of m.metrics) {
          liveKeys.add(c.uuid + ":" + item.metric);
          nodeState[METRIC_STATE_FIELD[item.metric]] = evaluateMetric(
            c.uuid, c.name, item.metric, item.value, item.threshold, cfg, item.sustain
          );
        }
        // 未启用的检测项沿用旧状态(关闭检测不应把历史报警态抹掉)
        if (nodeState.cpuState === undefined && prev) nodeState.cpuState = prev.cpuState;
        if (nodeState.loadState === undefined && prev) nodeState.loadState = prev.loadState;
        if (nodeState.connState === undefined && prev) nodeState.connState = prev.connState;
        if (nodeState.udpState === undefined && prev) nodeState.udpState = prev.udpState;
        if (nodeState.totalState === undefined && prev) nodeState.totalState = prev.totalState;
      } else if (prev) {
        nodeState.cpuState = prev.cpuState;
        nodeState.loadState = prev.loadState;
        nodeState.connState = prev.connState;
        nodeState.udpState = prev.udpState;
        nodeState.totalState = prev.totalState;
      }
    } else {
      nodeState.cpu = null;
      nodeState.load = null;
      nodeState.conn = null;
      nodeState.udp = null;
      nodeState.total = null;
      nodeState.loadTh = fmt(effectiveLoadThreshold(c, cfg, parseCustomMap(cfg.load_custom_map)));
      nodeState.cpuState = "offline";
      nodeState.loadState = "offline";
      nodeState.connState = "offline";
      nodeState.udpState = "offline";
      nodeState.totalState = "offline";
    }
    result.push(nodeState);
  }

  // 清理已不存在节点/已关闭检测的残余状态，防止 STATE.firing 无限增长
  if (advance) {
    for (const key of Object.keys(STATE.firing)) {
      if (!liveKeys.has(key)) delete STATE.firing[key];
    }
  }
  return { nodes: result, errors: errors };
}

/* ---------- 主巡检 ---------- */

let checking = false; // 巡检哨兵：防止慢巡检与下一轮定时重叠导致重复报警

async function runCheck() {
  if (checking) return;
  const cfg = STATE.config;
  if (!cfg) return;
  checking = true;
  try {
    const snap = await collectSnapshot(true);
    STATE.node = snap.nodes;
    STATE.lastCheck = new Date().toISOString();
    STATE.valuesAt = STATE.lastCheck;
    STATE.clients = snap.nodes;
    STATE.lastError = snap.errors.length ? "部分节点记录获取失败: " + snap.errors.join("; ") : "";
  } catch (e) {
    // 采集整体失败(如面板接口异常)：保留上一次快照，页面继续展示旧数据
    STATE.lastError = "check failed: " + e.message;
  } finally {
    checking = false;
  }
}

// 状态页轻量刷新：实时拉取各节点最新数值用于展示，不推进报警状态机
// (报警节奏仍由「检查间隔」决定，不会因为打开页面而加速报警)
async function refreshValues() {
  try {
    const snap = await collectSnapshot(false);
    STATE.node = snap.nodes;
    STATE.valuesAt = new Date().toISOString();
    if (snap.errors.length) {
      STATE.lastError = "部分节点记录获取失败: " + snap.errors.join("; ");
    }
  } catch (e) {
    STATE.lastError = "refresh failed: " + e.message;
  }
}

/* ---------- IP 被墙检测(引用 Komari 延迟监测任务数据) ---------- */

const PING_METRIC = "ping.latency_ms";

// 单轮 IP 被墙检测：读取选中延迟监测任务的 ping 数据 -> 线级分类 -> 任务级聚合 -> 状态机 -> 通知
async function runIpBlock() {
  const cfg = STATE.config;
  const ip = STATE.ipBlock;
  if (!cfg || ip.running) return;
  if (!toBool(cfg.ip_block_enabled, true)) return;
  ip.running = true;
  ip.lastError = "";
  try {
    // 1) 选中的延迟监测任务(1 个或多个)
    const taskIds = ipb.parseTaskIds(cfg.ip_block_pingtasks);
    if (!taskIds.length) {
      ip.lastError = "未选择延迟监测任务：请在插件配置的「延迟监测任务」中选择 1 个或多个任务";
      return;
    }
    const allTasks = await fetchPingTasksMap();
    const selected = [];
    for (const id of taskIds) {
      if (allTasks[id]) selected.push(allTasks[id]);
    }
    if (!selected.length) {
      ip.lastError = "所选延迟监测任务不存在(可能已被删除，请在插件配置中重新选择)";
      return;
    }

    // 2) 判定参数与查询窗口
    const timeoutMinutes = Math.max(1, toNum(cfg.ip_block_timeout_minutes, 10));
    const recoverMinutes = Math.max(0, toNum(cfg.ip_block_recover_minutes, 2));
    const hours = ipb.queryHours(timeoutMinutes, recoverMinutes);
    const maxPoints = ipb.queryMaxPoints(hours);
    const now = Date.now();

    // 3) 逐节点读取 ping 时序(一次调用返回该节点全部任务的序列，按 task_id 区分)，并发拉取
    const clients = await getClients(false);
    if (!clients.length) {
      ip.lastError = "面板没有任何节点";
      return;
    }
    const lines = {}; // taskId -> [{uuid, name, state, sum}]
    for (const id of taskIds) lines[id] = [];
    await pool(clients, FETCH_POOL, async function (c) {
      let resp = null;
      try {
        resp = await server.call("public:queryMetrics", {
          metric_keys: [PING_METRIC],
          entity_id: c.uuid,
          hours: hours,
          max_points: maxPoints,
          fill_empty: false,
          aggregation: "avg",
        });
      } catch (e) {
        resp = null; // 个别节点查询失败不影响其他节点
      }
      const byTask = ipb.extractTaskSeries(resp, taskIds);
      for (const id of taskIds) {
        const task = allTasks[id];
        const sum = ipb.summarizeLine(byTask[id], now);
        const state = ipb.classifyLine(sum, {
          timeoutMinutes: timeoutMinutes,
          recoverMinutes: recoverMinutes,
          freshMsLimit: ipb.freshMs(task ? task.interval : 60),
        }, now);
        lines[id].push({ uuid: c.uuid, name: c.name, state: state, sum: sum });
      }
    });

    // 4) 任务级聚合 + 状态机推进 + 通知
    const view = [];
    for (const task of selected) {
      const taskLines = lines[task.id];
      const round = ipb.taskRoundState(taskLines.map(function (l) { return l.state; }));
      const ev = ipb.advanceTaskState(ip.states, task.id, round, {
        cooldownSeconds: cfg.ip_block_cooldown_seconds,
      }, now);
      const st = ip.states[task.id];
      if (ev) notifyIpEvent(ev, task, taskLines);
      view.push(buildTaskView(task, taskLines, round, st));
    }

    ip.targets = view;
    ip.lastCheck = new Date().toISOString();
  } catch (e) {
    ip.lastError = "ip block check failed: " + e.message;
  } finally {
    ip.running = false;
  }
}

// 展示数据：任务 + 各监测线明细 + 状态
function buildTaskView(task, taskLines, round, st) {
  return {
    id: task.id,
    name: task.name,
    target: task.target,
    type: task.type,
    interval: task.interval,
    round: round,
    state: st ? st.state : "ok",
    since: st && st.since ? new Date(st.since).toISOString() : null,
    lastAt: st && st.lastAt ? new Date(st.lastAt).toISOString() : null,
    lines: taskLines.map(function (l) {
      return {
        uuid: l.uuid,
        name: l.name,
        state: l.state,
        timeoutMs: l.sum ? l.sum.timeoutMs : 0,
        okMs: l.sum ? l.sum.okMs : 0,
        lastValue: l.sum ? l.sum.lastSuccessValue : null,
        lastPointAt: l.sum && l.sum.lastPointAt ? new Date(l.sum.lastPointAt).toISOString() : null,
        failCount: l.sum ? l.sum.failCount : 0,
        count: l.sum ? l.sum.count : 0,
      };
    }),
  };
}

// IP 被墙事件 -> 通知(复用 deliver 的 Komari 站点通知渠道 + Webhook)
function notifyIpEvent(ev, task, taskLines) {
  const cfg = STATE.config || {};
  const label = task.name + (task.target ? " (" + task.target + ")" : "");
  // 通知携带执行该任务的节点对象(sendNotification 的 clients 参数)
  const clientObjs = [];
  for (const l of taskLines) {
    if (STATE.clientMap[l.uuid] && clientObjs.indexOf(STATE.clientMap[l.uuid]) < 0) {
      clientObjs.push(STATE.clientMap[l.uuid]);
    }
  }
  const dataLines = taskLines.filter(function (l) { return l.state !== "nodata"; });
  const nodeNames = dataLines.map(function (l) { return l.name; }).join("、") || "无";
  const timeoutMins = Math.max(1, toNum(cfg.ip_block_timeout_minutes, 10));
  const target = task.target || "?";

  if (ev.type === "blocked") {
    deliver(
      "alert",
      label + " IP 疑似被墙",
      "延迟监测任务「" + task.name + "」目标 " + target + " 已持续超时 " + timeoutMins +
        " 分钟以上(监测节点：" + nodeNames + " 全部超时)，入站 IP 可能已被封锁。建议尽快更换 IP、增加中转或切换线路。",
      { clients: clientObjs, node: task.name, metric: "ip_block", value: "fail", threshold: timeoutMins }
    );
  } else if (ev.type === "recover") {
    let latest = null;
    for (const l of dataLines) {
      if (l.state === "ok" || l.state === "recovering") latest = l;
    }
    const latency = latest && latest.sum && typeof latest.sum.lastSuccessValue === "number"
      ? "，最新延迟 " + latest.sum.lastSuccessValue + " ms(节点 " + latest.name + ")"
      : "";
    deliver(
      "recover",
      label + " IP 已恢复",
      "延迟监测任务「" + task.name + "」目标 " + target + " 已恢复正常" + latency + "。",
      { clients: clientObjs, node: task.name, metric: "ip_block", value: "ok", threshold: toNum(cfg.ip_block_recover_minutes, 2) }
    );
  } else if (ev.type === "repeat") {
    const mins = Math.round((Date.now() - ev.st.since) / 60000);
    deliver(
      "alert",
      label + " IP 被墙持续",
      "延迟监测任务「" + task.name + "」目标 " + target + " 持续无法连通(已 " + mins + " 分钟)，请尽快处理。",
      { clients: clientObjs, node: task.name, metric: "ip_block", value: "fail", threshold: timeoutMins }
    );
  }
}

/* ---------- 生命周期 ---------- */

let timer = null;
let ipTimer = null;

// 统一响应辅助
function json(res, code, obj) {
  res.statusCode = code;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.end(JSON.stringify(obj));
}

// 管理员判定(用户会话 / API Key / 角色含 admin)
function isAdmin(req) {
  const p = req && req.context && req.context.principal;
  return !!(p && (p.type === "user" || p.type === "api_key" || (p.roles && p.roles.indexOf("admin") >= 0)));
}

function applyCron() {
  if (timer) {
    clearInterval(timer);
    timer = null;
  }
  const interval = Math.max(5, toNum(STATE.config && STATE.config.check_interval, 60)) * 1000;
  timer = setInterval(function () { runCheck(); }, interval);
}

function applyIpCron() {
  if (ipTimer) {
    clearInterval(ipTimer);
    ipTimer = null;
  }
  const interval = Math.max(10, toNum(STATE.config && STATE.config.ip_block_interval, 300)) * 1000;
  ipTimer = setInterval(function () { runIpBlock(); }, interval);
}

async function load() {
  // 读取配置(含默认值合并)
  STATE.config = await server.getConfig();
  if (!STATE.config) STATE.config = {};

  // 注册状态查询路由(仅管理员)；fresh=1 时实时拉取各节点最新数值再返回
  server.route("GET", "/resource-alert/status", async function (req, res) {
    if (!isAdmin(req)) {
      json(res, 403, { status: "error", message: "forbidden" });
      return;
    }
    if (req.query && String(req.query.fresh) === "1") {
      await refreshValues();
    }
    json(res, 200, {
      status: "success",
      lastCheck: STATE.lastCheck,
      valuesAt: STATE.valuesAt,
      lastError: STATE.lastError,
      config: STATE.config,
      nodes: STATE.node,
      notifyLog: STATE.notifyLog,
      ipBlock: {
        tasks: STATE.ipBlock.targets,
        lastCheck: STATE.ipBlock.lastCheck,
        lastError: STATE.ipBlock.lastError,
        running: STATE.ipBlock.running,
      },
    });
  });

  // 测试通知路由：发送一条真实测试消息到 Komari 通知渠道和 Webhook，验证连通性(仅管理员)
  server.route("POST", "/resource-alert/test-notify", async function (req, res) {
    if (!isAdmin(req)) {
      json(res, 403, { status: "error", message: "forbidden" });
      return;
    }
    const cfg = STATE.config || {};
    const result = { status: "success", komari: null, webhook: null };

    // Komari 自带通知渠道(走后台已配置的 Telegram/SMTP 等 Provider)
    try {
      await server.call("admin:sendNotification", {
        event: {
          event: "测试通知",
          clients: [],
          time: new Date().toISOString(),
          message: "这是一条测试通知，收到即说明消息渠道连通正常。",
          emoji: "🔔",
        },
      });
      result.komari = { ok: true };
      pushNotifyLog({ channel: "komari", title: "测试通知", ok: true, test: true });
    } catch (e) {
      result.komari = { ok: false, error: e.message };
      pushNotifyLog({ channel: "komari", title: "测试通知", ok: false, error: e.message, test: true });
    }

    // 自定义 Webhook
    if (cfg.webhook_url) {
      try {
        const res2 = await fetch(cfg.webhook_url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            level: "test",
            title: "测试通知",
            message: "这是一条测试通知，收到即说明 Webhook 连通正常。",
            time: new Date().toISOString(),
          }),
        });
        result.webhook = { ok: res2.ok, httpStatus: res2.status };
        pushNotifyLog({
          channel: "webhook",
          title: "测试通知",
          ok: res2.ok,
          error: res2.ok ? "" : "HTTP " + res2.status,
          test: true,
        });
      } catch (e) {
        result.webhook = { ok: false, error: e.message };
        pushNotifyLog({ channel: "webhook", title: "测试通知", ok: false, error: e.message, test: true });
      }
    } else {
      result.webhook = { ok: null, note: "未配置 webhook_url" };
    }

    json(res, 200, result);
  });

  // 注册插件自有 RPC，可手动触发一次巡检(后台执行，立即返回)
  server.registerRPC("plugin:resourceAlertRun", function () {
    runCheck();
    return { ok: true, note: "check triggered in background" };
  });

  // 手动触发一次 IP 被墙检测(后台执行，立即返回)
  server.registerRPC("plugin:resourceAlertIpBlockRun", function () {
    runIpBlock();
    return { ok: true, note: "ip block check triggered in background" };
  });

  // HTTP 路由：手动触发 IP 被墙检测并返回最新状态(仅管理员)
  server.route("POST", "/resource-alert/ipblock-run", async function (req, res) {
    if (!isAdmin(req)) {
      json(res, 403, { status: "error", message: "forbidden" });
      return;
    }
    const started = !STATE.ipBlock.running;
    if (started) {
      runIpBlock();
    }
    json(res, 200, { status: "success", started: started, running: STATE.ipBlock.running });
  });

  applyCron();
  applyIpCron();
  // 启动后立即巡检一次
  runCheck();
  runIpBlock();
  console.log("[resource-alert] loaded, interval=" +
    (STATE.config.check_interval || 60) + "s, ipblock=" +
    (STATE.config.ip_block_interval || 300) + "s");
}

async function unload() {
  if (timer) {
    clearInterval(timer);
    timer = null;
  }
  if (ipTimer) {
    clearInterval(ipTimer);
    ipTimer = null;
  }
  console.log("[resource-alert] unloaded");
}
