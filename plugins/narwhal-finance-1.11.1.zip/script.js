// =============================================================================
// 独角鲸托管财务日报 — Komari 插件
// -----------------------------------------------------------------------------
// 数据来源：Narwhal Cloud (fuckip.me) 开放 API（Authorization: Bearer）
//   GET  /user/me                账户余额 available_balance
//   GET  /withdrawals/info       托管余额 / 冻结 / 托管可用
//   GET  /machines               机器列表（vm_count / est_revenue）
//   GET  /machines/{id}/plans    机器套餐（库存 / 售空）
//   GET  /machines/{id}/vms      机器 VM 明细（买家 / 规格 / 流量）
//   GET  /billing/transactions   交易流水（今日入账、累计提现、退款）
//   GET  /billing/orders         订单（交易 → VM 的权威映射）
//   GET  /tickets                工单（新消息推送 + 直接回复）
//
// 能力：每日定时日报、新交易实时推送、TG 命令交互、工单通知、自动提现、
//       机器套餐库存、客户购买排行、VM 归档、退款用户统计。
//
// v1.11.0 主要改进（逻辑 / 代码 / 界面）：
//   1. 今日交易分页修复：以「原始返回行数」判断是否继续翻页，避免客户端二次过滤
//      导致提前中断、漏掉当日更早的交易。
//   2. 定时任务时区换算改为「按分钟计算」，支持 +5:30 等半小时时区，不再生成非法 cron。
//   3. Telegram 长消息自动分片（4096 上限），日报不再因超长整条发送失败；429 自动重试。
//   4. Webhook 补齐 callback_query 订阅，内联按钮在推送模式下同样可用。
//   5. 持久化拆分为 state.json（轻量）+ cache.json（机器/归档/排行大数据），
//      写入防抖 + 原子替换，避免每次推送日志都重写数 MB 文件。
//   6. 日报发送失败不再标记「今日已发」，自动重试 2 次，避免当日日报彻底丢失。
//   7. 归档 / VM / 套餐查询增加前缀索引，退款统计与交易定位从 O(n) 降为 O(1)。
//   8. /balance 命令走轻量采集（仅余额 + 今日交易），不再全量拉机器列表。
//   9. 轮询连续失败 3 次主动告警一次；预览文本仅在数据变化时重建，减少无谓请求。
//  10. 统一路由守卫 / JSON 响应 / 错误处理，管理页 4 个接口并行加载。
// =============================================================================

const server = require("server");
const fs = require("fs");
const path = require("path");

const VERSION = "1.11.1";

/* ============================== 常量 ============================== */

// 交易类型中文名
const TYPE_LABEL = {
  escrow_in: "托管收入",
  escrow_renew: "托管续费",
  escrow_deduct: "托管扣减",
  purchase: "购买",
  renew: "续费",
  renewal: "续费",
  refund: "退款",
  withdrawal: "提现",
  topup: "充值",
  market_sell: "市场出售",
  market_buy: "市场购买",
  ip_rent: "IP租赁",
  ip_renew: "IP续费",
  compensation: "补偿",
};

// 入账分类
const IN_LABELS = {
  escrow_in: "托管收入",
  escrow_renew: "托管续费",
  topup: "充值",
  market_sell: "市场出售",
  ip_rent: "IP租赁",
  ip_renew: "IP续费",
  compensation: "补偿",
};

// 扣减分类
const OUT_LABELS = {
  escrow_deduct: "托管扣减",
  purchase: "购买",
  refund: "退款",
  withdrawal: "提现",
  market_buy: "市场购买",
};

// 展示顺序（未登记的标签排到最后）
const IN_ORDER = ["托管收入", "托管续费", "充值", "市场出售", "IP租赁", "IP续费", "补偿", "其他入账"];
const OUT_ORDER = ["托管扣减", "购买", "退款", "提现申请", "提现完成", "提现", "市场购买", "其他扣减"];

// 分类标签 → emoji（日报「入账/扣减明细」与管理页收支构成共用）
const LABEL_ICON = {
  "托管收入": "📈", "托管续费": "🔄", "充值": "💵", "市场出售": "🏷️",
  "IP租赁": "🌐", "IP续费": "🔁", "补偿": "🎁", "其他入账": "💸",
  "托管扣减": "📉", "购买": "🛒", "退款": "↩️", "提现申请": "🏧",
  "提现完成": "✅", "提现": "🏦", "市场购买": "🛍️", "其他扣减": "➖",
};
function labelIcon(k) { return LABEL_ICON[k] || "💸"; }

// 提现细分：按备注关键词区分「申请中」与「已完成」，识别不了归通用「提现」
function classifyWithdraw(note) {
  const n = String(note || "");
  if (/完成|成功|已到账|已通过|已处理|已打款/.test(n)) return "提现完成";
  if (/申请|请求|待处理|审核中|处理中|提交|审批|受理/.test(n)) return "提现申请";
  return "提现";
}

// 订单类型 → 托管交易类型
const ORDER_TX_TYPES = { purchase: ["escrow_in"], renewal: ["escrow_renew"], refund: ["escrow_deduct"] };
// 交易类型 → 订单类型（note 前缀桥接用）
const TX_ORDER_TYPES = { escrow_in: ["purchase"], escrow_renew: ["renewal"], escrow_deduct: ["refund"] };

const TG_TEXT_LIMIT = 4000;          // Telegram 单条上限 4096，留出安全余量
const TX_SCAN_MAX_PAGES = 20;        // 今日交易最大翻页
const ARCHIVE_LIMIT = 2000;          // VM 归档条数上限
const SEEN_KEEP = 500;               // 工单已读 ID 保留数
const API_MIN_GAP = 50;              // 相邻 API 请求最小间隔（毫秒）

// 大数据字段：单独落在 cache.json，避免每次写日志都重写 MB 级文件
const HEAVY_KEYS = ["machineData", "machineDataAt", "machineDataAlgo", "machineSyncDate", "vmArchive", "rankData"];

/* ============================== 运行状态 ============================== */

const S = {
  config: {},
  token: null,
  tokenExp: 0,

  alertsReady: false,     // 新交易水位基线是否已建立（持久化）
  lastCheck: null,
  lastReport: null,
  lastError: "",
  lastText: "",

  todayTxns: [],
  balances: null,
  instanceCount: 0,
  estMonthly: 0,
  withdrawSum: 0,
  inParts: {},
  outParts: {},
  todayIn: 0,
  todayOut: 0,
  todayNet: 0,

  notifyLog: [],
  tgCommands: null,
  tgWebhook: null,

  vmSnapshot: null,
  vmSnapshotAt: 0,
  machineInfoCache: null,
  machineInfoAt: 0,

  state: {},              // 持久化状态（state.json + cache.json 合并视图）
};

// 互斥锁：不同任务之间互不阻塞（轮询不再阻塞日报发送）
const L = {
  poll: false,
  report: false,
  rank: false,
  withdraw: false,
  refund: false,
  autoWithdraw: false,
  ticket: false,
  notifyBuyers: false,
  syncAll: false,
  machineSync: false,
  tgPoll: false,
};

/* ============================== 基础工具 ============================== */

function toNum(v, def) {
  const n = Number(v);
  return isFinite(n) ? n : def;
}

function toBool(v, def) {
  return v === undefined || v === null ? def : !!v;
}

function pad(n) {
  return (n < 10 ? "0" : "") + n;
}

function round2(v) {
  return Math.round(toNum(v, 0) * 100) / 100;
}

function abs2(v) {
  return Math.abs(round2(v)).toFixed(2);
}

function nowSec() {
  return Math.floor(Date.now() / 1000);
}

function sleep(ms) {
  return new Promise(function (r) { setTimeout(r, ms); });
}

function currency() {
  return (S.config && S.config.currency_symbol) || "$";
}

// 金额格式化：可选正负号 + 货币符号 + 两位小数
function money(v, withSign) {
  const n = round2(v);
  const s = withSign ? (n > 0 ? "+" : n < 0 ? "-" : "") : "";
  return s + currency() + abs2(n);
}

// 时间戳(秒) → 配置时区下的时间分量
function tsToLocal(ts) {
  const off = toNum(S.config.timezone_offset, 8) * 3600;
  const d = new Date((toNum(ts, 0) + off) * 1000);
  return {
    y: d.getUTCFullYear(),
    mo: d.getUTCMonth() + 1,
    d: d.getUTCDate(),
    h: d.getUTCHours(),
    mi: d.getUTCMinutes(),
    s: d.getUTCSeconds(),
  };
}

function nowStr() {
  const t = tsToLocal(nowSec());
  return t.y + "-" + pad(t.mo) + "-" + pad(t.d) + " " + pad(t.h) + ":" + pad(t.mi) + ":" + pad(t.s);
}

function txTimeStr(ts) {
  const t = tsToLocal(ts);
  return pad(t.mo) + "-" + pad(t.d) + " " + pad(t.h) + ":" + pad(t.mi);
}

// 今日零点（秒，按配置时区）
function dayStart() {
  const off = toNum(S.config.timezone_offset, 8) * 3600;
  return Math.floor((nowSec() + off) / 86400) * 86400 - off;
}

function todayKey() {
  const t = tsToLocal(nowSec());
  return t.y + "-" + pad(t.mo) + "-" + pad(t.d);
}

function yesterdayKey() {
  return todayKeyOf(nowSec() - 86400);
}

function todayKeyOf(ts) {
  const t = tsToLocal(ts);
  return t.y + "-" + pad(t.mo) + "-" + pad(t.d);
}

// 时区标签：8 → "UTC+8"，5.5 → "UTC+5:30"
function tzLabel() {
  const off = toNum(S.config.timezone_offset, 8);
  const abs = Math.abs(off);
  const h = Math.floor(abs);
  const m = Math.round((abs - h) * 60);
  return "UTC" + (off < 0 ? "-" : "+") + h + (m ? ":" + pad(m) : "");
}

// "HH:MM" 解析（容错全角冒号 / 越界值）
function parseHHMM(raw, defH, defM) {
  const m = String(raw || "").match(/^(\d{1,2})\s*[:：]\s*(\d{1,2})$/);
  if (!m) return { h: defH, m: defM };
  return {
    h: Math.min(23, Math.max(0, parseInt(m[1], 10))),
    m: Math.min(59, Math.max(0, parseInt(m[2], 10))),
  };
}

// 本地时刻 → UTC cron 表达式（按分钟换算，支持 +5:30 这类半小时时区）
function cronAtLocal(hhmm, offsetHours, defH) {
  const t = parseHHMM(hhmm, defH, 0);
  const offMin = Math.round(toNum(offsetHours, 8) * 60);
  let total = t.h * 60 + t.m - offMin;
  total = ((total % 1440) + 1440) % 1440;
  return (total % 60) + " " + Math.floor(total / 60) + " * * *";
}

// 下一次本地时刻的时间戳（毫秒）
function nextDailyAt(hhmm, offsetHours, defH) {
  const t = parseHHMM(hhmm, defH, 0);
  const off = toNum(offsetHours, 8) * 3600;
  const local = nowSec() + off;
  let target = Math.floor(local / 86400) * 86400 + t.h * 3600 + t.m * 60;
  if (target <= local) target += 86400;
  return (target - off) * 1000;
}

// 统一 HTTP → {res, text, json}
async function httpJson(url, opts) {
  const res = await fetch(url, opts);
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch (e) {}
  return { res: res, text: text, json: json };
}

async function withRetry(fn, attempts, delayMs) {
  let err = null;
  const n = Math.max(1, toNum(attempts, 3));
  for (let i = 0; i < n; i++) {
    try { return await fn(); } catch (e) {
      err = e;
      if (i < n - 1) await sleep(toNum(delayMs, 800));
    }
  }
  throw err || new Error("retry failed");
}

/* ============================== 持久化 ============================== */

function storageDir() {
  try {
    if (typeof __storageDir__ !== "undefined" && __storageDir__) return __storageDir__;
  } catch (e) {}
  return null;
}

function storageFile(name) {
  const dir = storageDir();
  return dir ? path.join(dir, name) : null;
}

function readJsonFile(file) {
  if (!file) return null;
  try {
    if (!fs.existsSync(file)) return null;
    const t = fs.readFileSync(file, "utf8");
    return t ? JSON.parse(t) : null;
  } catch (e) {
    console.log("[narwhal-finance] 读取 " + path.basename(file) + " 失败: " + e.message);
    return null;
  }
}

// 原子写入：先写 .tmp 再重命名，避免进程中断留下半个 JSON
function writeJsonFile(file, obj) {
  if (!file) return;
  try {
    const dir = path.dirname(file);
    if (!fs.existsSync(dir)) {
      try { fs.mkdirSync(dir, { recursive: true }); } catch (e) {}
    }
    const tmp = file + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(obj));
    try { fs.renameSync(tmp, file); } catch (e) {
      fs.writeFileSync(file, JSON.stringify(obj));
      try { fs.unlinkSync(tmp); } catch (e2) {}
    }
  } catch (e) {
    console.error("[narwhal-finance] 写入 " + path.basename(file) + " 失败: " + e.message);
  }
}

function splitState() {
  const light = {};
  const heavy = {};
  for (const k of Object.keys(S.state)) {
    if (HEAVY_KEYS.indexOf(k) >= 0) heavy[k] = S.state[k];
    else light[k] = S.state[k];
  }
  return { light: light, heavy: heavy };
}

function loadStore() {
  const light = readJsonFile(storageFile("state.json")) || {};
  const heavy = readJsonFile(storageFile("cache.json")) || {};
  // 旧版本把大数据写在 state.json 里：迁移到 cache.json 并瘦身
  let migrated = false;
  for (const k of HEAVY_KEYS) {
    if (Object.prototype.hasOwnProperty.call(light, k)) {
      if (!Object.prototype.hasOwnProperty.call(heavy, k)) heavy[k] = light[k];
      delete light[k];
      migrated = true;
    }
  }
  S.state = Object.assign({}, heavy, light);
  if (migrated) {
    console.log("[narwhal-finance] 存储结构升级：大数据迁移至 cache.json");
    flushSave();
  }
}

let saveTimer = null;
let dirtyLight = false;
let dirtyHeavy = false;

function scheduleSave(light, heavy) {
  if (light) dirtyLight = true;
  if (heavy) dirtyHeavy = true;
  if (saveTimer) return;
  saveTimer = setTimeout(function () {
    saveTimer = null;
    flushSave();
  }, 400);
}

function flushSave() {
  if (saveTimer) {
    clearTimeout(saveTimer);
    saveTimer = null;
  }
  if (!storageDir()) {
    dirtyLight = false;
    dirtyHeavy = false;
    return;
  }
  const parts = splitState();
  if (dirtyLight) {
    writeJsonFile(storageFile("state.json"), parts.light);
    dirtyLight = false;
  }
  if (dirtyHeavy) {
    writeJsonFile(storageFile("cache.json"), parts.heavy);
    dirtyHeavy = false;
  }
}

// 常规保存：轻量状态立即排队，大数据随缓存单独排队（合并写）
function saveState() {
  scheduleSave(true, true);
}

function saveCache() {
  scheduleSave(false, true);
}

/* ============================== Narwhal API ============================== */

function apiBase() {
  return String(S.config.api_base || "https://api.fuckip.me/api/v1").replace(/\/+$/, "");
}

// 邮箱密码登录换 Token
async function apiLogin() {
  const cfg = S.config;
  const r = await httpJson(apiBase() + "/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: cfg.auth_email, password: cfg.auth_password }),
  });
  if (!r.res.ok || !r.json || !r.json.data || !r.json.data.token) {
    throw new Error("login failed: " + (r.text || "HTTP " + r.res.status).slice(0, 200));
  }
  S.token = r.json.data.token;
  const exp = toNum(r.json.data.expires_at, 0);
  S.tokenExp = exp ? exp * 1000 : Date.now() + 6 * 3600 * 1000;
  return S.token;
}

async function ensureToken() {
  if (S.config.api_key) return S.config.api_key;
  if (S.token && Date.now() < S.tokenExp) return S.token;
  return apiLogin();
}

// 统一请求：401 自动重新登录重试；429 指数退避（Cloudflare 限速）
async function apiRequest(pathAndQuery, opts) {
  const cfg = S.config;
  const method = ((opts && opts.method) || "GET").toUpperCase();
  const hasBody = opts && opts.body !== undefined && opts.body !== null;
  let relogin = false;
  let backoff = 0;

  for (let attempt = 0; attempt < 6; attempt++) {
    const token = await ensureToken();
    const headers = { Accept: "application/json" };
    if (token) headers["Authorization"] = "Bearer " + token;
    if (hasBody) headers["Content-Type"] = "application/json";

    let r = null;
    try {
      r = await httpJson(apiBase() + pathAndQuery, {
        method: method,
        headers: headers,
        body: hasBody ? JSON.stringify(opts.body) : undefined,
      });
    } catch (e) {
      throw new Error("network: " + e.message);
    }

    if (r.res.status === 401 && !relogin && !cfg.api_key) {
      S.token = null;
      relogin = true;
      continue;
    }
    if (r.res.status === 429 && attempt < 5) {
      backoff = backoff ? backoff * 2 : 2000;
      console.log("[narwhal-finance] API 限速(429)，" + backoff + "ms 后重试: " + String(pathAndQuery).slice(0, 80));
      await sleep(backoff);
      continue;
    }
    if (!r.res.ok) throw new Error("HTTP " + r.res.status + ": " + r.text.slice(0, 200));
    if (r.json && r.json.code !== undefined && r.json.code !== 0) throw new Error(r.json.msg || "API code " + r.json.code);
    return r.json ? r.json.data : null;
  }
  throw new Error("unauthorized");
}

function apiGet(p) { return apiRequest(p, { method: "GET" }); }
function apiPost(p, body) { return apiRequest(p, { method: "POST", body: body || {} }); }
function apiPut(p, body) { return apiRequest(p, { method: "PUT", body: body || {} }); }

// 串行节流队列：所有请求排队，相邻间隔 ≥ api_rate_ms，避免全量分页触发 429
let apiQueueTail = Promise.resolve();
let apiLastAt = 0;

function apiThrottledRaw(pathAndQuery, opts, minInterval) {
  const cfg = S.config || {};
  const interval = Math.max(API_MIN_GAP, Math.min(60000, toNum(minInterval || cfg.api_rate_ms, 250)));
  const task = apiQueueTail.then(async function () {
    const wait = apiLastAt + interval - Date.now();
    if (wait > 0) await sleep(wait);
    try {
      return await apiRequest(pathAndQuery, opts);
    } finally {
      apiLastAt = Date.now();
    }
  });
  apiQueueTail = task.then(function () {}, function () {}); // 队列不因单次失败中断
  return task;
}

function apiThrottled(p) { return apiThrottledRaw(p, { method: "GET" }); }
function apiPostThrottled(p, body, minInterval) { return apiThrottledRaw(p, { method: "POST", body: body }, minInterval); }
function apiPutThrottled(p, body) { return apiThrottledRaw(p, { method: "PUT", body: body }); }

/* ============================== 数据拉取 ============================== */

// 今日交易：分页拉取 + 客户端二次过滤。
// 注意：翻页判断必须用「服务端原始返回行数」，否则过滤后行数变少会被误判为最后一页。
async function fetchTodayTxns() {
  const start = dayStart();
  const end = nowSec();
  const seen = {};
  const out = [];
  let serverFilter = true; // 服务端不支持时间过滤时降级为本地过滤

  for (let page = 1; page <= TX_SCAN_MAX_PAGES; page++) {
    let rows = [];
    if (serverFilter) {
      try {
        const d = await apiThrottled("/billing/transactions?page=" + page + "&page_size=100&start_time=" + start + "&end_time=" + end);
        rows = (d && d.transactions) || [];
      } catch (e) {
        serverFilter = false; // 降级：本页改用全量接口重取
      }
    }
    if (!serverFilter) {
      const d2 = await apiThrottled("/billing/transactions?page=" + page + "&page_size=100");
      rows = (d2 && d2.transactions) || [];
    }

    const rawCount = rows.length;
    for (const t of rows) {
      const ts = toNum(t.created_at, 0);
      if (ts < start || ts > end + 60) continue;
      const key = t.id ? String(t.id) : ts + "|" + toNum(t.amount, 0) + "|" + String(t.note || "");
      if (seen[key]) continue;
      seen[key] = true;
      out.push(t);
    }
    if (rawCount < 100) break; // 服务端已无更多页
  }

  out.sort(function (a, b) { return toNum(b.created_at, 0) - toNum(a.created_at, 0); });
  return out;
}

// 最后一笔交易（不限今日，测试通讯用）。服务端排序方向不确定，按时间取最大值。
async function fetchLastTx() {
  const d = await apiThrottled("/billing/transactions?page=1&page_size=100");
  const rows = (d && d.transactions) || [];
  if (!rows.length) return null;
  const asc = rows.length < 2 || toNum(rows[rows.length - 1].created_at, 0) >= toNum(rows[0].created_at, 0);
  if (!asc) return rows[0];

  let newest = rows[0];
  for (const r of rows) {
    if (toNum(r.created_at, 0) > toNum(newest.created_at, 0)) newest = r;
  }
  const total = Math.max(rows.length, toNum(d && d.total, rows.length));
  const lastPage = Math.max(1, Math.ceil(total / 100));
  if (lastPage > 1) {
    try {
      const d2 = await apiThrottled("/billing/transactions?page=" + lastPage + "&page_size=100");
      for (const r of ((d2 && d2.transactions) || [])) {
        if (toNum(r.created_at, 0) > toNum(newest.created_at, 0)) newest = r;
      }
    } catch (e) {}
  }
  return newest;
}

// 机器列表分页拉全（按 id 去重，整页无新增即停止，防服务端忽略分页）
async function fetchAllMachines() {
  const all = [];
  const seen = {};
  for (let page = 1; page <= 100; page++) {
    const d = await apiThrottled("/machines?page=" + page + "&page_size=100");
    const rows = (d && d.machines) || [];
    if (!rows.length) break;
    let added = 0;
    for (const m of rows) {
      if (!m || !m.id || seen[m.id]) continue;
      seen[m.id] = true;
      all.push(m);
      added++;
    }
    if (rows.length < 100 || added === 0) break;
  }
  return all;
}

// 累计提现：增量扫描。
// 水位模型：wdMaxTs = 已统计的最新提现时间戳，wdMaxIds = 该秒内已统计的 ID。
//   ts >  wdMaxTs → 新提现，累加
//   ts == wdMaxTs → 按 id 去重后累加（同一秒多笔）
//   ts <  wdMaxTs → 已统计区间，停止翻页
async function fetchWithdrawals() {
  const st = S.state;
  let sum = toNum(st.withdrawSum, 0);
  const maxTs = toNum(st.wdMaxTs, 0);
  const maxIds = Array.isArray(st.wdMaxIds) ? st.wdMaxIds.slice() : [];
  const maxIdMap = {};
  for (const id of maxIds) maxIdMap[id] = true;
  const counted = {}; // 本轮已计数（防服务端跨页重复返回）

  let newMaxTs = maxTs;
  let newMaxIds = [];
  const maxPages = Math.max(1, Math.min(500, toNum(S.config.withdraw_max_pages, 60)));

  for (let page = 1; page <= maxPages; page++) {
    let rows = null;
    try {
      const d = await apiThrottled("/billing/transactions?page=" + page + "&page_size=100&type=withdrawal&balance_type=escrow");
      rows = (d && d.transactions) || [];
    } catch (e) {
      const d2 = await apiThrottled("/billing/transactions?page=" + page + "&page_size=100");
      rows = (d2 && d2.transactions) || [];
    }
    if (!rows.length) break;

    let stop = false;
    for (const t of rows) {
      if (t.type !== "withdrawal") continue; // 服务端可能忽略 type 过滤
      const ts = toNum(t.created_at, 0);
      const tid = t.id ? String(t.id) : "";
      if (tid && counted[tid]) continue;

      if (ts > maxTs) {
        sum += Math.abs(toNum(t.amount, 0));
        if (tid) counted[tid] = true;
        if (ts > newMaxTs) {
          newMaxTs = ts;
          newMaxIds = [];
        }
        if (ts === newMaxTs && t.id) newMaxIds.push(t.id);
      } else if (ts === maxTs && t.id && !maxIdMap[t.id]) {
        sum += Math.abs(toNum(t.amount, 0));
        maxIdMap[t.id] = true;
        maxIds.push(t.id);
        counted[tid] = true;
      } else if (ts < maxTs) {
        stop = true;
        break;
      }
    }
    if (stop || rows.length < 100) break;
  }

  st.withdrawSum = round2(sum);
  if (newMaxTs > maxTs) {
    st.wdMaxTs = newMaxTs;
    st.wdMaxIds = newMaxIds.slice(0, 100);
  } else {
    st.wdMaxTs = maxTs;
    st.wdMaxIds = maxIds.slice(0, 100);
  }
  return { sum: round2(sum) };
}

// 退款用户统计：按【VM 实际买家】聚合（交易 user_id 是母鸡自身，不能作为买家）。
// 退款判定：type=refund，或 type=escrow_deduct 且 note 含 VM 前缀（VM 销毁退款）。
async function fetchRefundStats() {
  const st = S.state;
  let stats = st.refundStats;
  if (!stats || typeof stats !== "object" || Array.isArray(stats)) stats = {};

  const maxTs = toNum(st.rfMaxTs, 0);
  const maxIds = Array.isArray(st.rfMaxIds) ? st.rfMaxIds.slice() : [];
  const maxIdMap = {};
  for (const id of maxIds) maxIdMap[id] = true;

  // 母鸡自身账号（订单 user_id 命中时不算买家）
  const ownerIds = {};
  for (const oid of (Array.isArray(st.rfOwnerIds) ? st.rfOwnerIds : [])) ownerIds[String(oid)] = true;

  let newMaxTs = maxTs;
  let newMaxIds = [];
  let orders = null;
  const counted = {};

  const countRefund = async function (t, ts, note) {
    const prefix = vmPrefixFromNote(note);
    if (orders === null) {
      try { orders = await fetchRecentOrders(); } catch (e) { orders = []; }
    }
    const buyer = locateBuyerByVmPrefix(prefix, orders, ownerIds);
    const key = (buyer && (buyer.email || buyer.userId)) ? (buyer.email || ("用户#" + buyer.userId)) : "__unknown__";
    if (!stats[key]) stats[key] = { count: 0, lastAt: 0 };
    stats[key].count += 1;
    if (ts > toNum(stats[key].lastAt, 0)) stats[key].lastAt = ts;
  };

  const maxPages = Math.max(1, Math.min(500, toNum(S.config.withdraw_max_pages, 60)));
  for (let page = 1; page <= maxPages; page++) {
    const d = await apiThrottled("/billing/transactions?page=" + page + "&page_size=100");
    const rows = (d && d.transactions) || [];
    if (!rows.length) break;

    let stop = false;
    for (const t of rows) {
      if (t.user_id) ownerIds[String(t.user_id)] = true;
      const ty = t.type || "";
      const note = String(t.note || "");
      if (ty !== "refund" && ty !== "escrow_deduct") continue;

      const ts = toNum(t.created_at, 0);
      const tid = t.id ? String(t.id) : "";
      if (tid && counted[tid]) continue;

      if (ts > maxTs) {
        await countRefund(t, ts, note);
        if (tid) counted[tid] = true;
        if (ts > newMaxTs) {
          newMaxTs = ts;
          newMaxIds = [];
        }
        if (ts === newMaxTs && t.id) newMaxIds.push(t.id);
      } else if (ts === maxTs && t.id && !maxIdMap[t.id]) {
        await countRefund(t, ts, note);
        maxIdMap[t.id] = true;
        maxIds.push(t.id);
        counted[tid] = true;
      } else if (ts < maxTs) {
        stop = true;
        break;
      }
    }
    if (stop || rows.length < 100) break;
  }

  st.refundStats = stats;
  st.rfOwnerIds = Object.keys(ownerIds).slice(0, 20);
  if (newMaxTs > maxTs) {
    st.rfMaxTs = newMaxTs;
    st.rfMaxIds = newMaxIds.slice(0, 100);
  } else {
    st.rfMaxTs = maxTs;
    st.rfMaxIds = maxIds.slice(0, 100);
  }
  return stats;
}

// 最近订单：purchase/renewal/refund 订单自带 vm_id，是交易 → VM 的权威映射
async function fetchRecentOrders() {
  const out = [];
  const seen = {};
  const push = function (rows) {
    for (const o of rows) {
      if (!o || !o.id || seen[o.id]) continue;
      seen[o.id] = true;
      out.push(o);
    }
  };
  try {
    const first = await apiThrottled("/billing/orders?page=1&page_size=100");
    const rows = (first && first.orders) || [];
    push(rows);
    if (rows.length >= 100) {
      const asc = toNum(rows[rows.length - 1].created_at, 0) >= toNum(rows[0].created_at, 0);
      if (asc) {
        const total = toNum(first && first.total, out.length);
        const lastPage = Math.max(1, Math.ceil(total / 100));
        for (let p = Math.max(2, lastPage - 2); p <= lastPage; p++) {
          const d = await apiThrottled("/billing/orders?page=" + p + "&page_size=100");
          const r = (d && d.orders) || [];
          push(r);
          if (r.length < 100) break;
        }
      } else {
        for (let p = 2; p <= 3; p++) {
          const d = await apiThrottled("/billing/orders?page=" + p + "&page_size=100");
          const r = (d && d.orders) || [];
          push(r);
          if (r.length < 100) break;
        }
      }
    }
  } catch (e) {} // 订单接口不可用时回退快照匹配
  return out;
}

/* ============================== 交易分类与汇总 ============================== */

// 单笔入账分类：备注关键词优先（续费也可能记为 escrow_in）
function classifyIn(t) {
  const note = String(t.note || "");
  if (note.indexOf("续费") >= 0) return "托管续费";
  const type = t.type || "";
  if (IN_LABELS[type]) return IN_LABELS[type];
  if (type === "renew" || type === "renewal") return "托管续费";
  if (note.indexOf("购买") >= 0 || note.indexOf("新购") >= 0 || note.indexOf("开通") >= 0) return "托管收入";
  return "其他入账";
}

// 单笔扣减分类：类型优先，备注兜底
function classifyOut(t) {
  const type = t.type || "";
  if (OUT_LABELS[type]) {
    // 提现类交易进一步区分「申请中 / 已完成」
    if (type === "withdrawal") return classifyWithdraw(String(t.note || ""));
    return OUT_LABELS[type];
  }
  const note = String(t.note || "");
  if (note.indexOf("退款") >= 0) return "退款";
  if (note.indexOf("提现") >= 0) return classifyWithdraw(note);
  if (note.indexOf("补偿") >= 0) return "补偿";
  if (note.indexOf("续费") >= 0) return "托管扣减";
  return "其他扣减";
}

function buildDaily(txs) {
  const inParts = {};
  const outParts = {};
  let tin = 0;
  let tout = 0;
  for (const t of txs) {
    const amt = toNum(t.amount, 0);
    if (amt >= 0) {
      tin += amt;
      const label = classifyIn(t);
      inParts[label] = round2((inParts[label] || 0) + amt);
    } else {
      tout += -amt;
      const label = classifyOut(t);
      outParts[label] = round2((outParts[label] || 0) + (-amt));
    }
  }
  return { inParts: inParts, outParts: outParts, tin: round2(tin), tout: round2(tout), net: round2(tin - tout) };
}

// 分类汇总片段（托管收入：+$15.80 · 托管续费：+$5.00）
function partsStr(parts, neg) {
  const order = neg ? OUT_ORDER : IN_ORDER;
  const keys = Object.keys(parts).sort(function (a, b) {
    const ia = order.indexOf(a);
    const ib = order.indexOf(b);
    return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
  });
  const arr = [];
  for (const k of keys) {
    if (parts[k] > 0) {
      arr.push(labelIcon(k) + " " + k + "：" + (neg ? "-" + currency() + abs2(parts[k]) : money(parts[k], true)));
    }
  }
  return arr.length ? "（" + arr.join(" · ") + "）" : "";
}

// 余额行：昨日 → 今日 + 变动
function balanceLine(today, yesterday) {
  const sym = currency();
  const t = sym + abs2(today);
  if (yesterday === null || yesterday === undefined) return " " + t;
  const delta = round2(today - yesterday);
  if (Math.abs(delta) < 0.005) return " " + sym + abs2(yesterday) + " → " + t;
  return " " + sym + abs2(yesterday) + " → " + t + "  " + (delta > 0 ? "+" : "-") + sym + abs2(delta);
}

/* ============================== 机器数据 / 索引 ============================== */

// 机器概览数据源：内存缓存优先，其次持久化
function machineDataList() {
  if (S.machineInfoCache && S.machineInfoCache.length) return S.machineInfoCache;
  if (Array.isArray(S.state.machineData) && S.state.machineData.length) return S.state.machineData;
  return [];
}

function machineDataStamp() {
  return toNum(S.machineInfoAt, 0) || toNum(S.state.machineDataAt, 0);
}

// VM 前缀索引（8 位 → {vm, machine, plan}），避免每次定位都全量扫描
let vmIndexCache = { stamp: -1, map: null };
let planIndexCache = { stamp: -1, map: null };

function invalidateMachineIndex() {
  vmIndexCache = { stamp: -1, map: null };
  planIndexCache = { stamp: -1, map: null };
}

function vmIndex() {
  const stamp = machineDataStamp();
  if (vmIndexCache.map && vmIndexCache.stamp === stamp) return vmIndexCache.map;
  const map = {};
  for (const m of machineDataList()) {
    for (const p of (m && m.plans) || []) {
      for (const v of (p && p.vms) || []) {
        const k = String(v && v.vmId || "").slice(0, 8).toLowerCase();
        if (k) map[k] = { vm: v, machine: m, plan: p };
      }
    }
  }
  vmIndexCache = { stamp: stamp, map: map };
  return map;
}

function planIndex() {
  const stamp = machineDataStamp();
  if (planIndexCache.map && planIndexCache.stamp === stamp) return planIndexCache.map;
  const map = {};
  for (const m of machineDataList()) {
    for (const p of (m && m.plans) || []) {
      if (p && p.id) map[String(p.id)] = { machine: m, plan: p };
    }
  }
  planIndexCache = { stamp: stamp, map: map };
  return map;
}

// VM 归档前缀索引
let archiveIndexCache = null;

function archiveMap() {
  const a = S.state.vmArchive;
  return (a && typeof a === "object" && !Array.isArray(a)) ? a : {};
}

function archiveIndex() {
  if (archiveIndexCache) return archiveIndexCache;
  const idx = {};
  const arch = archiveMap();
  for (const k of Object.keys(arch)) {
    const a = arch[k];
    if (!a) continue;
    const p = String(a.vmId || k).slice(0, 8).toLowerCase();
    if (p) idx[p] = a;
  }
  archiveIndexCache = idx;
  return idx;
}

// VM 明细统一字段（宿主视角 VM 响应 → 持久化格式）
function vmDetailFields(vm) {
  return {
    vmId: vm.id || "",
    email: String(vm.user_email || "").trim(),
    userId: vm.user_id || "",
    status: vm.status || "",
    remark: vm.remark || "",
    expiresAt: toNum(vm.expires_at, 0),
    createdAt: toNum(vm.created_at, 0),
    cpu: toNum(vm.cpu, 0),
    ramMb: toNum(vm.ram_mb, 0),
    diskGb: toNum(vm.disk_gb, 0),
    trafficGb: toNum(vm.monthly_traffic_gb, 0), // 0 = 无限流量
    trafficUsedGb: round2((toNum(vm.monthly_traffic_in, 0) + toNum(vm.monthly_traffic_out, 0)) / 1e9),
    price: toNum(vm.price_monthly, 0),
    autoRenew: toBool(vm.auto_renew, false),
  };
}

// 按 VM ID 前 8 位定位完整详情：归档（已销毁）→ 机器概览明细
function locateVmByPrefix(prefix) {
  const pfx = String(prefix || "").toLowerCase();
  if (!pfx) return null;

  const a = archiveIndex()[pfx];
  if (a) {
    return {
      vmId: a.vmId || "",
      machineId: a.machineId || "",
      machineName: a.machineName || "",
      machineRegion: a.machineRegion || "",
      userEmail: String(a.userEmail || "").trim(),
      userId: a.userId || "",
      planId: a.planId || "",
      planName: a.planName || "",
      createdAt: toNum(a.createdAt, 0),
      expiresAt: toNum(a.expiresAt, 0),
      status: a.status || "",
      remark: a.remark || "",
      cpu: toNum(a.cpu, 0),
      ramMb: toNum(a.ramMb, 0),
      diskGb: toNum(a.diskGb, 0),
      trafficGb: toNum(a.trafficGb, 0),
      trafficUsedGb: toNum(a.trafficUsedGb, 0),
      price: toNum(a.price, 0),
      archived: true,
    };
  }

  const hit = vmIndex()[pfx];
  if (hit && hit.vm) {
    const v = hit.vm;
    const m = hit.machine;
    const p = hit.plan;
    return {
      vmId: v.vmId || "",
      machineId: m.id || "",
      machineName: m.name || ("机器#" + m.id),
      machineRegion: m.region || "",
      userEmail: String(v.email || "").trim(),
      userId: v.userId || "",
      planId: p && p.id || "",
      planName: p && p.name || "",
      createdAt: toNum(v.createdAt, 0),
      expiresAt: toNum(v.expiresAt, 0),
      status: v.status || "",
      remark: v.remark || "",
      cpu: toNum(v.cpu, 0),
      ramMb: toNum(v.ramMb, 0),
      diskGb: toNum(v.diskGb, 0),
      trafficGb: toNum(v.trafficGb, 0),
      trafficUsedGb: toNum(v.trafficUsedGb, 0),
      price: toNum(v.price, 0),
      autoRenew: toBool(v.autoRenew, false),
    };
  }
  return null;
}

// 按 VM 前缀定位买家：VM 明细 → 订单回退（订单 user_id 命中母鸡自身时忽略）
function locateBuyerByVmPrefix(prefix, orders, ownerIds) {
  const vm = locateVmByPrefix(prefix);
  if (vm && (vm.userEmail || vm.userId)) return { email: vm.userEmail || "", userId: vm.userId || "" };

  const pfx = String(prefix || "").toLowerCase();
  if (!pfx) return null;
  for (const o of orders || []) {
    if (!o || !o.vm_id) continue;
    if (String(o.vm_id).slice(0, 8).toLowerCase() !== pfx) continue;
    const ouid = String(o.user_id || "");
    if (!ouid || (ownerIds && ownerIds[ouid])) continue;
    return { email: "", userId: ouid };
  }
  return null;
}

// user_id → 邮箱映射（机器明细 + 归档）
function userIdToEmailMap() {
  const map = {};
  for (const m of machineDataList()) {
    for (const p of (m && m.plans) || []) {
      for (const v of (p && p.vms) || []) {
        if (v && v.userId && v.email) map[String(v.userId)] = String(v.email);
      }
    }
  }
  const arch = archiveMap();
  for (const k of Object.keys(arch)) {
    const a = arch[k];
    if (a && a.userId && a.userEmail && !map[String(a.userId)]) map[String(a.userId)] = String(a.userEmail);
  }
  return map;
}

// VM 归档：按 vm_id 键控记录最后一次见到的状态；按保留天数与条数上限清理
function archiveVmsFromScan(machine, plans, vms) {
  if (!toBool(S.config.archive_enabled, true)) return;
  if (!machine || !machine.id) return;

  const now = nowSec();
  let arch = S.state.vmArchive;
  if (!arch || typeof arch !== "object" || Array.isArray(arch)) arch = {};

  const planById = {};
  for (const p of plans || []) if (p && p.id) planById[p.id] = p;

  for (const vm of vms || []) {
    if (!vm || !vm.id) continue;
    const f = vmDetailFields(vm);
    const plan = planById[vm.plan_id] || null;
    arch[vm.id] = {
      vmId: f.vmId,
      machineId: machine.id,
      machineName: machine.name || ("机器#" + machine.id),
      machineRegion: machine.region || "",
      userEmail: f.email,
      userId: f.userId,
      planId: vm.plan_id || "",
      planName: plan ? (plan.name || "") : "",
      createdAt: f.createdAt,
      expiresAt: f.expiresAt,
      status: f.status,
      remark: f.remark,
      cpu: f.cpu,
      ramMb: f.ramMb,
      diskGb: f.diskGb,
      trafficGb: f.trafficGb,
      trafficUsedGb: f.trafficUsedGb,
      price: f.price,
      lastSeenAt: now,
    };
  }

  // 数量上限：删除最久未见的
  let keys = Object.keys(arch);
  if (keys.length > ARCHIVE_LIMIT) {
    keys.sort(function (a, b) {
      return toNum(arch[a] && arch[a].lastSeenAt, 0) - toNum(arch[b] && arch[b].lastSeenAt, 0);
    });
    for (let i = 0; i < keys.length - ARCHIVE_LIMIT; i++) delete arch[keys[i]];
  }
  // 保留天数
  const keepDays = Math.max(1, toNum(S.config.archive_keep_days, 90));
  const cutoff = now - keepDays * 86400;
  for (const k of Object.keys(arch)) {
    if (arch[k] && toNum(arch[k].lastSeenAt, 0) < cutoff) delete arch[k];
  }

  S.state.vmArchive = arch;
  archiveIndexCache = null;
}

// 机器 VM 单页拉取（失败重试 2 次，避免瞬时错误让 VM 从明细里静默消失）
async function fetchVmPageWithRetry(p) {
  return withRetry(function () { return apiThrottled(p); }, 3, 900);
}

// 套餐名缓存（machineId → {at, map}）：冷启动（尚未做过每日同步）时也能给出套餐名，
// 每个机器每小时最多拉一次套餐表，避免推送里「套餐」一栏只剩规格没有名称
const planNameCache = {};

async function planNamesFor(machineId) {
  const key = String(machineId || "");
  if (!key) return {};
  const hit = planNameCache[key];
  if (hit && Date.now() - hit.at < 3600 * 1000) return hit.map;

  const map = {};
  try {
    for (let p = 1; p <= 10; p++) {
      const d = await apiThrottled("/machines/" + key + "/plans?page=" + p + "&page_size=100");
      const rows = (d && d.plans) || [];
      for (const x of rows) if (x && x.id) map[x.id] = x.name || "";
      if (rows.length < 100) break;
    }
  } catch (e) {}
  planNameCache[key] = { at: Date.now(), map: map };
  return map;
}

// 机器概览：机器 + 全部套餐 + 全部 VM，结果持久化（每日同步一次）
async function getMachineInfo(force) {
  if (!force && S.machineInfoCache) return S.machineInfoCache;

  const machines = await fetchAllMachines();
  const out = [];

  for (const m of machines) {
    if (!m || !m.id) continue;

    // 套餐分页拉全
    let plans = [];
    try {
      const seen = {};
      for (let pp = 1; pp <= 200; pp++) {
        const pd = await apiThrottled("/machines/" + m.id + "/plans?page=" + pp + "&page_size=100");
        const pagePlans = (pd && pd.plans) || [];
        let added = 0;
        for (const p of pagePlans) {
          if (!p || !p.id || seen[p.id]) continue;
          seen[p.id] = true;
          plans.push(p);
          added++;
        }
        if (pagePlans.length < 100 || added === 0) break;
      }
    } catch (e) {}

    // VM 分页拉全
    let vms = [];
    try {
      const seen = {};
      for (let vp = 1; vp <= 500; vp++) {
        const vd = await fetchVmPageWithRetry("/machines/" + m.id + "/vms?page=" + vp + "&page_size=100");
        const pageVms = (vd && vd.vms) || [];
        let added = 0;
        for (const v of pageVms) {
          if (!v || (v.id && seen[v.id])) continue;
          if (v.id) seen[v.id] = true;
          vms.push(v);
          added++;
        }
        if (pageVms.length < 100 || added === 0) break;
      }
    } catch (e) {}

    try { archiveVmsFromScan(m, plans, vms); } catch (e) {}

    // 按套餐分组
    const vmsByPlan = {};
    for (const vm of vms) {
      if (!vm.plan_id) continue;
      if (!vmsByPlan[vm.plan_id]) vmsByPlan[vm.plan_id] = [];
      vmsByPlan[vm.plan_id].push(vmDetailFields(vm));
    }

    const planRows = [];
    for (const p of plans) {
      const max = toNum(p.max_quantity, 0);
      const sold = toNum(p.sold_quantity, 0);
      const buyers = vmsByPlan[p.id] || [];
      const row = {
        id: p.id,
        name: p.name || "",
        price: toNum(p.price_monthly, 0),
        cpu: toNum(p.cpu, 0),
        ramMb: toNum(p.ram_mb, 0),
        diskGb: toNum(p.disk_gb, 0),
        trafficGb: toNum(p.monthly_traffic_gb, 0),
        max: max,
        sold: sold,
        remaining: max > 0 ? Math.max(0, max - sold) : -1,
        unlimited: max === 0,
        soldOut: max > 0 && sold >= max,
        status: p.status || "",
        vms: buyers,
      };
      row.buyerCount = countPlanBuyers(row);
      planRows.push(row);
    }

    // 未匹配套餐的 VM（套餐已删除）归入「未知套餐」
    const planIds = {};
    for (const p of plans) planIds[p.id] = true;
    const orphanVms = vms.filter(function (vm) { return !planIds[vm.plan_id]; }).map(vmDetailFields);
    if (orphanVms.length) {
      const orphan = {
        id: "",
        name: "（已删除套餐的 VM）",
        price: 0,
        cpu: 0,
        ramMb: 0,
        diskGb: 0,
        trafficGb: 0,
        max: 0,
        sold: orphanVms.length,
        remaining: -1,
        unlimited: true,
        soldOut: false,
        status: "orphan",
        vms: orphanVms,
      };
      orphan.buyerCount = countPlanBuyers(orphan);
      planRows.push(orphan);
    }

    const active = planRows.filter(function (p) { return p.status === "active"; });
    let remainingTotal = 0;
    let hasUnlimited = false;
    for (const p of active) {
      if (p.unlimited) hasUnlimited = true;
      else remainingTotal += p.remaining;
    }

    out.push({
      id: m.id,
      name: m.name || ("机器#" + m.id),
      region: m.region || "",
      status: m.status || "",
      vmCount: toNum(m.vm_count, 0),
      estRevenue: toNum(m.est_revenue, 0),
      ramTotalMb: m.reported_specs ? toNum(m.reported_specs.ram_total_mb, 0) : 0,
      plans: planRows,
      activePlans: active.length,
      remainingTotal: hasUnlimited ? -1 : remainingTotal,
      soldOut: active.length > 0 && !hasUnlimited && remainingTotal === 0,
    });
  }

  S.machineInfoCache = out;
  S.machineInfoAt = Date.now();
  S.vmSnapshot = null;
  S.vmSnapshotAt = 0;
  invalidateMachineIndex();

  S.state.machineData = out;
  S.state.machineDataAt = S.machineInfoAt;
  saveCache();
  return out;
}

// 机器概览每日同步（启动补跑 / cron / 手动按钮共用）
async function runMachineSync(source) {
  if (!toBool(S.config.machine_sync_enabled, true)) return { ok: false, note: "disabled" };
  if (L.machineSync) return { ok: false, note: "busy" };
  L.machineSync = true;
  try {
    const info = await getMachineInfo(true);
    S.state.machineSyncDate = todayKey();
    saveState();
    console.log("[narwhal-finance] 机器同步完成(" + source + "): " + info.length + " 台");
    if (toBool(S.config.rank_enabled, true)) {
      try { await runRankUpdate("after-sync"); } catch (e) {}
    }
    return { ok: true, count: info.length };
  } catch (e) {
    S.lastError = "machine sync failed: " + e.message;
    return { ok: false, error: e.message };
  } finally {
    L.machineSync = false;
  }
}

/* ============================== 客户购买排行 ============================== */

function buildRankFromMachineData(md) {
  const agg = {};
  let total = 0;
  let totalMonthly = 0;

  for (const m of md) {
    for (const p of (m && m.plans) || []) {
      const planPrice = toNum(p.price, 0);
      for (const v of (p && p.vms) || []) {
        const price = toNum(v.price, 0) > 0 ? toNum(v.price, 0) : planPrice;
        const key = String(v.email || "").trim() || (v.userId ? "用户#" + v.userId : "未知客户");
        if (!agg[key]) agg[key] = { name: key, count: 0, amount: 0, vms: [] };
        agg[key].count += 1;
        agg[key].amount = round2(agg[key].amount + price);
        agg[key].vms.push({
          machineId: m.id,
          machineName: m.name || ("机器#" + m.id),
          machineRegion: m.region || "",
          vmId: v.vmId || "",
          planId: p.id || "",
          planName: p.name || "",
          price: price,
          status: v.status || "",
          expiresAt: toNum(v.expiresAt, 0),
          cpu: toNum(v.cpu, 0),
          ramMb: toNum(v.ramMb, 0),
          diskGb: toNum(v.diskGb, 0),
        });
        total += 1;
        totalMonthly = round2(totalMonthly + price);
      }
    }
  }
  return { agg: agg, total: total, totalMonthly: totalMonthly };
}

async function runRankUpdate(source) {
  if (!toBool(S.config.rank_enabled, true)) return { ok: false, note: "disabled" };
  if (L.rank) return { ok: false, note: "busy" };
  L.rank = true;
  try {
    const maxPages = Math.max(1, Math.min(500, toNum(S.config.rank_max_pages, 100)));
    const md = machineDataList();
    const useCache = md.length > 0;

    let agg = {};
    let total = 0;
    let totalMonthly = 0;
    let machineCount = 0;
    let failedMachines = 0;
    let bookCount = 0;

    if (useCache) {
      const r = buildRankFromMachineData(md);
      agg = r.agg;
      total = r.total;
      totalMonthly = r.totalMonthly;
      machineCount = md.length;
      for (const mm of md) bookCount += toNum(mm && mm.vmCount, 0);
      console.log("[narwhal-finance] 排行复用已同步数据(" + source + "): " + md.length + " 台机器");
    } else {
      const machines = await fetchAllMachines();
      machineCount = machines.length;
      for (const mm of machines) bookCount += toNum(mm && mm.vm_count, 0);

      for (const m of machines) {
        if (!m || !m.id) continue;
        try {
          const seen = {};
          for (let page = 1; page <= maxPages; page++) {
            const d = await apiThrottled("/machines/" + m.id + "/vms?page=" + page + "&page_size=100");
            const vms = (d && d.vms) || [];
            if (!vms.length) break;
            let added = 0;
            for (const vm of vms) {
              if (!vm || (vm.id && seen[vm.id])) continue;
              if (vm.id) seen[vm.id] = true;
              added++;
              const email = String(vm.user_email || "").trim();
              const key = email || (vm.user_id ? "用户#" + vm.user_id : "未知客户");
              if (!agg[key]) agg[key] = { name: key, count: 0, amount: 0, vms: [] };
              agg[key].count += 1;
              agg[key].amount = round2(agg[key].amount + toNum(vm.price_monthly, 0));
              agg[key].vms.push({
                machineId: m.id,
                machineName: m.name || ("机器#" + m.id),
                machineRegion: m.region || "",
                vmId: vm.id || "",
                planId: vm.plan_id || "",
                planName: "",
                price: toNum(vm.price_monthly, 0),
                status: vm.status || "",
                expiresAt: toNum(vm.expires_at, 0),
                cpu: toNum(vm.cpu, 0),
                ramMb: toNum(vm.ram_mb, 0),
                diskGb: toNum(vm.disk_gb, 0),
              });
              total += 1;
              totalMonthly = round2(totalMonthly + toNum(vm.price_monthly, 0));
            }
            if (vms.length < 100 || added === 0) break;
          }
        } catch (e) {
          failedMachines += 1;
        }
      }
    }

    const items = [];
    for (const k of Object.keys(agg)) items.push(agg[k]);
    items.sort(function (a, b) { return b.count - a.count || b.amount - a.amount; });

    S.state.rankData = {
      kind: "vm-owner",
      date: todayKey(),
      generatedAt: new Date().toISOString(),
      machineCount: machineCount,
      failedMachines: failedMachines,
      fromSyncedData: useCache,
      total: { count: total, amount: round2(totalMonthly) },
      bookCount: bookCount,
      missing: Math.max(0, bookCount - total),
      items: items,
    };
    saveCache();
    console.log("[narwhal-finance] 排行更新(" + source + "): " + total + " 个实例 / " + items.length + " 位客户");
    return { ok: true, total: total };
  } catch (e) {
    S.lastError = "rank failed: " + e.message;
    return { ok: false, error: e.message };
  } finally {
    L.rank = false;
  }
}

function buildRankText(rd) {
  const top = Math.max(1, toNum(S.config.rank_top, 10));
  const lines = ["🏆 客户购买实例排行（当前持有）"];
  for (const it of (rd.items || []).slice(0, top)) {
    lines.push("▸ " + it.name + " ×" + it.count + " · " + money(it.amount, false) + "/月");
  }
  lines.push("");
  lines.push("合计：" + rd.total.count + " 个实例 · " + money(rd.total.amount, false) + "/月" +
    (toNum(rd.missing, 0) > 0 ? "（账面 " + toNum(rd.bookCount, 0) + "，" + toNum(rd.missing, 0) + " 个待同步）" : ""));
  const gt = tsToLocal(Math.floor(new Date(rd.generatedAt).getTime() / 1000));
  lines.push("更新于 " + pad(gt.mo) + "-" + pad(gt.d) + " " + pad(gt.h) + ":" + pad(gt.mi) +
    "（每日 " + (S.config.machine_sync_time || "08:00") + " 随机器同步更新）");
  return lines.join("\n");
}

function buildRankSection() {
  const rd = S.state.rankData;
  if (!rd || !rd.items || !rd.items.length) return null;
  const top = Math.max(1, toNum(S.config.rank_top, 10));
  const lines = ["🏆 客户购买排行（当前持有）"];
  for (const it of (rd.items || []).slice(0, top)) {
    lines.push("▸ " + it.name + " ×" + it.count + " · " + money(it.amount, false) + "/月");
  }
  lines.push("📦 合计 " + rd.total.count + " 个实例 · " + money(rd.total.amount, false) + "/月");
  return lines;
}

/* ============================== 交易 → VM 定位 ============================== */

function txAlertTypeLabel(t) {
  const type = (t && t.type) || "";
  if (type === "escrow_in") return "托管入账";
  if (type === "escrow_renew") return "托管续费";
  if (type === "escrow_deduct") return "托管扣减";
  if (type === "withdrawal") return classifyWithdraw(t && t.note);
  return TYPE_LABEL[type] || type || "交易";
}

function txAlertTypeIcon(t) {
  const type = (t && t.type) || "";
  if (type === "escrow_in") return "📈";
  if (type === "escrow_renew") return "🔄";
  if (type === "escrow_deduct") return "📉";
  if (type === "withdrawal") return txAlertTypeLabel(t) === "提现完成" ? "✅" : "🏧";
  return "💸";
}

function renewDaysFromNote(note) {
  const ms = String(note || "").match(/(\d+)\s*days?\b/i);
  return ms ? toNum(ms[1], 0) : 0;
}

// 推送首行：▸ 📅 MM-DD HH:MM  📈 分类  ±金额 → 余额
function txAlertLine(t) {
  const lt = tsToLocal(toNum(t.created_at, 0));
  const bal = toNum(t.balance_after, 0);
  return "▸ 📅 " + pad(lt.mo) + "-" + pad(lt.d) + " " + pad(lt.h) + ":" + pad(lt.mi) +
    "  " + txAlertTypeIcon(t) + " " + txAlertTypeLabel(t) + "  " + money(toNum(t.amount, 0), true) +
    (bal > 0 ? " → " + money(bal, false) : "");
}

// 推送详情行：套餐名 / 规格 / 流量 / 退款 / 续费 / 到期 / 已用
function vmStatusLine(t, vm) {
  const parts = [];
  const type = (t && t.type) || "";
  if (vm.planName) parts.push("🏷️ " + vm.planName);
  if (toNum(vm.cpu, 0) > 0) parts.push("💻 " + vm.cpu + "c/" + toNum(vm.ramMb, 0) + "M/" + toNum(vm.diskGb, 0) + "G");
  const tg = toNum(vm.trafficGb, 0);
  parts.push(tg > 0 ? "📊 " + tg + "G 流量" : "📊 无限流量");

  const now = toNum(t.created_at, nowSec());
  const exp = toNum(vm.expiresAt, 0);
  const expLocal = exp > 0 ? tsToLocal(exp) : null;
  const dstr = expLocal ? "⏳ " + (type === "escrow_renew" ? "新到期" : "到期") + " " + pad(expLocal.mo) + "-" + pad(expLocal.d) : "";

  if (type === "escrow_deduct") {
    if (exp <= 0 || vm.planOnly) {
      parts.push("↩️ 已退款 · VM 已销毁");
    } else {
      if (vm.archived) parts.push("↩️ 已退款");
      parts.push("⏳ 剩余 " + Math.max(0, Math.floor((exp - now) / 86400)) + " 天");
      const used = toNum(vm.trafficUsedGb, 0);
      parts.push(tg > 0 ? "📉 已用 " + used + "/" + tg + " GB" : "📉 已用 " + used + " GB");
    }
  } else if (type === "escrow_renew") {
    const rd = renewDaysFromNote(t.note);
    if (rd > 0) parts.push("🔁 续费 " + rd + " 天");
    if (dstr) parts.push(dstr);
    if (vm.autoRenew) parts.push("🤖 自动");
  } else {
    if (dstr) parts.push(dstr);
    if (vm.autoRenew) parts.push("🤖 自动");
  }
  return "套餐：" + parts.join(" · ");
}

function isEscrowTx(t) {
  const type = (t && t.type) || "";
  return type === "escrow_in" || type === "escrow_renew" || type === "escrow_deduct";
}

// note 中的 VM ID 前 8 位（如 "VM refund deduction 2a625e65"）
function vmPrefixFromNote(note) {
  const ms = String(note || "").toLowerCase().match(/\b[0-9a-f]{8}\b/g);
  return ms && ms.length ? ms[ms.length - 1] : "";
}

// 交易 → 订单（时间窗 + 类型 + 同批去重）
function findOrderForTx(t, orders, usedOrderIds) {
  const ts = toNum(t.created_at, 0);
  const uid = String(t.user_id || "");
  let best = null;
  let bestDiff = Infinity;

  for (const o of orders) {
    if (!o || !o.vm_id) continue;
    if (usedOrderIds && o.id && usedOrderIds[String(o.id)]) continue;
    const allow = ORDER_TX_TYPES[o.type];
    if (!allow || allow.indexOf(t.type) < 0) continue;
    if (uid && String(o.user_id || "") !== uid) continue;
    const diff = Math.abs(toNum(o.created_at, 0) - ts);
    if (diff < bestDiff && diff <= 300) {
      bestDiff = diff;
      best = o;
    }
  }
  return best;
}

// note 前缀 → 订单（精确键控，不受 user_id 差异影响）
function findOrderByVmPrefix(t, orders) {
  const prefix = vmPrefixFromNote(t && t.note);
  if (!prefix) return null;
  const allow = TX_ORDER_TYPES[t.type] || [];
  let fallback = null;
  for (const o of orders) {
    if (!o || !o.vm_id) continue;
    if (String(o.vm_id).slice(0, 8).toLowerCase() !== prefix) continue;
    if (allow.indexOf(o.type) >= 0) return o;
    if (!fallback) fallback = o;
  }
  return fallback;
}

// 为交易匹配 VM（时间窗）：
//   托管扣减：按 VM 到期时间（≤1 小时）
//   入账/续费：按 VM 创建时间（≤30 分钟），失败再按到期时间兜底
function findVmForTxEx(tx, vms, excludeVmIds) {
  const ts = toNum(tx.created_at, 0);
  let best = null;
  let bestDiff = Infinity;

  const skip = function (v) {
    return excludeVmIds && v.vmId && excludeVmIds[String(v.vmId)];
  };

  if ((tx.type || "") === "escrow_deduct") {
    for (const v of vms) {
      if (skip(v)) continue;
      const diff = Math.abs(toNum(v.expiresAt, 0) - ts);
      if (diff < bestDiff) {
        bestDiff = diff;
        best = v;
      }
    }
    return best && bestDiff <= 3600 ? best : null;
  }

  for (const v of vms) {
    if (skip(v)) continue;
    const diff = Math.abs(toNum(v.createdAt, 0) - ts);
    if (diff < bestDiff) {
      bestDiff = diff;
      best = v;
    }
  }
  if (best && bestDiff <= 1800) return best;

  best = null;
  bestDiff = Infinity;
  for (const v of vms) {
    if (skip(v)) continue;
    const diff = Math.abs(toNum(v.expiresAt, 0) - ts);
    if (diff < bestDiff) {
      bestDiff = diff;
      best = v;
    }
  }
  return best && bestDiff <= 3600 ? best : null;
}

// 找出 VM 数量变化的机器（新购 VM 不在每日快照里）
async function findChangedMachines() {
  const fresh = await fetchAllMachines();
  const base = S.machineInfoCache && S.machineInfoCache.length ? S.machineInfoCache : null;
  const changed = [];
  for (const m of fresh) {
    if (!m || !m.id) continue;
    const snap = base ? base.find(function (x) { return x.id === m.id; }) : null;
    if (!snap || toNum(m.vm_count, -1) !== toNum(snap.vmCount, -2)) changed.push(m);
  }
  return changed;
}

// 拉指定机器最近的 VM（前 2 页）并转快照格式
async function fetchRecentVms(machine) {
  const out = [];
  const rawRows = [];
  const plansById = {};
  const snapM = S.machineInfoCache ? S.machineInfoCache.find(function (x) { return x.id === machine.id; }) : null;
  for (const p of (snapM && snapM.plans) || []) plansById[p.id] = p.name || "";
  // 无同步数据时（冷启动）补拉一次套餐表，保证推送能显示套餐名
  if (!Object.keys(plansById).length) {
    const fallback = await planNamesFor(machine.id);
    for (const k of Object.keys(fallback)) plansById[k] = fallback[k];
  }

  for (let page = 1; page <= 2; page++) {
    const d = await apiThrottled("/machines/" + machine.id + "/vms?page=" + page + "&page_size=100");
    const rows = (d && d.vms) || [];
    for (const vm of rows) {
      rawRows.push(vm);
      const f = vmDetailFields(vm);
      out.push({
        vmId: vm.id || "",
        machineId: machine.id,
        machineName: machine.name || ("机器#" + machine.id),
        machineRegion: machine.region || "",
        userEmail: f.email,
        userId: f.userId,
        planId: vm.plan_id || "",
        planName: plansById[vm.plan_id] || "",
        createdAt: f.createdAt,
        expiresAt: f.expiresAt,
        status: f.status,
        remark: f.remark,
        cpu: f.cpu,
        ramMb: f.ramMb,
        diskGb: f.diskGb,
        trafficGb: f.trafficGb,
        trafficUsedGb: f.trafficUsedGb,
        price: f.price,
        autoRenew: f.autoRenew,
      });
    }
    if (rows.length < 100) break;
  }

  try { archiveVmsFromScan(machine, (snapM && snapM.plans) || [], rawRows); } catch (e) {}
  return out;
}

// 订单 → VM 详情：机器 VM 列表 → 快照 → 归档 → 套餐级兜底
async function vmFromOrder(order, cache) {
  if (!order || !order.vm_id) return null;
  const ck = String(order.vm_id);
  if (cache && Object.prototype.hasOwnProperty.call(cache, ck)) return cache[ck];

  const fin = function (v) {
    if (cache) cache[ck] = v;
    return v;
  };

  const hit = planIndex()[String(order.plan_id)];
  const machineId = hit ? hit.machine.id : "";
  const machineName = hit ? (hit.machine.name || ("机器#" + hit.machine.id)) : "";
  const machineRegion = hit ? (hit.machine.region || "") : "";
  const planName = hit ? (hit.plan.name || "") : "";
  const planRow = hit ? hit.plan : null;

  if (machineId) {
    try {
      for (let page = 1; page <= 2; page++) {
        const d = await apiThrottled("/machines/" + machineId + "/vms?page=" + page + "&page_size=100");
        const rows = (d && d.vms) || [];
        try { archiveVmsFromScan({ id: machineId, name: machineName, region: machineRegion }, planRow ? [planRow] : [], rows); } catch (e) {}
        for (const vm of rows) {
          if (String(vm.id) !== String(order.vm_id)) continue;
          const f = vmDetailFields(vm);
          return fin({
            vmId: f.vmId,
            machineId: machineId,
            machineName: machineName,
            machineRegion: machineRegion,
            userEmail: f.email,
            userId: f.userId,
            planId: order.plan_id || "",
            planName: planName,
            createdAt: f.createdAt,
            expiresAt: f.expiresAt,
            status: f.status,
            remark: f.remark,
            cpu: f.cpu,
            ramMb: f.ramMb,
            diskGb: f.diskGb,
            trafficGb: f.trafficGb,
            trafficUsedGb: f.trafficUsedGb,
            autoRenew: f.autoRenew,
          });
        }
        if (rows.length < 100) break;
      }
    } catch (e) {}
  }

  try {
    for (const v of (await getVmSnapshot(false)) || []) {
      if (String(v.vmId) === String(order.vm_id)) return fin(v);
    }
  } catch (e) {}

  const archHit = archiveMap()[String(order.vm_id)];
  if (archHit) return fin(Object.assign({}, archHit, { archived: true }));

  if (machineId) {
    return fin({
      vmId: order.vm_id || "",
      machineId: machineId,
      machineName: machineName,
      machineRegion: machineRegion,
      userEmail: "",
      userId: order.user_id || "",
      planId: order.plan_id || "",
      planName: planName,
      createdAt: 0,
      expiresAt: 0,
      status: "gone",
      remark: "",
      cpu: planRow ? toNum(planRow.cpu, 0) : 0,
      ramMb: planRow ? toNum(planRow.ramMb, 0) : 0,
      diskGb: planRow ? toNum(planRow.diskGb, 0) : 0,
      trafficGb: planRow ? toNum(planRow.trafficGb, 0) : 0,
      trafficUsedGb: 0,
      price: planRow ? toNum(planRow.price, 0) : 0,
      planOnly: true,
    });
  }
  return fin(null);
}

// VM 快照（新交易机器定位用）：优先复用每日同步数据，0 次 API
async function getVmSnapshot(force) {
  if (!force && S.vmSnapshot && Date.now() - S.vmSnapshotAt < 300000) return S.vmSnapshot;

  const md = machineDataList();
  const vms = [];

  if (md.length) {
    for (const m of md) {
      for (const p of (m && m.plans) || []) {
        for (const v of (p && p.vms) || []) {
          vms.push({
            vmId: v.vmId || "",
            machineId: m.id,
            machineName: m.name || ("机器#" + m.id),
            machineRegion: m.region || "",
            userEmail: v.email || "",
            userId: v.userId,
            planId: p.id || "",
            planName: p.name || "",
            createdAt: v.createdAt,
            expiresAt: v.expiresAt,
            status: v.status || "",
            remark: v.remark || "",
            cpu: toNum(v.cpu, 0),
            ramMb: toNum(v.ramMb, 0),
            diskGb: toNum(v.diskGb, 0),
            trafficGb: toNum(v.trafficGb, 0),
            trafficUsedGb: toNum(v.trafficUsedGb, 0),
            price: toNum(v.price, 0),
            autoRenew: toBool(v.autoRenew, false),
          });
        }
      }
    }
  } else {
    const machines = await fetchAllMachines();
    for (const m of machines) {
      if (!m || !m.id) continue;
      try {
        // 冷启动补套餐名（机器很多时跳过，等每日同步补齐，避免一次性大量请求）
        const planNames = machines.length <= 30 ? await planNamesFor(m.id) : {};
        const planRows = Object.keys(planNames).map(function (id) { return { id: id, name: planNames[id] }; });
        const d = await apiThrottled("/machines/" + m.id + "/vms?page=1&page_size=100");
        const rows = (d && d.vms) || [];
        try { archiveVmsFromScan(m, planRows, rows); } catch (e) {}
        for (const vm of rows) {
          const f = vmDetailFields(vm);
          vms.push({
            vmId: f.vmId,
            machineId: m.id,
            machineName: m.name || ("机器#" + m.id),
            machineRegion: m.region || "",
            userEmail: f.email,
            userId: f.userId,
            planId: vm.plan_id || "",
            planName: planNames[vm.plan_id] || "",
            createdAt: f.createdAt,
            expiresAt: f.expiresAt,
            status: f.status,
            remark: f.remark,
            cpu: f.cpu,
            ramMb: f.ramMb,
            diskGb: f.diskGb,
            trafficGb: f.trafficGb,
            trafficUsedGb: f.trafficUsedGb,
            price: f.price,
            autoRenew: f.autoRenew,
          });
        }
      } catch (e) {}
    }
  }

  vms.sort(function (a, b) { return toNum(b.createdAt, 0) - toNum(a.createdAt, 0); });
  S.vmSnapshot = vms;
  S.vmSnapshotAt = Date.now();
  return vms;
}

// 交易明细行（日报「新交易」与实时推送共用格式）
async function buildTxDetailLines(show, vmOut, maxShow) {
  const lines = [];
  let vms = null;
  let orders = null;
  let changedVms = null;
  const orderVmCache = {};
  const usedOrderIds = {};
  const usedVmIds = {};

  if (show.some(isEscrowTx)) {
    try { orders = await fetchRecentOrders(); } catch (e) {}
    try { vms = await getVmSnapshot(false); } catch (e) {}
  }

  for (let i = 0; i < show.length; i++) {
    const t = show[i];
    const silent = maxShow != null && i >= maxShow;
    if (!silent) lines.push(txAlertLine(t));
    if (!isEscrowTx(t)) continue;

    let vm = null;

    // 1) 订单权威映射
    const order = findOrderByVmPrefix(t, orders || []) || findOrderForTx(t, orders || [], usedOrderIds);
    if (order) {
      usedOrderIds[String(order.id)] = true;
      try { vm = await vmFromOrder(order, orderVmCache); } catch (e) {}
    }

    // 2) note 前缀直接定位（退款销毁与新购主力路径）
    if (!vm) {
      try { vm = locateVmByPrefix(vmPrefixFromNote(t.note)); } catch (e) {}
    }

    // 3) 快照时间窗匹配
    if (!vm && vms) vm = findVmForTxEx(t, vms, usedVmIds);

    // 4) 机器数量变化兜底（刚购买的新 VM）
    if (!vm && vms) {
      if (changedVms === null) {
        changedVms = [];
        try {
          const changed = await findChangedMachines();
          for (const m of changed) {
            changedVms = changedVms.concat(await fetchRecentVms(m));
          }
        } catch (e) {
          changedVms = [];
        }
      }
      vm = findVmForTxEx(t, changedVms, usedVmIds);
    }

    if (vm) {
      if (vm.vmId) usedVmIds[String(vm.vmId)] = true;
      if (!silent) {
        lines.push("    🌐 " + vm.machineName);
        if (vm.userEmail) lines.push("   👤 用户邮箱：" + vm.userEmail);
        lines.push("   📦 " + vmStatusLine(t, vm));
      }
      if (vmOut) vmOut.push({ tx: t, vm: vm });
    } else if (!silent) {
      console.log("[narwhal-finance] 交易未定位到 VM（type=" + t.type + " tx=" + t.id + "）");
    }
  }
  return lines;
}

// 新交易推送文本
async function buildTxAlertLines(fresh, header, vmOut, opts) {
  const forceShow = !!(opts && opts.forceShow);
  const showLimit = toNum(S.config.tx_show_count, 10);
  const cap = Math.max(1, Math.min(50, showLimit > 0 ? showLimit : 50));
  const show = fresh.slice(0, cap);
  const maxShow = show.length ? (forceShow ? show.length : Math.min(show.length, showLimit > 0 ? showLimit : 0)) : 0;

  const lines = [header || ("💰 新交易 " + fresh.length + " 笔")];
  if (show.length) {
    const detail = await buildTxDetailLines(show, vmOut, maxShow);
    for (const line of detail) lines.push(line);
    if (maxShow > 0 && fresh.length > maxShow) lines.push("… 仅显示前 " + maxShow + " 笔");
  }
  return lines;
}

// 新交易涉及的机器即时刷新归档
async function refreshArchiveForFresh(txVms) {
  if (!toBool(S.config.archive_enabled, true)) return;
  const seen = {};
  const targets = [];
  for (const pair of txVms || []) {
    const vm = pair && pair.vm;
    const mid = vm && vm.machineId;
    if (!mid) continue;
    const k = String(mid);
    if (seen[k]) continue;
    seen[k] = true;
    targets.push({ id: mid, name: vm.machineName || "" });
    if (targets.length >= 10) break;
  }
  for (const m of targets) {
    try { await fetchRecentVms(m); } catch (e) {}
  }
}

// 套餐购买用户数（按邮箱 / uid 去重）
function countPlanBuyers(p) {
  const set = {};
  let n = 0;
  for (const v of (p && p.vms) || []) {
    const k = v.email || ("uid:" + v.userId);
    if (!set[k]) { set[k] = true; n++; }
  }
  return n;
}

// 新交易实时补丁：同步更新机器概览与客户排行（每日全量同步兜底纠偏）
function applyTxToCaches(fresh, txVms) {
  if (!Array.isArray(txVms) || !txVms.length) return;
  const md = (S.machineInfoCache && S.machineInfoCache.length) ? S.machineInfoCache : null;
  const rd = (S.state.rankData && Array.isArray(S.state.rankData.items)) ? S.state.rankData : null;

  const vmDetailFromCache = function (vm, planRow) {
    return {
      vmId: vm.vmId || "",
      email: String(vm.userEmail || "").trim(),
      userId: vm.userId || "",
      status: vm.status || "",
      remark: vm.remark || "",
      expiresAt: toNum(vm.expiresAt, 0),
      createdAt: toNum(vm.createdAt, 0),
      cpu: toNum(vm.cpu, 0),
      ramMb: toNum(vm.ramMb, 0),
      diskGb: toNum(vm.diskGb, 0),
      trafficGb: toNum(vm.trafficGb, 0),
      trafficUsedGb: toNum(vm.trafficUsedGb, 0),
      price: toNum(vm.price, 0) > 0 ? toNum(vm.price, 0) : toNum(planRow && planRow.price, 0),
      autoRenew: toBool(vm.autoRenew, false),
    };
  };

  for (const pair of txVms) {
    const t = pair && pair.tx;
    const vm = pair && pair.vm;
    if (!t || !vm || !vm.vmId) continue;

    const ty = t.type || "";
    if (ty !== "escrow_in" && ty !== "escrow_deduct" && ty !== "escrow_renew") continue;
    const isBuy = ty === "escrow_in";
    const isDestroy = ty === "escrow_deduct";

    const m = md ? md.find(function (x) { return String(x.id) === String(vm.machineId); }) : null;
    const p = m ? (m.plans || []).find(function (x) { return String(x.id) === String(vm.planId); }) : null;

    if (m && p) {
      if (isBuy) {
        m.vmCount = toNum(m.vmCount, 0) + 1;
        p.sold = toNum(p.sold, 0) + 1;
        if (toNum(p.max, 0) > 0) p.remaining = Math.max(0, toNum(p.remaining, 0) - 1);
        if (!(p.vms || []).some(function (v) { return String(v.vmId) === String(vm.vmId); })) {
          p.vms.push(vmDetailFromCache(vm, p));
        }
        p.buyerCount = countPlanBuyers(p);
      } else if (isDestroy) {
        m.vmCount = Math.max(0, toNum(m.vmCount, 0) - 1);
        p.sold = Math.max(0, toNum(p.sold, 0) - 1);
        if (toNum(p.max, 0) > 0) p.remaining = toNum(p.remaining, 0) + 1;
        p.vms = (p.vms || []).filter(function (v) { return String(v.vmId) !== String(vm.vmId); });
        p.buyerCount = countPlanBuyers(p);
      } else {
        for (const v of p.vms || []) {
          if (String(v.vmId) === String(vm.vmId)) {
            v.expiresAt = toNum(vm.expiresAt, v.expiresAt);
            if (toNum(vm.price, 0) > 0) v.price = toNum(vm.price, 0);
            v.status = vm.status || v.status;
          }
        }
      }
    }

    if (rd) {
      const email = String(vm.userEmail || "").trim();
      const key = email || (vm.userId ? "用户#" + vm.userId : "");
      if (key) {
        const price = toNum(vm.price, 0) > 0 ? toNum(vm.price, 0) : toNum(p && p.price, 0);
        let it = rd.items.find(function (x) { return x.name === key; });

        if (isBuy) {
          if (!it) {
            it = { name: key, count: 0, amount: 0, vms: [] };
            rd.items.push(it);
          }
          if (!(it.vms || []).some(function (v) { return String(v.vmId) === String(vm.vmId); })) {
            it.count += 1;
            it.amount = round2(it.amount + price);
            it.vms.push({
              machineId: vm.machineId || "",
              machineName: vm.machineName || "",
              machineRegion: vm.machineRegion || "",
              vmId: vm.vmId || "",
              planId: vm.planId || "",
              planName: vm.planName || "",
              price: price,
              status: vm.status || "",
              expiresAt: toNum(vm.expiresAt, 0),
              cpu: toNum(vm.cpu, 0),
              ramMb: toNum(vm.ramMb, 0),
              diskGb: toNum(vm.diskGb, 0),
            });
            rd.total.count = toNum(rd.total.count, 0) + 1;
            rd.total.amount = round2(toNum(rd.total.amount, 0) + price);
          }
        } else if (isDestroy && it) {
          const idx = (it.vms || []).findIndex(function (v) { return String(v.vmId) === String(vm.vmId); });
          if (idx >= 0) {
            const old = it.vms[idx];
            it.vms.splice(idx, 1);
            it.count = Math.max(0, it.count - 1);
            it.amount = round2(Math.max(0, it.amount - toNum(old && old.price, price)));
            if (!it.count) rd.items = rd.items.filter(function (x) { return x !== it; });
            rd.total.count = Math.max(0, toNum(rd.total.count, 0) - 1);
            rd.total.amount = round2(Math.max(0, toNum(rd.total.amount, 0) - toNum(old && old.price, price)));
          }
        } else if (ty === "escrow_renew" && it) {
          for (const v of it.vms || []) {
            if (String(v.vmId) === String(vm.vmId)) {
              const diff = toNum(vm.price, 0) - toNum(v.price, 0);
              if (toNum(vm.price, 0) > 0) {
                v.price = toNum(vm.price, 0);
                it.amount = round2(Math.max(0, it.amount + diff));
                rd.total.amount = round2(Math.max(0, toNum(rd.total.amount, 0) + diff));
              }
              v.expiresAt = toNum(vm.expiresAt, v.expiresAt);
              v.status = vm.status || v.status;
            }
          }
        }
      }
    }
  }

  // 缓存被就地修改，索引必须失效
  invalidateMachineIndex();
  S.vmSnapshot = null;
  S.vmSnapshotAt = 0;
}

// 新退款交易实时计入退款统计（与增量扫描共用水位，防重复）
function bumpRefundStatsRealtime(txVms) {
  if (!Array.isArray(txVms) || !txVms.length) return;
  const st = S.state;
  let stats = st.refundStats;
  if (!stats || typeof stats !== "object" || Array.isArray(stats)) stats = {};

  let maxTs = toNum(st.rfMaxTs, 0);
  let maxIds = Array.isArray(st.rfMaxIds) ? st.rfMaxIds.slice() : [];
  let maxIdMap = {};
  for (const id of maxIds) maxIdMap[id] = true;

  for (const pair of txVms) {
    const t = pair && pair.tx;
    if (!t) continue;
    const ty = t.type || "";
    if (ty !== "escrow_deduct" && ty !== "refund") continue;

    const ts = toNum(t.created_at, 0);
    if (ts < maxTs) continue;
    if (ts === maxTs && t.id && maxIdMap[t.id]) continue;

    const vm = pair.vm;
    const buyerKey = (vm && (vm.userEmail || vm.userId)) ? (vm.userEmail || ("用户#" + vm.userId)) : "__unknown__";
    if (!stats[buyerKey]) stats[buyerKey] = { count: 0, lastAt: 0 };
    stats[buyerKey].count += 1;
    if (ts > toNum(stats[buyerKey].lastAt, 0)) stats[buyerKey].lastAt = ts;

    if (ts > maxTs) {
      maxTs = ts;
      maxIds = [];
      maxIdMap = {};
    }
    if (ts === maxTs && t.id && !maxIdMap[t.id]) {
      maxIdMap[t.id] = true;
      maxIds.push(t.id);
    }
  }

  st.refundStats = stats;
  st.rfMaxTs = maxTs;
  st.rfMaxIds = maxIds.slice(0, 100);
}

/* ============================== 日报 ============================== */

async function buildReport(data) {
  const L2 = [];
  if (S.config.report_title) L2.push(String(S.config.report_title));

  L2.push("🖥️ 托管实例：" + data.instanceCount);
  L2.push("💰 预计月入：" + money(data.estMonthly, true));
  L2.push("🏦 累计提现：" + money(data.withdrawSum, true));
  L2.push("🔐 托管余额：" + balanceLine(data.escrow, data.yEscrow));
  L2.push("💳 账户余额：" + balanceLine(data.available, data.yAvailable));
  L2.push("🧊 冻结金额：" + balanceLine(data.locked, data.yLocked));
  L2.push("✅ 托管可用：" + balanceLine(data.availToWithdraw, data.yAvailWithdraw));
  L2.push("");
  L2.push("📈 今日入账：" + money(data.tin, true) + partsStr(data.inParts, false));
  L2.push("📉 今日扣减：" + money(-data.tout, true) + partsStr(data.outParts, true));
  L2.push("🧮 今日累计：" + money(data.net, true));

  if (toBool(S.config.rank_in_report, false)) {
    const sec = buildRankSection();
    if (sec) {
      L2.push("");
      for (const line of sec) L2.push(line);
    }
  }

  const showLimit = toNum(S.config.tx_show_count, 10);
  if (data.txs.length && showLimit > 0) {
    L2.push("");
    L2.push("💸 新交易 " + data.txs.length + " 笔");
    const show = data.txs.slice(0, showLimit);
    const detail = await buildTxDetailLines(show);
    for (const line of detail) L2.push(line);
    if (data.txs.length > show.length) L2.push("… 仅显示前 " + show.length + " 笔");
  }

  L2.push("");
  L2.push("⏰ " + nowStr());
  return L2.join("\n");
}

/* ============================== Telegram ============================== */

// 解析按钮配置："名称|链接"，多个用逗号 / 分号 / 换行分隔
function parseTgButtons() {
  const raw = String(S.config.tg_buttons || "").trim();
  if (!raw) return null;
  const row = [];
  for (const e of raw.split(/[,，;；\n]/)) {
    const seg = e.trim();
    if (!seg) continue;
    const idx = seg.indexOf("|");
    if (idx <= 0) continue;
    const text = seg.slice(0, idx).trim();
    const url = seg.slice(idx + 1).trim();
    if (text && /^https?:\/\//i.test(url)) row.push({ text: text, url: url });
  }
  return row.length ? [row] : null;
}

function hasTg() {
  return !!(S.config.tg_bot_token && S.config.tg_chat_id);
}

// 通用 Bot API 调用（429 / 5xx 自动重试）
async function tgApiCall(method, params) {
  const cfg = S.config;
  if (!cfg.tg_bot_token) throw new Error("未配置 tg_bot_token");
  const base = String(cfg.tg_api_base || "https://api.telegram.org").replace(/\/+$/, "");

  let lastErr = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    let r = null;
    try {
      r = await httpJson(base + "/bot" + cfg.tg_bot_token + "/" + method, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params || {}),
      });
    } catch (e) {
      lastErr = new Error("network: " + e.message);
      if (attempt < 2) { await sleep(1200 * (attempt + 1)); continue; }
      break;
    }
    if (r.res.ok && r.json && r.json.ok) return r.json.result;

    const desc = (r.json && r.json.description) || ("HTTP " + r.res.status);
    lastErr = new Error(desc);
    const retryAfter = toNum(r.json && r.json.parameters && r.json.parameters.retry_after, 0);
    if (r.res.status === 429 && attempt < 2) {
      await sleep(Math.min(30, Math.max(1, retryAfter || 2)) * 1000);
      continue;
    }
    if (r.res.status >= 500 && attempt < 2) {
      await sleep(1500 * (attempt + 1));
      continue;
    }
    break;
  }
  throw lastErr || new Error("telegram api failed");
}

// 长文本按行分片（单条 ≤ TG_TEXT_LIMIT，避免 4096 上限导致整条发送失败）
function splitText(text, limit) {
  const max = limit || TG_TEXT_LIMIT;
  const src = String(text || "");
  if (src.length <= max) return [src];

  const out = [];
  let buf = "";
  for (const line of src.split("\n")) {
    if (line.length > max) {
      if (buf) { out.push(buf); buf = ""; }
      for (let i = 0; i < line.length; i += max) out.push(line.slice(i, i + max));
      continue;
    }
    if (buf && (buf.length + 1 + line.length) > max) {
      out.push(buf);
      buf = line;
    } else {
      buf = buf ? buf + "\n" + line : line;
    }
  }
  if (buf) out.push(buf);
  return out;
}

// 发送消息（超长自动分片，按钮挂最后一片），返回最后一片的 message_id
async function tgSend(text, buttons) {
  if (!S.config.tg_bot_token) throw new Error("未配置 tg_bot_token");
  const chunks = splitText(text);
  let result = true;

  for (let i = 0; i < chunks.length; i++) {
    const isLast = i === chunks.length - 1;
    const body = {
      chat_id: S.config.tg_chat_id,
      text: chunks[i],
      disable_web_page_preview: true,
    };
    // 内联按钮：显式传入优先，否则用配置的通用按钮
    if (isLast) {
      if (buttons && buttons.length) {
        body.reply_markup = { inline_keyboard: buttons };
      } else if (toBool(S.config.tg_buttons_enabled, true)) {
        const btns = parseTgButtons();
        if (btns) body.reply_markup = { inline_keyboard: btns };
      }
    }
    result = await tgApiCall("sendMessage", body);
  }
  return result && typeof result === "object" ? toNum(result.message_id, 0) : true;
}

async function tgEditMessage(messageId, text) {
  return tgApiCall("editMessageText", {
    chat_id: S.config.tg_chat_id,
    message_id: messageId,
    text: String(text || "").slice(0, TG_TEXT_LIMIT),
  });
}

// 命令菜单
const TG_COMMANDS = [
  { command: "daily", description: "获取今日财务日报" },
  { command: "balance", description: "查询当前余额概况" },
  { command: "rank", description: "客户购买实例排行" },
  { command: "notify", description: "通知买家（主题|内容）" },
  { command: "status", description: "查看插件运行状态" },
  { command: "help", description: "使用帮助" },
];

async function tgRegisterCommands() {
  try {
    await tgApiCall("setMyCommands", { commands: TG_COMMANDS });
    return { ok: true, error: "" };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// 会话授权：主 Chat ID + 额外授权列表
function tgChatAllowed(chat) {
  if (!chat) return false;
  const raw = [String(S.config.tg_chat_id || "")].concat(String(S.config.tg_allowed_chats || "").split(/[,，]/));
  for (const r of raw) {
    const s = r.trim();
    if (!s) continue;
    if (s.charAt(0) === "@") {
      if (chat.username && ("@" + chat.username).toLowerCase() === s.toLowerCase()) return true;
    } else if (String(chat.id) === s) {
      return true;
    }
  }
  return false;
}

// 处理一条 TG 命令
async function tgHandleMessage(msg) {
  const chat = msg && msg.chat;
  if (!tgChatAllowed(chat)) return;

  const text = String(msg.text || "").trim();

  // 回复工单推送消息 → 作为工单回复提交
  if (msg.reply_to_message && text && text.charAt(0) !== "/") {
    const map = (S.state.tkMsgTicket && typeof S.state.tkMsgTicket === "object") ? S.state.tkMsgTicket : {};
    const tid = map[String(msg.reply_to_message.message_id)];
    if (tid) {
      try {
        await apiPost("/tickets/" + tid + "/messages", { content: text.slice(0, 2000) });
        try { await tgSend("✅ 已回复工单 " + String(tid).slice(0, 8)); } catch (e) {}
        pushLog("telegram", "工单回复", true);
      } catch (e) {
        try { await tgSend("❌ 回复工单失败：" + String(e.message).slice(0, 80)); } catch (e2) {}
        pushLog("telegram", "工单回复", false, e.message);
      }
      return;
    }
  }

  if (!text || text.charAt(0) !== "/") return;
  const cmd = text.split(/\s+/)[0].split("@")[0].toLowerCase();

  if (cmd === "/daily" || cmd === "/report") {
    if (L.report) { try { await tgSend("⏳ 正在处理其他任务，请稍后再试"); } catch (e) {} return; }
    L.report = true;
    try {
      const text2 = await generateReport();
      await tgSend(text2);
      pushLog("telegram", "TG命令 /daily", true);
    } catch (e) {
      S.lastError = "/daily failed: " + e.message;
      try { await tgSend("❌ 日报生成失败: " + e.message); } catch (e2) {}
      pushLog("telegram", "TG命令 /daily", false, e.message);
    } finally {
      L.report = false;
    }
    return;
  }

  if (cmd === "/balance") {
    if (L.poll) { try { await tgSend("⏳ 正在同步数据，请稍后再试"); } catch (e) {} return; }
    try {
      const data = await collectBalances(); // 轻量：不拉机器列表
      const lines = [
        "💰 独角鲸托管财务快报",
        "🔐 托管余额：" + currency() + abs2(data.escrow),
        "💳 账户余额：" + currency() + abs2(data.available),
        "🧊 冻结金额：" + currency() + abs2(data.locked),
        "✅ 托管可用：" + currency() + abs2(data.availToWithdraw),
        "🏦 累计提现：" + money(toNum(S.state.withdrawSum, 0), true),
        "📈 今日入账：" + money(data.tin, true) + partsStr(data.inParts, false),
        "📉 今日扣减：" + money(-data.tout, true) + partsStr(data.outParts, true),
        "🧮 今日累计：" + money(data.net, true),
      ];
      await tgSend(lines.join("\n"));
      pushLog("telegram", "TG命令 /balance", true);
    } catch (e) {
      S.lastError = "/balance failed: " + e.message;
      try { await tgSend("❌ 查询失败: " + e.message); } catch (e2) {}
      pushLog("telegram", "TG命令 /balance", false, e.message);
    }
    return;
  }

  if (cmd === "/rank") {
    const rd = S.state.rankData;
    if (!rd || !rd.items || !rd.items.length) {
      try { await tgSend("📊 暂无排行数据，正在后台生成，请稍后再查 /rank"); } catch (e) {}
      runRankUpdate("tg-rank");
      return;
    }
    try {
      await tgSend(buildRankText(rd));
      pushLog("telegram", "TG命令 /rank", true);
    } catch (e) {
      pushLog("telegram", "TG命令 /rank", false, e.message);
    }
    return;
  }

  if (cmd === "/status") {
    const lines = [
      "ℹ️ 独角鲸托管财务日报 - 运行状态",
      "版本：" + VERSION,
      "最近拉取：" + (S.lastCheck || "尚未执行"),
      "最近日报：" + (S.lastReport || "未发送"),
      "最近错误：" + (S.lastError || "无"),
      "托管实例：" + S.instanceCount + " · 预计月入：" + money(S.estMonthly, true),
      "日报时间：每天 " + (S.config.report_time || "21:00") +
        "（" + tzLabel() + "）",
    ];
    try { await tgSend(lines.join("\n")); } catch (e) { pushLog("telegram", "TG命令 /status", false, e.message); }
    return;
  }

  if (cmd === "/notify") {
    const raw = text.replace(/^\/notify(@\S+)?\s*/i, "").trim();
    if (!raw) {
      try {
        await tgSend([
          "📣 通知买家",
          "用法：/notify 主题|内容",
          "示例：/notify 国庆优惠|全场 8 折，欢迎续费",
          "",
          "说明：向所有机器的全部买家广播（每台机器 24 小时限 2 次，插件自动节流；机器多时需数分钟）",
        ].join("\n"));
      } catch (e) {}
      return;
    }

    let subject = "";
    let message = "";
    const sepIdx = raw.indexOf("|");
    if (sepIdx > 0) {
      subject = raw.slice(0, sepIdx).trim();
      message = raw.slice(sepIdx + 1).trim();
    } else {
      subject = raw.slice(0, 40);
      message = raw;
    }
    if (!message) { try { await tgSend("❌ 内容不能为空"); } catch (e) {} return; }
    subject = subject.slice(0, 200);
    message = message.slice(0, 2000);

    if (L.notifyBuyers) { try { await tgSend("⏳ 已有通知买家任务在执行，请稍后再试"); } catch (e) {} return; }
    L.notifyBuyers = true;
    try {
      await tgSend("📣 开始向所有买家广播…（主题：" + subject + "）");
      const res = await broadcastNotifyBuyers(subject, message);
      const lines = [
        "📣 通知买家完成",
        "主题：" + subject,
        "机器：" + res.ok + " 成功 / " + res.fail + " 失败（共 " + res.total + " 台）",
        "通知买家：" + res.notified + " 人",
      ];
      if (res.errors.length) lines.push("失败示例：" + res.errors.slice(0, 3).join("；"));
      await tgSend(lines.join("\n"));
      pushLog("telegram", "TG命令 /notify", true);
    } catch (e) {
      S.lastError = "/notify failed: " + e.message;
      try { await tgSend("❌ 通知买家失败：" + e.message); } catch (e2) {}
      pushLog("telegram", "TG命令 /notify", false, e.message);
    } finally {
      L.notifyBuyers = false;
    }
    return;
  }

  if (cmd === "/start" || cmd === "/help") {
    const help = [
      "🐳 独角鲸托管财务日报 Bot",
      "",
      "可用命令：",
      "/daily - 获取今日财务日报",
      "/balance - 查询当前余额概况",
      "/rank - 客户购买实例排行（每日 " + (S.config.machine_sync_time || "08:00") + " 全量同步 · 新交易实时更新）",
      "/notify - 通知买家（格式：/notify 主题|内容）",
      "/status - 查看插件运行状态",
      "/help - 显示本帮助",
      "",
      "日报每天 " + (S.config.report_time || "21:00") +
        "（" + tzLabel() + "）自动发送",
    ].join("\n");
    try { await tgSend(help); } catch (e) { pushLog("telegram", "TG命令 /help", false, e.message); }
    return;
  }
}

// 处理内联按钮回调（工单关闭 / 重新打开）
async function tgHandleCallback(cq) {
  if (!cq) return;
  const chat = cq.message && cq.message.chat;
  if (!tgChatAllowed(chat)) return;

  const data = String(cq.data || "");
  const msgId = cq.message ? cq.message.message_id : null;
  let answer = "";

  try {
    if (data.indexOf("tkclose:") === 0) {
      const tid = data.slice(8);
      await apiPut("/tickets/" + tid + "/close", {});
      answer = "✅ 工单已关闭";
      if (msgId) { try { await tgEditMessage(msgId, "🎫 工单已关闭（" + String(tid).slice(0, 8) + "）"); } catch (e) {} }
      pushLog("telegram", "工单按钮·关闭", true);
    } else if (data.indexOf("tkopen:") === 0) {
      const tid = data.slice(7);
      await apiPut("/tickets/" + tid + "/reopen", {});
      answer = "✅ 工单已重新打开";
      if (msgId) { try { await tgEditMessage(msgId, "🎫 工单已重新打开（" + String(tid).slice(0, 8) + "）"); } catch (e) {} }
      pushLog("telegram", "工单按钮·重新打开", true);
    } else {
      answer = "未知操作";
    }
  } catch (e) {
    answer = "❌ 操作失败：" + String(e.message).slice(0, 80);
    pushLog("telegram", "工单按钮", false, e.message);
  }

  try { await tgApiCall("answerCallbackQuery", { callback_query_id: cq.id, text: answer }); } catch (e) {}
}

/* ============================== 工单监听 ============================== */

function ticketStatusLabel(st) {
  return st === "open" ? "待处理" : st === "pending" ? "处理中" : st === "resolved" ? "已解决" : st === "closed" ? "已关闭" : (st || "-");
}

async function runTicketCheck() {
  if (!toBool(S.config.ticket_notify_enabled, true)) return;
  if (!hasTg()) return;
  if (L.ticket) return;
  L.ticket = true;

  try {
    let seen = S.state.tkSeenIds;
    if (!seen || typeof seen !== "object" || Array.isArray(seen)) seen = {};

    const d = await apiThrottled("/tickets?page=1&page_size=20");
    const tickets = (d && d.tickets) || [];
    const emailMap = userIdToEmailMap();

    for (const tk of tickets) {
      if (!tk || !tk.id || tk.status === "closed") continue;

      let detail = null;
      try { detail = await apiThrottled("/tickets/" + tk.id); } catch (e) { continue; }
      const msgs = (detail && detail.messages) || [];
      // 只推送买家/管理员的新消息，母鸡自己的回复不推送（避免自循环）
      const fresh = msgs.filter(function (m) { return m && m.id && !seen[m.id] && m.sender_role !== "host"; });
      if (!fresh.length) continue;
      for (const m of fresh) seen[m.id] = true; // 无论推送成败都标记，避免反复重推

      const buyerId = String(tk.user_id || "");
      const buyer = emailMap[buyerId] || ("用户#" + buyerId.slice(0, 8));
      const vm = detail && detail.vm;

      const lines = [
        "🎫 工单新消息",
        "标题：" + (tk.title || "-") + " · " + ticketStatusLabel(tk.status) + (tk.type === "withdrawal" ? " · 提现工单" : ""),
        "买家：" + buyer,
      ];
      if (vm) lines.push("VM：" + String(vm.id || "").slice(0, 8) + (vm.machine_name ? " · " + vm.machine_name : ""));
      lines.push("──────");
      for (const m of fresh.slice(-5)) {
        const who = m.sender_role === "admin" ? "管理员" : "买家";
        const lt = tsToLocal(toNum(m.created_at, 0));
        lines.push(who + "（" + pad(lt.mo) + "-" + pad(lt.d) + " " + pad(lt.h) + ":" + pad(lt.mi) + "）：" +
          String(m.content || "").slice(0, 500));
      }
      lines.push("──────");
      lines.push("提示：直接回复本条消息即可回复工单");

      const buttons = [[
        { text: "关闭工单", callback_data: "tkclose:" + tk.id },
        { text: "重新打开", callback_data: "tkopen:" + tk.id },
      ]];

      try {
        const sentId = await tgSend(lines.join("\n"), buttons);
        if (sentId && sentId !== true) {
          const map = (S.state.tkMsgTicket && typeof S.state.tkMsgTicket === "object") ? S.state.tkMsgTicket : {};
          map[String(sentId)] = tk.id;
          const keys = Object.keys(map);
          if (keys.length > 200) { for (const k of keys.slice(0, keys.length - 200)) delete map[k]; }
          S.state.tkMsgTicket = map;
        }
        pushLog("telegram", "工单推送", true);
      } catch (e) {
        pushLog("telegram", "工单推送", false, e.message);
      }
    }

    const seenKeys = Object.keys(seen);
    if (seenKeys.length > SEEN_KEEP) {
      const keep = {};
      for (const k of seenKeys.slice(seenKeys.length - SEEN_KEEP)) keep[k] = true;
      S.state.tkSeenIds = keep;
    } else {
      S.state.tkSeenIds = seen;
    }
    saveState();
  } catch (e) {
    S.lastError = "ticket check failed: " + e.message;
  } finally {
    L.ticket = false;
  }
}

/* ============================== 自动提现 ============================== */

async function runAutoWithdrawCheck() {
  const cfg = S.config;
  if (!toBool(cfg.auto_withdraw_enabled, false)) return;

  const threshold = toNum(cfg.auto_withdraw_threshold, 0);
  if (threshold <= 0) return;

  const st = S.state;
  const now = nowSec();
  const minInterval = Math.max(1, toNum(cfg.auto_withdraw_interval_hours, 24)) * 3600;
  if (toNum(st.awLastAt, 0) > 0 && now - toNum(st.awLastAt, 0) < minInterval) return;
  if (L.autoWithdraw) return;
  L.autoWithdraw = true;

  try {
    const info = await apiThrottled("/withdrawals/info");
    if (!info) return;
    const avail = toNum(info.available_to_withdraw, 0);
    if (avail < threshold) return;
    if (info.has_pending_request) {
      console.log("[narwhal-finance] 自动提现跳过：已有处理中的提现请求");
      return;
    }

    const cfgAmount = toNum(cfg.auto_withdraw_amount, 0);
    const amount = cfgAmount > 0 ? Math.min(cfgAmount, avail) : 0; // 0 = 全部可用
    const type = cfg.auto_withdraw_type === "transfer" ? "transfer" : "payout";
    const res = await apiPost("/withdrawals", { amount: amount, type: type });

    st.awLastAt = now;
    saveState();
    pushLog("telegram", "自动提现", true);

    if (toBool(cfg.auto_withdraw_notify, true)) {
      const lines = [
        "💰 自动提现已提交",
        "🔐 可用余额：" + money(avail, false),
        "🏧 提现申请：" + money(toNum(res && res.request_amount, amount || avail), false),
        "🧾 佣金：" + money(toNum(res && res.commission_amount, 0), false) +
          "（费率 " + (toNum(res && res.commission_rate, 0) * 100).toFixed(2) + "%）",
        "✅ 预计到账：" + money(toNum(res && res.payout_amount, 0), false),
        "📤 类型：" + (type === "payout" ? "外部提现" : "转可用余额") + " · 状态 " + ((res && res.status) || "pending") + "（待平台处理）",
      ];
      try { await tgSend(lines.join("\n")); } catch (e) {}
    }
  } catch (e) {
    S.lastError = "auto withdraw failed: " + e.message;
    pushLog("telegram", "自动提现", false, e.message);
    if (toBool(cfg.auto_withdraw_notify, true)) {
      try { await tgSend("⚠️ 自动提现失败：" + e.message); } catch (e2) {}
    }
  } finally {
    L.autoWithdraw = false;
  }
}

/* ============================== 通知买家 ============================== */

async function broadcastNotifyBuyers(subject, message) {
  const machines = await fetchAllMachines();
  const res = { total: machines.length, ok: 0, fail: 0, notified: 0, errors: [] };

  for (const m of machines) {
    if (!m || !m.id) continue;
    try {
      const d = await apiPostThrottled(
        "/machines/" + m.id + "/notify-buyers",
        { subject: subject, message: message },
        Math.max(6500, toNum(S.config.api_rate_ms, 250))
      );
      res.ok += 1;
      res.notified += toNum(d && d.notified, 0);
    } catch (e) {
      res.fail += 1;
      if (res.errors.length < 5) res.errors.push((m.name || m.id) + ": " + String(e.message).slice(0, 60));
    }
  }
  return res;
}

/* ============================== TG Webhook ============================== */

function genWebhookSecret() {
  try {
    const crypto = require("crypto");
    return crypto.randomBytes(16).toString("hex");
  } catch (e) {
    let s = "";
    for (let i = 0; i < 32; i++) s += Math.floor(Math.random() * 16).toString(16);
    return s;
  }
}

async function tgSetupWebhook() {
  const cfg = S.config;
  if (!cfg.tg_bot_token || !toBool(cfg.tg_cmd_enabled, true)) return { ok: false, error: "命令功能未启用" };
  if ((cfg.tg_cmd_mode || "webhook") !== "webhook") return { ok: false, error: "mode=poll" };

  const base = String(cfg.tg_webhook_base || S.state.autoWebhookBase || "").replace(/\/+$/, "");
  if (!base) return { ok: false, error: "尚未探测到面板域名（打开插件管理页后自动探测）" };
  if (!/^https:\/\//i.test(base)) return { ok: false, error: "Webhook 地址必须为 https:// 开头的公网地址" };

  if (!S.state.webhookSecret) {
    S.state.webhookSecret = genWebhookSecret();
    saveState();
  }

  const url = base + "/narwhal-finance/tg-webhook";
  try {
    await tgApiCall("setWebhook", {
      url: url,
      secret_token: S.state.webhookSecret,
      allowed_updates: ["message", "callback_query"], // 内联按钮回调必须订阅，否则按钮无响应
      drop_pending_updates: false,
    });
    return { ok: true, error: "", url: url };
  } catch (e) {
    return { ok: false, error: e.message, url: url };
  }
}

function detectWebhookBase(req) {
  try {
    const h = req.headers || {};
    const host = String(h["x-forwarded-host"] || h["host"] || "").trim();
    if (!host) return "";
    if (/^(localhost|127\.0\.0\.1|\[::1\])(:|\/|$)/i.test(host)) return "";
    const proto = String(h["x-forwarded-proto"] || "https").trim().toLowerCase();
    return proto + "://" + host;
  } catch (e) {
    return "";
  }
}

async function maybeAutoSetupWebhook(req) {
  const cfg = S.config;
  if (!cfg.tg_bot_token || !toBool(cfg.tg_cmd_enabled, true)) return;
  if ((cfg.tg_cmd_mode || "webhook") !== "webhook") return;
  if (S.tgWebhook && S.tgWebhook.ok) return;
  if (cfg.tg_webhook_base) return;

  const now = Date.now();
  if (S.webhookTryAt && now - S.webhookTryAt < 60000) return;
  S.webhookTryAt = now;

  const base = detectWebhookBase(req);
  if (!base) return;
  S.state.autoWebhookBase = base;
  saveState();
  S.tgWebhook = await tgSetupWebhook();
  if (S.tgWebhook.ok) console.log("[narwhal-finance] TG Webhook 自动注册成功: " + S.tgWebhook.url);
}

async function tgHandleWebhook(req) {
  const secret = S.state.webhookSecret || "";
  const header = (req.headers && (req.headers["x-telegram-bot-api-secret-token"] || req.headers["X-Telegram-Bot-Api-Secret-Token"])) || "";
  if (!secret || header !== secret) return; // 非法请求丢弃

  let j = null;
  try { j = JSON.parse(req.body || ""); } catch (e) { return; }
  if (!j || j.update_id === undefined) return;

  if (j.message) { try { await tgHandleMessage(j.message); } catch (e) {} }
  if (j.callback_query) { try { await tgHandleCallback(j.callback_query); } catch (e) {} }
}

async function tgPollUpdates() {
  const cfg = S.config;
  if (!cfg.tg_bot_token || !toBool(cfg.tg_cmd_enabled, true)) return;
  if (S.tgWebhook && S.tgWebhook.ok) return; // webhook 生效时不轮询
  if (L.tgPoll) return;
  L.tgPoll = true;

  try {
    const offset = toNum(S.state.tgUpdateOffset, 0);
    let result;
    try {
      result = await tgApiCall("getUpdates", { offset: offset, timeout: 0, limit: 50 });
    } catch (e) {
      const msg = String(e.message);
      if (msg.indexOf("webhook") >= 0 && !S.tgWebhookCleared) {
        S.tgWebhookCleared = true;
        try { await tgApiCall("deleteWebhook", { drop_pending_updates: false }); } catch (e2) {}
      } else if (msg.indexOf("terminated by other getUpdates") >= 0 && !S.tgConflictWarned) {
        S.tgConflictWarned = true;
        S.lastError = "TG getUpdates 冲突：有其他程序在用该 Bot Token 轮询";
      }
      return;
    }
    S.tgWebhookCleared = false;
    S.tgConflictWarned = false;
    if (!Array.isArray(result) || !result.length) return;

    let lastId = offset;
    for (const u of result) {
      lastId = Math.max(lastId, toNum(u.update_id, 0));
      if (u && u.message) { try { await tgHandleMessage(u.message); } catch (e) {} }
      if (u && u.callback_query) { try { await tgHandleCallback(u.callback_query); } catch (e) {} }
    }
    S.state.tgUpdateOffset = lastId + 1;
    saveState();
  } finally {
    L.tgPoll = false;
  }
}

/* ============================== 通知日志 ============================== */

function pushLog(channel, title, ok, error, isTest) {
  const keep = Math.max(1, Math.min(500, toNum(S.config.notify_log_keep, 30)));
  S.notifyLog.unshift({
    time: new Date().toISOString(),
    channel: channel,
    title: title,
    ok: ok,
    error: error || "",
    test: !!isTest,
  });
  if (S.notifyLog.length > keep) S.notifyLog.length = keep;
  S.state.notifyLog = S.notifyLog;
  saveState();
}

/* ============================== 数据采集 ============================== */

// 余额与昨日对比（含快照写入），供 collectData / collectBalances 共用
function resolveBalances(me, wi, txs) {
  const escrow = toNum(wi && wi.escrow_balance, toNum(me && me.escrow_balance, 0));
  const locked = toNum(wi && wi.locked_value, toNum(me && me.escrow_locked_value, 0));
  const availToWithdraw = toNum(wi && wi.available_to_withdraw, 0);
  const available = toNum(me && me.available_balance, 0);

  // 今日交易净额（按余额类型拆分）
  let escrowDelta = 0;
  let availableDelta = 0;
  for (const t of txs) {
    const amt = toNum(t.amount, 0);
    if (t.balance_type === "escrow") escrowDelta += amt;
    else if (t.balance_type === "available") availableDelta += amt;
  }

  const tKey = todayKey();
  const snaps = S.state.snapshots || {};
  const y = snaps[yesterdayKey()] || null;

  const yEscrow = y ? toNum(y.escrow, null) : round2(escrow - escrowDelta);
  const yAvailable = y ? toNum(y.available, null) : round2(available - availableDelta);
  const yLocked = y ? toNum(y.locked, null) : null;
  const yAvailToWithdraw = y ? toNum(y.availToWithdraw, null) : null;

  snaps[tKey] = {
    escrow: escrow,
    locked: locked,
    availToWithdraw: availToWithdraw,
    available: available,
    at: nowSec(),
  };
  // 清理 45 天前的快照
  const cutoff = nowSec() - 45 * 86400;
  for (const k of Object.keys(snaps)) {
    if (toNum(snaps[k] && snaps[k].at, 0) < cutoff) delete snaps[k];
  }
  S.state.snapshots = snaps;

  return {
    escrow: escrow,
    locked: locked,
    availToWithdraw: availToWithdraw,
    available: available,
    yEscrow: yEscrow,
    yAvailable: yAvailable,
    yLocked: yLocked,
    yAvailWithdraw: yAvailToWithdraw,
    tKey: tKey,
  };
}

function summarize(txs) {
  const d = buildDaily(txs);
  return { tin: d.tin, tout: d.tout, net: d.net, inParts: d.inParts, outParts: d.outParts };
}

// 全量采集（日报 / 轮询）
async function collectData(full) {
  const cfg = S.config;
  const me = await apiThrottled("/user/me");
  const wi = await apiThrottled("/withdrawals/info");
  const machines = await fetchAllMachines();
  const txs = await fetchTodayTxns();

  let withdrawSum = toNum(S.state.withdrawSum, 0);
  if (full) {
    try { withdrawSum = (await fetchWithdrawals()).sum; } catch (e) { S.lastError = "withdraw failed: " + e.message; }
    try { await fetchRefundStats(); } catch (e) {} // 退款统计随日报增量更新，失败不影响日报
  }

  const bal = resolveBalances(me, wi, txs);

  // 实例数与预计月入
  let instanceCount = 0;
  let estMonthly = 0;
  for (const m of machines) {
    instanceCount += toNum(m.vm_count, 0);
    estMonthly += toNum(m.est_revenue, 0);
  }
  if (instanceCount <= 0) instanceCount = machines.length;
  const mode = cfg.instance_count_mode || "auto";
  if (mode === "machines") instanceCount = machines.length;
  if (mode === "fixed") instanceCount = Math.max(0, toNum(cfg.instance_count_fixed, 0));

  return Object.assign({}, bal, summarize(txs), {
    instanceCount: instanceCount,
    estMonthly: round2(estMonthly),
    withdrawSum: round2(withdrawSum),
    txs: txs,
  });
}

// 轻量采集（/balance 命令：仅余额 + 今日交易，不拉机器列表）
async function collectBalances() {
  const me = await apiThrottled("/user/me");
  const wi = await apiThrottled("/withdrawals/info");
  const txs = await fetchTodayTxns();
  return Object.assign({}, resolveBalances(me, wi, txs), summarize(txs), { txs: txs });
}

// 同步当日交易水位，返回新增交易
function syncTxWatermark(txs) {
  const st = S.state;
  const known = st.lastTxIds || [];
  const knownMap = {};
  for (const id of known) knownMap[id] = true;

  const fresh = [];
  const ids = [];
  for (const t of txs) {
    if (t.id && !knownMap[t.id]) fresh.push(t);
    if (t.id) ids.push(t.id);
  }
  st.lastTxIds = ids.slice(0, 100);
  return fresh;
}

// 预览签名：数据没变就不重建日报文本（省掉每轮 VM 定位与 API 调用）
function previewSignature(data) {
  return [
    round2(data.escrow), round2(data.available), round2(data.locked), round2(data.availToWithdraw),
    round2(data.tin), round2(data.tout), round2(data.net),
    data.txs.length, data.instanceCount, round2(data.estMonthly), round2(data.withdrawSum),
  ].join("|");
}

/* ============================== 任务 ============================== */

async function generateReport() {
  const data = await collectData(true);
  const text = await buildReport(data);
  S.lastText = text;
  S.state.lastText = text;
  S.state.previewSig = previewSignature(data);
  syncTxWatermark(data.txs);
  saveState();
  return text;
}

// 发送日报：TG 失败不标记「今日已发」，稍后自动重试（最多 2 次）
async function runReport(source) {
  if (L.report) return { ok: false, note: "busy" };
  L.report = true;

  try {
    const text = await generateReport();
    let tgOk = false;
    let tgErr = "";

    if (hasTg()) {
      try {
        await tgSend(text);
        tgOk = true;
        pushLog("telegram", "每日日报", true);
      } catch (e) {
        tgErr = e.message;
        S.lastError = "tg send: " + e.message;
        pushLog("telegram", "每日日报", false, e.message);
      }
    } else {
      tgErr = "未配置 tg_bot_token / tg_chat_id";
      pushLog("telegram", "每日日报", false, tgErr);
    }

    if (tgOk || !hasTg()) {
      S.lastReport = new Date().toISOString();
      S.state.lastReportDate = todayKey();
      S.state.reportRetry = 0;
    } else {
      const tries = toNum(S.state.reportRetry, 0);
      if (tries < 2) {
        S.state.reportRetry = tries + 1;
        setTimeout(function () { runReport("retry"); }, 5 * 60 * 1000);
      }
    }
    saveState();

    console.log("[narwhal-finance] 日报完成(" + source + ") tg=" + tgOk);
    return { ok: true, tgOk: tgOk, tgErr: tgErr };
  } catch (e) {
    S.lastError = "report failed: " + e.message;
    return { ok: false, error: e.message };
  } finally {
    L.report = false;
  }
}

function applyCollected(data) {
  S.instanceCount = data.instanceCount;
  S.estMonthly = data.estMonthly;
  S.withdrawSum = data.withdrawSum;
  S.balances = {
    escrow: data.escrow,
    locked: data.locked,
    availToWithdraw: data.availToWithdraw,
    available: data.available,
    yEscrow: data.yEscrow,
    yAvailable: data.yAvailable,
    yLocked: data.yLocked,
    yAvailWithdraw: data.yAvailWithdraw,
  };
  S.inParts = data.inParts;
  S.outParts = data.outParts;
  S.todayIn = data.tin;
  S.todayOut = data.tout;
  S.todayNet = data.net;
  S.todayTxns = data.txs;
}

// 连续失败告警（只在连续第 3 次告警一次，避免刷屏）
function notePollResult(ok, err) {
  if (ok) {
    S.state.pollFailStreak = 0;
    return;
  }
  const n = toNum(S.state.pollFailStreak, 0) + 1;
  S.state.pollFailStreak = n;
  if (n === 3 && hasTg()) {
    tgSend("⚠️ 财务日报插件连续 3 次拉取失败\n" + String(err || "").slice(0, 300) + "\n请检查 API Key / 网络 / 限速设置")
      .catch(function () {});
  }
}

async function runPoll() {
  if (L.poll) return;
  L.poll = true;

  try {
    const data = await collectData(false);
    S.lastCheck = new Date().toISOString();
    applyCollected(data);

    // 新交易检测：首次只建立基线，不推送（基线持久化，重启不再重新基线）
    const fresh = syncTxWatermark(data.txs);
    const wasReady = !!S.alertsReady;
    if (!wasReady) {
      S.alertsReady = true;
      S.state.alertsReady = true;
      console.log("[narwhal-finance] 新交易水位基线建立，本次不推送 " + fresh.length + " 笔既有交易");
    }

    if (fresh.length) {
      // VM 定位与 TG 推送解耦：推送关闭或失败时，缓存补丁照常生效
      let lines = null;
      const txVms = [];
      try {
        lines = await buildTxAlertLines(fresh, null, txVms);
      } catch (e) {
        console.log("[narwhal-finance] 新交易明细生成失败: " + e.message);
      }
      try { applyTxToCaches(fresh, txVms); } catch (e) {
        console.log("[narwhal-finance] 实时缓存补丁失败: " + e.message);
      }
      try { bumpRefundStatsRealtime(txVms); } catch (e) {}
      try { await refreshArchiveForFresh(txVms); } catch (e) {}

      if (wasReady && lines && toBool(S.config.tx_alert_enabled, false)) {
        try {
          await tgSend(lines.join("\n"));
          pushLog("telegram", "新交易通知", true);
        } catch (e) {
          S.lastError = "新交易推送失败: " + e.message;
          pushLog("telegram", "新交易通知", false, e.message);
        }
      }
    }

    // 日报预览：仅在数据变化时重建（不发送、不标记已发）
    try {
      const sig = previewSignature(data);
      if (fresh.length || sig !== S.state.previewSig) {
        if (fresh.length) { try { await getVmSnapshot(true); } catch (e) {} }
        const preview = await buildReport(data);
        S.lastText = preview;
        S.state.lastText = preview;
        S.state.previewSig = sig;
      }
    } catch (e) {}

    try { await runAutoWithdrawCheck(); } catch (e) {}
    try { await runTicketCheck(); } catch (e) {}

    notePollResult(true);
    saveState();
  } catch (e) {
    S.lastError = "poll failed: " + e.message;
    notePollResult(false, e.message);
  } finally {
    L.poll = false;
  }
}

/* ============================== 定时调度 ============================== */

function applySchedules() {
  const cfg = S.config;
  const off = toNum(cfg.timezone_offset, 8);

  // 每日日报（按配置时区换算 UTC）
  server.cron(cronAtLocal(cfg.report_time || "21:00", off, 21), function () {
    runReportWithRetry("cron");
  });

  // 数据轮询
  const pm = Math.max(1, toNum(cfg.poll_minutes, 10));
  server.cron("@every " + pm + "m", function () { runPoll(); });

  // TG 命令轮询（webhook 生效时不实际工作）
  const ts = Math.max(5, Math.min(120, toNum(cfg.tg_poll_seconds, 30)));
  server.cron("@every " + ts + "s", function () { tgPollUpdates(); });

  // 机器概览与排行共用同步时间
  const syncExpr = cronAtLocal(cfg.machine_sync_time || "08:00", off, 8);
  if (toBool(cfg.machine_sync_enabled, true)) {
    server.cron(syncExpr, function () { runMachineSync("cron"); });
  } else if (toBool(cfg.rank_enabled, true)) {
    server.cron(syncExpr, function () { runRankUpdate("cron"); });
  }
}

// 定时日报若因其它任务占用而跳过，1 分钟后重试（最多 3 次），避免当天日报丢失
async function runReportWithRetry(source) {
  for (let i = 0; i < 3; i++) {
    const r = await runReport(source);
    if (!r || r.note !== "busy") return r;
    await sleep(60 * 1000);
  }
  return { ok: false, note: "busy" };
}

function shouldCatchUpReport() {
  const off = toNum(S.config.timezone_offset, 8);
  const t = parseHHMM(S.config.report_time || "21:00", 21, 0);
  const local = new Date((nowSec() + off * 3600) * 1000);
  const curMin = local.getUTCHours() * 60 + local.getUTCMinutes();
  return curMin >= t.h * 60 + t.m && S.state.lastReportDate !== todayKey();
}

/* ============================== 路由与生命周期 ============================== */

function isAdmin(req) {
  const p = req.context && req.context.principal;
  return !!(p && (p.type === "user" || p.type === "api_key" || (p.roles && p.roles.indexOf("admin") >= 0)));
}

function sendJson(res, obj, code) {
  res.statusCode = code || 200;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  res.end(JSON.stringify(obj));
}

function guard(handler) {
  return async function (req, res) {
    try {
      await handler(req, res);
    } catch (e) {
      S.lastError = e.message;
      try { sendJson(res, { status: "error", message: e.message }, 500); } catch (e2) {}
    }
  };
}

// 管理页交易流水用的 VM 摘要（同步、O(1) 索引查询，不触发 API）：
// 依次尝试 note 前缀 → VM 前缀索引 → 归档索引；取不到就返回 null（前端显示 —）
function txVmBrief(t) {
  const pfx = vmPrefixFromNote(t && t.note);
  let vm = null;
  if (pfx) {
    try { vm = locateVmByPrefix(pfx); } catch (e) { vm = null; }
  }
  if (!vm) return null;
  return {
    machineName: vm.machineName || "",
    machineRegion: vm.machineRegion || "",
    planName: vm.planName || "",
    cpu: toNum(vm.cpu, 0),
    ramMb: toNum(vm.ramMb, 0),
    diskGb: toNum(vm.diskGb, 0),
  };
}

function txBrief(t) {
  const vm = txVmBrief(t);
  return {
    id: t.id || "",
    type: t.type || "",
    label: txAlertTypeLabel(t),
    icon: txAlertTypeIcon(t),
    amount: toNum(t.amount, 0),
    balance_after: toNum(t.balance_after, 0),
    balance_type: t.balance_type || "",
    note: String(t.note || "").slice(0, 160),
    created_at: toNum(t.created_at, 0),
    machineName: vm ? vm.machineName : "",
    planName: vm ? vm.planName : "",
    cpu: vm ? vm.cpu : 0,
    ramMb: vm ? vm.ramMb : 0,
    diskGb: vm ? vm.diskGb : 0,
  };
}

function statusPayload() {
  const cfg = S.config || {};
  const arch = archiveMap();
  const stats = (S.state.refundStats && typeof S.state.refundStats === "object" && !Array.isArray(S.state.refundStats)) ? S.state.refundStats : {};

  let refundUsers = 0;
  let refundTotal = 0;
  let refundUnknown = 0;
  for (const k of Object.keys(stats)) {
    const c = toNum(stats[k] && stats[k].count, 0);
    if (k === "__unknown__") refundUnknown += c;
    else { refundUsers += 1; refundTotal += c; }
  }

  return {
    status: "success",
    version: VERSION,
    lastCheck: S.lastCheck,
    lastReport: S.lastReport,
    lastError: S.lastError,
    instanceCount: S.instanceCount,
    estMonthly: S.estMonthly,
    withdrawSum: toNum(S.state.withdrawSum, 0),
    balances: S.balances,
    todayIn: S.todayIn,
    todayOut: S.todayOut,
    todayNet: S.todayNet,
    inParts: S.inParts,
    outParts: S.outParts,
    todayCount: S.todayTxns ? S.todayTxns.length : 0,
    txns: (S.todayTxns || []).slice(0, 60).map(txBrief),
    lastText: S.lastText,
    notifyLog: S.notifyLog,
    tgMenu: S.tgCommands || null,
    tgWebhook: S.tgWebhook || null,
    rank: S.state.rankData || null,
    archive: {
      count: Object.keys(arch).length,
      enabled: toBool(cfg.archive_enabled, true),
      keepDays: Math.max(1, toNum(cfg.archive_keep_days, 90)),
    },
    refund: { users: refundUsers, refunds: refundTotal, unknown: refundUnknown },
    machineSync: {
      at: S.machineInfoAt ? new Date(S.machineInfoAt).toISOString() : null,
      date: S.state.machineSyncDate || "",
      count: S.machineInfoCache ? S.machineInfoCache.length : 0,
    },
    schedules: {
      reportTime: cfg.report_time || "21:00",
      pollMinutes: toNum(cfg.poll_minutes, 10),
      machineSyncTime: cfg.machine_sync_time || "08:00",
      tgPollSeconds: toNum(cfg.tg_poll_seconds, 30),
      nextReportAt: new Date(nextDailyAt(cfg.report_time || "21:00", toNum(cfg.timezone_offset, 8), 21)).toISOString(),
    },
    config: {
      api_base: cfg.api_base || "",
      api_key_set: !!(cfg.api_key && cfg.api_key.length),
      auth_email: cfg.auth_email || "",
      api_rate_ms: Math.max(50, Math.min(5000, toNum(cfg.api_rate_ms, 250))),
      tg_bot_token_set: !!(cfg.tg_bot_token && cfg.tg_bot_token.length),
      tg_chat_id: cfg.tg_chat_id || "",
      timezone_offset: cfg.timezone_offset,
      report_time: cfg.report_time || "21:00",
      report_title: cfg.report_title || "",
      poll_minutes: cfg.poll_minutes,
      tx_alert_enabled: !!cfg.tx_alert_enabled,
      tx_show_count: cfg.tx_show_count,
      tg_buttons: cfg.tg_buttons || "",
      tg_buttons_enabled: toBool(cfg.tg_buttons_enabled, true),
      tg_cmd_enabled: toBool(cfg.tg_cmd_enabled, true),
      tg_cmd_mode: cfg.tg_cmd_mode || "webhook",
      tg_webhook_base: cfg.tg_webhook_base || "",
      tg_allowed_chats: cfg.tg_allowed_chats || "",
      tg_poll_seconds: cfg.tg_poll_seconds,
      rank_enabled: toBool(cfg.rank_enabled, true),
      rank_top: cfg.rank_top,
      rank_in_report: toBool(cfg.rank_in_report, false),
      machine_sync_enabled: toBool(cfg.machine_sync_enabled, true),
      machine_sync_time: cfg.machine_sync_time || "08:00",
      notify_log_keep: toNum(cfg.notify_log_keep, 30),
      instance_count_mode: cfg.instance_count_mode || "auto",
      instance_count_fixed: cfg.instance_count_fixed,
      withdraw_max_pages: cfg.withdraw_max_pages,
      currency_symbol: cfg.currency_symbol || "$",
      archive_enabled: toBool(cfg.archive_enabled, true),
      archive_keep_days: Math.max(1, toNum(cfg.archive_keep_days, 90)),
      auto_withdraw_enabled: toBool(cfg.auto_withdraw_enabled, false),
      ticket_notify_enabled: toBool(cfg.ticket_notify_enabled, true),
    },
  };
}

async function load() {
  S.config = (await server.getConfig()) || {};
  loadStore();

  if (!S.state.snapshots) S.state.snapshots = {};
  if (!S.state.lastTxIds) S.state.lastTxIds = [];
  if (toBool(S.state.alertsReady, false)) S.alertsReady = true;
  if (S.state.lastText) S.lastText = S.state.lastText;

  if (Array.isArray(S.state.notifyLog) && S.state.notifyLog.length) {
    const keep = Math.max(1, Math.min(500, toNum(S.config.notify_log_keep, 30)));
    S.notifyLog = S.state.notifyLog.slice(0, keep);
  }
  if (Array.isArray(S.state.machineData) && S.state.machineData.length) {
    S.machineInfoCache = S.state.machineData;
    S.machineInfoAt = toNum(S.state.machineDataAt, 0);
  }

  let wdNeedRefresh = false;

  // ---- 算法版本迁移（保持旧数据的正确性） ----
  if (toNum(S.state.wdAlgo, 1) < 3) {
    console.log("[narwhal-finance] 累计提现算法升级(v3)，重置统计缓存");
    S.state.withdrawSum = 0;
    S.state.wdMaxTs = 0;
    S.state.wdMaxIds = [];
    S.state.wdAlgo = 3;
    wdNeedRefresh = true;
  }
  if (toNum(S.state.rankAlgo, 1) < 4) {
    console.log("[narwhal-finance] 排行算法升级(v4)，重置旧排行");
    S.state.rankData = null;
    S.state.rankAlgo = 4;
  }
  if (toNum(S.state.machineDataAlgo, 1) < 3) {
    console.log("[narwhal-finance] 机器概览升级(v3)：VM 明细补规格/流量，清空旧缓存");
    S.state.machineData = null;
    S.state.machineSyncDate = "";
    S.state.machineDataAlgo = 3;
    S.machineInfoCache = null;
    S.machineInfoAt = 0;
    S.vmSnapshot = null;
    S.vmSnapshotAt = 0;
  }
  if (toNum(S.state.rfAlgo, 1) < 2) {
    console.log("[narwhal-finance] 退款统计算法升级(v2)：按 VM 买家统计，重置并重扫");
    S.state.refundStats = {};
    S.state.rfMaxTs = 0;
    S.state.rfMaxIds = [];
    S.state.rfOwnerIds = [];
    S.state.rfAlgo = 2;
  }

  /* ---------------- 路由 ---------------- */

  // 机器概览 + 排行（默认读持久化，refresh=1 强制拉 API）
  server.route("GET", "/narwhal-finance/machines", guard(async function (req, res) {
    if (!isAdmin(req)) return sendJson(res, { status: "error", message: "forbidden" }, 403);
    const force = req.query && String(req.query.refresh || "") === "1";
    try {
      const info = await getMachineInfo(force);
      // 排行缺失或强制刷新后为空时，用刚同步的数据补算一次（0 次 API，纯内存聚合）
      if (toBool(S.config.rank_enabled, true) && (!S.state.rankData || (force && !S.state.rankData.items))) {
        try { await runRankUpdate("machines"); } catch (e) {}
      }
      sendJson(res, {
        status: "success",
        generatedAt: S.machineInfoAt ? new Date(S.machineInfoAt).toISOString() : null,
        machines: info,
        rank: S.state.rankData || null,
        config: {
          currency_symbol: S.config.currency_symbol || "",
          machine_sync_time: S.config.machine_sync_time || "08:00",
          machine_sync_enabled: toBool(S.config.machine_sync_enabled, true),
        },
      });
    } catch (e) {
      sendJson(res, { status: "error", message: e.message }, 502);
    }
  }));

  // 状态
  server.route("GET", "/narwhal-finance/status", function (req, res) {
    maybeAutoSetupWebhook(req); // 异步探测域名，不阻塞响应
    if (!isAdmin(req)) return sendJson(res, { status: "error", message: "forbidden" }, 403);
    sendJson(res, statusPayload());
  });

  // 立即发送日报
  server.route("POST", "/narwhal-finance/send-now", guard(async function (req, res) {
    if (!isAdmin(req)) return sendJson(res, { status: "error", message: "forbidden" }, 403);
    sendJson(res, await runReport("manual"));
  }));

  // 发送测试消息
  server.route("POST", "/narwhal-finance/test", guard(async function (req, res) {
    if (!isAdmin(req)) return sendJson(res, { status: "error", message: "forbidden" }, 403);
    const result = { ok: true, tg: null };
    try {
      await tgSend("✅ 测试消息：独角鲸托管财务日报插件通知渠道连通正常。");
      result.tg = { ok: true };
      pushLog("telegram", "测试通知", true, "", true);
    } catch (e) {
      result.tg = { ok: false, error: e.message };
      pushLog("telegram", "测试通知", false, e.message, true);
    }
    sendJson(res, result);
  }));

  // 测试通讯：发送最近一笔交易（按实时推送格式）
  server.route("POST", "/narwhal-finance/test-last", guard(async function (req, res) {
    if (!isAdmin(req)) return sendJson(res, { status: "error", message: "forbidden" }, 403);
    const result = { ok: true, tg: null, mode: "latest-tx" };
    try {
      let tx = null;
      if (Array.isArray(S.todayTxns) && S.todayTxns.length) tx = S.todayTxns[0];
      else tx = await fetchLastTx();

      if (!tx) {
        result.tg = { ok: false, error: "暂无任何交易记录，无法生成新交易通知" };
        pushLog("telegram", "测试通讯(新交易通知)", false, result.tg.error, true);
      } else {
        const text = (await buildTxAlertLines([tx], "💰 新交易通知（测试 · 最近 1 笔）", null, { forceShow: true })).join("\n");
        try {
          await tgSend(text);
          result.tg = { ok: true };
          result.preview = text.slice(0, 160);
          pushLog("telegram", "测试通讯(新交易通知)", true, "", true);
        } catch (e) {
          result.tg = { ok: false, error: e.message };
          pushLog("telegram", "测试通讯(新交易通知)", false, e.message, true);
        }
      }
    } catch (e) {
      result.tg = { ok: false, error: "生成新交易通知失败: " + e.message };
      pushLog("telegram", "测试通讯(新交易通知)", false, e.message, true);
    }
    sendJson(res, result);
  }));

  // VM 归档列表
  server.route("GET", "/narwhal-finance/archive", function (req, res) {
    if (!isAdmin(req)) return sendJson(res, { status: "error", message: "forbidden" }, 403);
    const arch = archiveMap();
    const list = Object.keys(arch).map(function (k) { return arch[k]; }).filter(Boolean);
    list.sort(function (a, b) { return toNum(b.lastSeenAt, 0) - toNum(a.lastSeenAt, 0); });
    sendJson(res, {
      status: "success",
      enabled: toBool(S.config.archive_enabled, true),
      count: list.length,
      keepDays: Math.max(1, toNum(S.config.archive_keep_days, 90)),
      archive: list,
    });
  });

  // 退款用户统计
  server.route("GET", "/narwhal-finance/refund-stats", function (req, res) {
    if (!isAdmin(req)) return sendJson(res, { status: "error", message: "forbidden" }, 403);
    const stats = (S.state.refundStats && typeof S.state.refundStats === "object" && !Array.isArray(S.state.refundStats)) ? S.state.refundStats : {};
    const emailMap = userIdToEmailMap();
    const items = [];
    let unknown = 0;

    for (const k of Object.keys(stats)) {
      const s = stats[k];
      const count = toNum(s && s.count, 0);
      const lastAt = toNum(s && s.lastAt, 0);
      if (k === "__unknown__") { unknown += count; continue; }
      const isEmail = k.indexOf("@") >= 0;
      items.push({ userId: isEmail ? "" : k, email: isEmail ? k : (emailMap[k] || ""), count: count, lastAt: lastAt });
    }
    items.sort(function (a, b) { return b.count - a.count || b.lastAt - a.lastAt; });

    let total = 0;
    for (const it of items) total += it.count;
    sendJson(res, { status: "success", users: items.length, refunds: total, unknown: unknown, items: items });
  });

  // 重置统计缓存
  server.route("POST", "/narwhal-finance/reset-cache", function (req, res) {
    if (!isAdmin(req)) return sendJson(res, { status: "error", message: "forbidden" }, 403);
    S.state.withdrawSum = 0;
    S.state.wdMaxTs = 0;
    S.state.wdMaxIds = [];
    S.state.refundStats = {};
    S.state.rfMaxTs = 0;
    S.state.rfMaxIds = [];
    S.state.rfOwnerIds = [];
    S.state.snapshots = {};
    S.state.previewSig = "";
    saveState();
    sendJson(res, { status: "success", message: "统计缓存已重置，累计提现与退款统计将在下次日报时重新统计" });
  });

  // 同步所有数据
  server.route("POST", "/narwhal-finance/sync-all", guard(async function (req, res) {
    if (!isAdmin(req)) return sendJson(res, { status: "error", message: "forbidden" }, 403);
    if (L.syncAll) return sendJson(res, { status: "error", message: "已有同步任务在执行，请稍候" }, 429);
    L.syncAll = true;

    const out = { status: "success", ok: true, machines: 0, rank: 0, archive: 0, refunds: 0, withdrawSum: 0, errors: [] };
    try {
      // ① 机器概览（内含归档写入；runMachineSync 结束后顺带更新排行）
      try {
        const r = await runMachineSync("admin-sync-all");
        if (r && r.ok) {
          out.machines = toNum(r.count, 0);
        } else {
          const info = await getMachineInfo(true);
          S.state.machineSyncDate = todayKey();
          out.machines = info.length;
          if (toBool(S.config.rank_enabled, true)) {
            try { await runRankUpdate("admin-sync-all"); } catch (e) { out.errors.push("rank: " + e.message); }
          }
          if (r && r.note === "disabled") out.note = "machine_sync_enabled=false，已按手动同步执行";
          if (r && r.note === "busy") out.note = "机器同步已在执行，本次直接复用当前数据";
        }
      } catch (e) {
        out.errors.push("machines: " + e.message);
      }

      // ② 退款统计
      try { await fetchRefundStats(); } catch (e) { out.errors.push("refunds: " + e.message); }

      // ③ 累计提现
      try {
        await fetchWithdrawals();
        S.withdrawSum = toNum(S.state.withdrawSum, 0);
        out.withdrawSum = round2(S.withdrawSum);
      } catch (e) {
        out.errors.push("withdraw: " + e.message);
      }

      out.rank = (S.state.rankData && Array.isArray(S.state.rankData.items)) ? S.state.rankData.items.length : 0;
      out.archive = Object.keys(archiveMap()).length;
      const st = (S.state.refundStats && typeof S.state.refundStats === "object") ? S.state.refundStats : {};
      out.refunds = Object.keys(st).reduce(function (sum, k) { return sum + (k === "__unknown__" ? 0 : toNum(st[k] && st[k].count, 0)); }, 0);
      if (out.errors.length) out.ok = false;
      saveState();
      sendJson(res, out);
    } finally {
      L.syncAll = false;
    }
  }));

  // TG Webhook（先回 200 再异步处理，避免 Telegram 重试）
  server.route("POST", "/narwhal-finance/tg-webhook", async function (req, res) {
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.end("ok");
    await tgHandleWebhook(req);
  });

  /* ---------------- RPC ---------------- */
  server.registerRPC("plugin:narwhalFinancePoll", function () {
    runPoll();
    return { ok: true, note: "poll scheduled in background" };
  });
  server.registerRPC("plugin:narwhalFinanceReport", function () {
    runReport("rpc");
    return { ok: true, note: "report scheduled in background" };
  });
  server.registerRPC("plugin:narwhalFinanceTgPoll", function () {
    tgPollUpdates();
    return { ok: true, note: "tg poll scheduled in background" };
  });
  server.registerRPC("plugin:narwhalFinanceRank", function () {
    runRankUpdate("rpc");
    return { ok: true, note: "rank update scheduled in background" };
  });

  applySchedules();

  // 注册 TG 命令菜单
  if (S.config.tg_bot_token && toBool(S.config.tg_cmd_enabled, true)) {
    S.tgCommands = await tgRegisterCommands();
    if (S.tgCommands.ok) console.log("[narwhal-finance] TG 命令菜单已注册");
    else console.log("[narwhal-finance] TG 命令菜单注册失败: " + S.tgCommands.error);
  } else {
    S.tgCommands = { ok: false, error: toBool(S.config.tg_cmd_enabled, true) ? "未配置 tg_bot_token" : "未启用命令菜单" };
  }

  // Webhook：配置地址优先，留空则等管理页探测
  S.tgWebhook = await tgSetupWebhook();
  if (S.tgWebhook.ok) {
    console.log("[narwhal-finance] TG Webhook 已启用: " + S.tgWebhook.url);
  } else if ((S.config.tg_cmd_mode || "webhook") === "webhook" &&
    S.tgWebhook.error !== "mode=poll" && S.tgWebhook.error !== "命令功能未启用") {
    console.log("[narwhal-finance] TG Webhook 不可用(" + S.tgWebhook.error + ")，回退轮询");
  }

  // 启动补跑：排行 / 机器同步 / 提现缓存 / 退款统计
  if (toBool(S.config.rank_enabled, true)) {
    const rd = S.state.rankData;
    if (!rd || rd.date !== todayKey()) {
      setTimeout(function () {
        if (L.machineSync) return; // 同步完成后 after-sync 会更新排行
        runRankUpdate("catchup");
      }, 15000);
    }
  }

  if (toBool(S.config.machine_sync_enabled, true) && S.state.machineSyncDate !== todayKey()) {
    setTimeout(function () { runMachineSync("catchup"); }, 12000);
  }

  if (wdNeedRefresh || toNum(S.state.wdMaxTs, 0) === 0) {
    setTimeout(function () {
      if (L.withdraw) return;
      L.withdraw = true;
      fetchWithdrawals().then(function () {
        S.withdrawSum = toNum(S.state.withdrawSum, 0);
        saveState();
        console.log("[narwhal-finance] 累计提现缓存已刷新: " + S.withdrawSum);
      }).catch(function (e) {
        S.lastError = "withdraw refresh failed: " + e.message;
      }).then(function () { L.withdraw = false; });
    }, 8000);
  }

  if (toNum(S.state.rfMaxTs, 0) === 0) {
    setTimeout(function () {
      if (L.refund) return;
      L.refund = true;
      fetchRefundStats().then(function () {
        saveState();
        console.log("[narwhal-finance] 退款统计已预扫");
      }).catch(function (e) {
        S.lastError = "refund stats failed: " + e.message;
      }).then(function () { L.refund = false; });
    }, 9000);
  }

  // 启动后立即拉一次（静默）
  setTimeout(function () {
    runPoll();
    if (shouldCatchUpReport()) {
      setTimeout(function () { runReport("catchup"); }, 3000);
    }
  }, 1500);

  console.log(
    "[narwhal-finance] v" + VERSION + " loaded, report at " + (S.config.report_time || "21:00") +
    " (" + tzLabel() + ")" +
    ", poll every " + (S.config.poll_minutes || 10) + "m"
  );
}

async function unload() {
  if (S.tgWebhook && S.tgWebhook.ok && S.config && S.config.tg_bot_token) {
    try { await tgApiCall("deleteWebhook", { drop_pending_updates: false }); } catch (e) {}
  }
  dirtyLight = true;
  dirtyHeavy = true;
  flushSave();
  console.log("[narwhal-finance] unloaded");
}
