// 流量月重置日管理 — Komari 插件
//
// 功能：在面板管理页集中查看、批量修改每个节点：
//   1) Agent 的「网络统计月重置日」(--month-rotate 参数，agent 侧配置)；
//   2) 面板节点的「流量阈值」(traffic_limit，字节) 与「统计方式」
//      (traffic_limit_type: sum/max/min/up/down，面板原生字段，admin:editClient)。
//
// 原理：月重置日保存在节点服务器的 agent 服务定义（systemd unit 的 ExecStart）中，
//       面板 API 文档没有提供直接修改接口；本插件通过面板自身的远程任务系统
//       (admin:exec -> agent 以 sh -s 执行下发脚本) 完成以下动作：
//         1) 探测：按节点 Client Token 精确定位该节点的 agent 服务文件与运行进程，
//            解析出当前生效的月重置日；
//         2) 应用：备份 unit 文件 -> 改写 ExecStart 中的 --month-rotate ->
//            daemon-reload -> 延迟 3 秒重启 agent（延迟是为了让任务结果先回传）。
//       流量阈值/统计方式是面板节点字段，直接走 admin:editClient 部分更新，即时生效。
//
// 值语义：月重置日 0 = 禁用（上报网卡累计总量）；1-31 = 每月 N 日 0 点重置，
//         该月没有 N 日时自动顺延到下月 1 日（agent 侧 GetLastResetDate 行为）。
//         流量阈值 0 = 不显示进度条；单位换算遵循 Komari 规则（1024 进制，
//         formatBytes：B/KB/MB/GB/TB/PB，满 1024 进位，即 ≥1024G 显示为 T）。

const server = require("server");
const fs = require("fs");
const path = require("path");

/* ---------------- 运行状态 ---------------- */

const S = {
  probes: {},   // uuid -> 最近一次探测解析结果
  tasks: {},    // task_id -> { kind:'detect'|'apply', uuid, day, startedAt, result, done }
  tokens: {},   // uuid -> client token 缓存
  history: [],  // 应用历史 [{time, uuid, name, from, to, ok, note}]
  nodesCache: null,
  nodesCacheAt: 0,
};

const TASK_TIMEOUT_MS = 90 * 1000;   // 任务无结果视为超时
const TASK_KEEP_MS = 10 * 60 * 1000; // 已完成任务保留 10 分钟，之后回收（防 S.tasks 无限增长）
const HISTORY_KEEP = 100;
const HISTORY_RETURN = 30;           // status 只回吐最近 30 条历史
const DISPATCH_CONCURRENCY = 4;      // 并发下发上限（SQLite 单写锁，过高会撞库锁）
const SAVE_DEBOUNCE_MS = 1000;       // 状态落盘防抖
const TOKEN_RE = /^[A-Za-z0-9_-]{8,128}$/; // client token 安全字符集

// Komari 流量统计方式（traffic_limit_type）合法值，语义与面板状态页一致：
//   sum=(上传+下载)/阈值  max=max(上,下)/阈值  min=min(上,下)/阈值
//   up=上传/阈值  down=下载/阈值
const LIMIT_TYPES = ["sum", "max", "min", "up", "down"];
// 流量阈值上限（字节）：1 EiB，防止 int64 溢出；Komari 前端最大支持 PB 级输入
const MAX_LIMIT_BYTES = Math.pow(2, 60);

/* ---------------- 基础工具 ---------------- */

function toNum(v, def) {
  const n = Number(v);
  return isFinite(n) ? n : def;
}

function nowIso() {
  return new Date().toISOString();
}

function jsonReply(res, obj, code) {
  res.statusCode = code || 200;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.end(JSON.stringify(obj));
}

function isAdmin(req) {
  const p = req.context && req.context.principal;
  return !!(p && (p.type === "user" || p.type === "api_key" || (p.roles && p.roles.indexOf("admin") >= 0)));
}

function parseBody(req) {
  try {
    return JSON.parse(req.body || "{}");
  } catch (e) {
    return {};
  }
}

async function rpc(method, params) {
  return await server.call(method, params);
}

// 限定并发的 map。用于批量下发：56 个节点串行 RPC 要好几秒，
// 但并发过高会撞 SQLite 的写锁，所以取一个折中值。
async function mapLimit(items, limit, fn) {
  const list = items || [];
  const out = new Array(list.length);
  if (!list.length) return out;
  let cursor = 0;
  const workerCount = Math.min(Math.max(1, limit | 0), list.length);
  const workers = [];
  for (let w = 0; w < workerCount; w++) {
    workers.push((async function () {
      for (;;) {
        const idx = cursor++;
        if (idx >= list.length) return;
        try {
          out[idx] = await fn(list[idx], idx);
        } catch (e) {
          out[idx] = { error: e };
        }
      }
    })());
  }
  await Promise.all(workers);
  return out;
}

/* ---------------- shell 脚本生成 ---------------- */

// 生成探测脚本：在目标节点上执行，输出 KMRD 标记的结构化文本。
// 用 Client Token 精确定位本面板对应的 agent（一台机器可能跑多个面板的 agent）。
// 环境分类：systemd / container（Docker 等容器，改不了宿主启动参数）/ nosystemd。
// unit 搜索覆盖系统级与用户级（--run-as-user 安装时 unit 在 ~/.config/systemd/user/）。
// 通过运行中的 agent 进程反查它所属的 systemd unit。
// 用于 --auto-discovery 启动的 Agent：unit 文件里没有 Token 字符串，按 Token
// 搜不到，但进程的 cgroup / systemd 归属是确定的。
// 输出变量：CUR_UNIT（unit 名，如 komari-agent.service）、FP（unit 文件路径）
function pidUnitLines() {
  return [
    "AGENT_PID=$PPID",
    "CUR_UNIT=",
    "if command -v systemctl >/dev/null 2>&1; then",
    "  CUR_UNIT=$(systemctl show -p Id --value \"$AGENT_PID\" 2>/dev/null | tr -d ' ')",
    "  case \"$CUR_UNIT\" in *.service) ;; *) CUR_UNIT= ;; esac",
    "fi",
    "if [ -z \"$CUR_UNIT\" ] && [ -r \"/proc/$AGENT_PID/cgroup\" ]; then",
    "  CUR_UNIT=$(sed -n 's#.*/\\([^/]*\\.service\\)$#\\1#p' \"/proc/$AGENT_PID/cgroup\" | head -1)",
    "fi",
    "FP=",
    "if [ -n \"$CUR_UNIT\" ]; then",
    "  FP=$(systemctl show -p FragmentPath --value \"$CUR_UNIT\" 2>/dev/null | tr -d ' ')",
    "fi",
  ];
}

// 按 Client Token 在 systemd unit 文件里搜索，命中则置 UF=文件路径。
// 覆盖：系统级(/etc) -> 发行版级(/usr/lib、/lib) -> 用户级(~/.config/systemd/user)。
// detect / apply 共用，避免同一段 shell 在多处逐字重复。
function tokenUnitSearchLines() {
  return [
    "UF=",
    "for u in /etc/systemd/system/*.service; do",
    "  [ -f \"$u\" ] || continue",
    "  if grep -qF \"$TOKEN\" \"$u\" 2>/dev/null; then UF=\"$u\"; break; fi",
    "done",
    "if [ -z \"$UF\" ]; then",
    "  for u in /usr/lib/systemd/system/*.service /lib/systemd/system/*.service; do",
    "    [ -f \"$u\" ] || continue",
    "    if grep -qF \"$TOKEN\" \"$u\" 2>/dev/null; then UF=\"$u\"; break; fi",
    "  done",
    "fi",
    "if [ -z \"$UF\" ]; then",
    "  for u in /etc/systemd/user/*.service \"$HOME\"/.config/systemd/user/*.service; do",
    "    [ -f \"$u\" ] || continue",
    "    if grep -qF \"$TOKEN\" \"$u\" 2>/dev/null; then UF=\"$u\"; break; fi",
    "  done",
    "fi",
  ];
}

function detectScript(token) {
  return [
    "echo KMRD BEGIN",
    "TOKEN=" + shellQuote(token),
    "if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then",
    "  echo INIT=systemd",
    "elif [ -f /.dockerenv ] || grep -qiE 'docker|containerd|kubepods|lxc' /proc/1/cgroup 2>/dev/null; then",
    "  echo INIT=container",
    "else",
    "  echo INIT=nosystemd",
    "fi",
  ].concat(tokenUnitSearchLines()).concat(pidUnitLines()).concat([
    // 按 Token 搜不到（典型：--auto-discovery 启动）时，用运行进程反查所属 unit
    "if [ -z \"$UF\" ] && [ -n \"$FP\" ] && [ -f \"$FP\" ]; then UF=\"$FP\"; echo UNIT_SRC=process; fi",
    "if [ -n \"$UF\" ]; then",
    "  echo UNIT_FILE=$UF",
    "  grep -m1 '^ExecStart=' \"$UF\"",
    "  grep '^Environment=' \"$UF\" 2>/dev/null | grep -i 'MONTH_ROTATE' | head -1",
    "  SV=$(basename \"$UF\")",
    "  if echo \"$UF\" | grep -q '/systemd/user/'; then",
    "    echo SVC_ACTIVE=$(systemctl --user is-active \"$SV\" 2>/dev/null)",
    "  else",
    "    echo SVC_ACTIVE=$(systemctl is-active \"$SV\" 2>/dev/null)",
    "  fi",
    "  EXEC=$(grep -m1 '^ExecStart=' \"$UF\" | sed 's/^ExecStart=//')",
    "  CFG=$(echo \"$EXEC\" | sed -n 's/.*--config[= ][ ]\\{1,\\}\\([^ ]*\\).*/\\1/p')",
    "  if [ -n \"$CFG\" ] && [ -f \"$CFG\" ]; then",
    "    echo CONFIG_FILE=$CFG",
    "    sed -n 's/.*\"month_rotate\"[: ]*\\([0-9]\\{1,\\}\\).*/CONFIG_ROT=\\1/p' \"$CFG\" | head -1",
    "  fi",
    "else",
    "  echo UNIT_FILE=none",
    "  for u in /etc/systemd/system/*.service; do",
    "    [ -f \"$u\" ] || continue",
    "    grep -qi komari \"$u\" 2>/dev/null && echo CAND=$u",
    "  done",
    "fi",
    "PS=",
    "if [ -r \"/proc/$PPID/cmdline\" ]; then",
    "  PS=$(tr '\\000' ' ' < /proc/$PPID/cmdline 2>/dev/null)",
    "fi",
    "if [ -z \"$PS\" ]; then",
    "  PS=$(ps ax -o args= 2>/dev/null | grep -F \"$TOKEN\" | grep -v grep | head -1)",
    "fi",
    "if [ -z \"$PS\" ]; then",
    "  for d in /proc/[0-9]*; do",
    "    [ -r \"$d/cmdline\" ] || continue",
    "    CL=$(tr '\\000' ' ' < \"$d/cmdline\" 2>/dev/null)",
    "    case \"$CL\" in",
    "      *\"$TOKEN\"*) PS=\"$CL\"; break ;;",
    "    esac",
    "  done",
    "fi",
    "if [ -n \"$PS\" ]; then echo PS=$PS; else echo PS=none; fi",
    "echo KMRD END",
  ]).join("\n");
}

// 生成应用脚本：day 为 0-31 整数（后端已校验）。
// 关键点：systemctl restart 由 nohup 后台延迟 3 秒执行——agent 进程被 systemd
// 杀掉时不会中断本脚本的回传；任务结果先回面板，节点随后短暂离线再自动重连。
// 前置拦截：容器环境（Docker 等托管模板常见）改不了自身启动参数，直接报错。
function applyScript(token, day) {
  return [
    "echo KMRA_BEGIN",
    "TOKEN=" + shellQuote(token),
    "DAY=" + day,
    "if [ ! -d /run/systemd/system ]; then",
    "  if [ -f /.dockerenv ] || grep -qiE 'docker|containerd|kubepods|lxc' /proc/1/cgroup 2>/dev/null; then",
    "    echo KMRA_FAIL container",
    "    exit 0",
    "  fi",
    "fi",
  ].concat(tokenUnitSearchLines()).concat(pidUnitLines()).concat([
    // 同上：--auto-discovery 节点按 Token 搜不到 unit，用进程反查兜底
    "if [ -z \"$UF\" ] && [ -n \"$FP\" ] && [ -f \"$FP\" ]; then",
    "  case \"$FP\" in",
    "    /lib/*|/usr/lib/*) SV0=$(basename \"$FP\"); cp \"$FP\" \"/etc/systemd/system/$SV0\" 2>/dev/null && UF=\"/etc/systemd/system/$SV0\" ;;",
    "    *) UF=\"$FP\" ;;",
    "  esac",
    "fi",
    "if [ -z \"$UF\" ]; then",
    "  echo KMRA_FAIL no_unit",
    "  exit 0",
    "fi",
    "echo UNIT_FILE=$UF",
    "EXEC=$(grep -m1 '^ExecStart=' \"$UF\" | sed 's/^ExecStart=//')",
    "CFG=$(echo \"$EXEC\" | sed -n 's/.*--config[= ][ ]\\{1,\\}\\([^ ]*\\).*/\\1/p')",
    "if [ -n \"$CFG\" ] && [ -f \"$CFG\" ]; then",
    "  echo KMRA_FAIL config_managed $CFG",
    "  exit 0",
    "fi",
    "BK=\"$UF.kmr-bak-$(date +%Y%m%d%H%M%S)\"",
    "if ! cp \"$UF\" \"$BK\" 2>/dev/null; then echo KMRA_FAIL backup; exit 0; fi",
    "echo BACKUP=$BK",
    "sed -i -E '/^ExecStart=/ { s/[[:space:]]+--month-rotate[[:space:]]+[0-9]+//g; s/[[:space:]]+--month-rotate=[0-9]+//g }' \"$UF\"",
    "sed -i -E '/^Environment=.*AGENT_MONTH_ROTATE/d' \"$UF\"",
    "if [ \"$DAY\" -gt 0 ]; then",
    "  sed -i \"/^ExecStart=/ s/\\$/ --month-rotate $DAY/\" \"$UF\"",
    "fi",
    "grep -m1 '^ExecStart=' \"$UF\"",
    "SV=$(basename \"$UF\")",
    "if echo \"$UF\" | grep -q '/systemd/user/'; then",
    "  nohup sh -c \"sleep 3; systemctl --user daemon-reload; systemctl --user restart $SV\" >/dev/null 2>&1 &",
    "else",
    // 同上：daemon-reload + restart 交给独立定时器，避免挂住 agent 的输出管道
    "  systemd-run --unit=\"kmr-apply-$(date +%s)\" --on-active=3 --collect /bin/sh -c \"systemctl daemon-reload; systemctl restart $SV\" >/dev/null 2>&1 || nohup sh -c \"sleep 3; systemctl daemon-reload; systemctl restart $SV\" >/dev/null 2>&1 &",
    "fi",
    "echo KMRA_OK scheduled",
  ]).join("\n");
}

// 生成迁移脚本：把 agent 接管为 systemd 服务管理（v1.4.1 重写）。
//
// 旧版缺陷（已导致同节点双 Agent 重复上报、流量统计跳变）：
//   1) 只按 Token 在 unit 文件里搜索服务。--auto-discovery 启动的 Agent，unit
//      文件里没有 Token 字符串，于是被误判为「服务名被别的 Agent 占用」，转而
//      新建 komari-agent-2.service —— 而原 komari-agent.service 仍在运行。
//   2) 收尾用 kill $AGENT_PID。原 unit 是 Restart=always，kill 只会被 systemd
//      立刻拉起，随后 systemctl start komari-agent-2 再起一个，同机双进程。
//      两个 Agent 参数不同（一个有 --month-rotate、一个没有），上报的累计流量
//      基线不同，面板交替入库 → 流量在两个值之间反复跳变并虚高。
//
// 现在的做法：
//   1) 先用运行进程反查它所属的 systemd unit（systemctl show -p Id / cgroup）。
//      命中则原地改写该 unit 并 restart —— 全程只有一个服务、一个进程；
//   2) 只有确认是裸进程（无 systemd 归属）时才新建 unit，启动前 kill 旧进程；
//   3) 输出 DUP= 列出同机其它活跃的 komari 服务，便于排查历史遗留的重复。
// 参数固化：剥离 --auto-discovery / 旧 -t / 旧 --month-rotate，写入显式
//       -t <面板 Token>——迁移后 Agent 绑定固定节点，不再走自动发现。
function migrateScript(token, day) {
  return [
    "echo KMRA_BEGIN",
    "TOKEN=" + shellQuote(token),
    "DAY=" + day,
    "CL=\"\"",
    "AGENT_PID=$PPID",
    "if [ -r \"/proc/$PPID/cmdline\" ]; then",
    "  CL=$(tr '\\000' ' ' < /proc/$PPID/cmdline 2>/dev/null)",
    "fi",
    "if [ -z \"$CL\" ]; then",
    "  for d in /proc/[0-9]*; do",
    "    [ -r \"$d/cmdline\" ] || continue",
    "    C=$(tr '\\000' ' ' < \"$d/cmdline\" 2>/dev/null)",
    "    case \"$C\" in",
    "      *\"$TOKEN\"*) CL=\"$C\"; AGENT_PID=$(basename \"$d\"); break ;;",
    "    esac",
    "  done",
    "fi",
    "if [ -z \"$CL\" ]; then",
    "  echo KMRA_FAIL not_running",
    "  for d in /proc/[0-9]*; do",
    "    [ -r \"$d/cmdline\" ] || continue",
    "    C=$(tr '\\000' ' ' < \"$d/cmdline\" 2>/dev/null)",
    "    case \"$C\" in",
    "      *komari*|*agent*) echo DIAG_PROC=$C ;;",
    "    esac",
    "  done",
    "  exit 0",
    "fi",
    "echo PS=$CL",
    "ARGS=$(echo \"$CL\" | sed 's/[[:space:]]*$//')",
    "BIN=$(echo \"$ARGS\" | awk '{print $1}')",
    "if [ ! -x \"$BIN\" ]; then",
    "  echo KMRA_FAIL no_binary $BIN",
    "  exit 0",
    "fi",
  ].concat(pidUnitLines()).concat([
    "MODE=",
    "SV=",
    "UF=",
    "if [ -n \"$FP\" ] && [ -f \"$FP\" ]; then",
    "  SV=\"$CUR_UNIT\"",
    "  case \"$FP\" in",
    "    /lib/*|/usr/lib/*) UF=\"/etc/systemd/system/$CUR_UNIT\" ;;",
    "    *) UF=\"$FP\" ;;",
    "  esac",
    "  MODE=reuse",
    "fi",
    // 进程反查失败时，再按 Token 在 unit 里搜一次（老节点 unit 里有显式 -t 的情况）
    "if [ -z \"$MODE\" ]; then",
    "  for u in /etc/systemd/system/*.service; do",
    "    [ -f \"$u\" ] || continue",
    "    if grep -qF \"$TOKEN\" \"$u\" 2>/dev/null; then",
    "      SV=$(basename \"$u\"); UF=\"$u\"; MODE=reuse; break",
    "    fi",
    "  done",
    "fi",
    "if [ -z \"$MODE\" ]; then",
    "  SV=komari-agent",
    "  UF=/etc/systemd/system/komari-agent.service",
    "  if [ -f \"$UF\" ] && [ \"$(systemctl is-active komari-agent.service 2>/dev/null)\" = active ]; then",
    "    SV=komari-agent-2",
    "    UF=/etc/systemd/system/komari-agent-2.service",
    "    if [ -f \"$UF\" ] && [ \"$(systemctl is-active komari-agent-2.service 2>/dev/null)\" = active ]; then",
    "      echo KMRA_FAIL name_conflict",
    "      exit 0",
    "    fi",
    "  fi",
    "  MODE=create",
    "fi",
    "echo MODE=$MODE",
    "if [ -f \"$UF\" ]; then",
    "  cp \"$UF\" \"$UF.kmr-bak-$(date +%Y%m%d%H%M%S)\" 2>/dev/null",
    "fi",
    "NEWARGS=$(echo \"$ARGS\" | sed -E 's/[[:space:]]+--auto-discovery[[:space:]]+[^[:space:]]+//g; s/[[:space:]]+--auto-discovery=[^[:space:]]+//g; s/[[:space:]]+-t[[:space:]]+[^[:space:]]+//g; s/[[:space:]]+-t=[^[:space:]]+//g; s/[[:space:]]+--month-rotate[[:space:]]+[0-9]+//g; s/[[:space:]]+--month-rotate=[0-9]+//g')",
    "if [ \"$DAY\" -gt 0 ]; then",
    "  NEWARGS=\"$NEWARGS -t $TOKEN --month-rotate $DAY\"",
    "else",
    "  NEWARGS=\"$NEWARGS -t $TOKEN\"",
    "fi",
    "cat > \"$UF\" <<UNIT_EOF",
    "[Unit]",
    "Description=Komari Agent (migrated by month-rotate plugin)",
    "After=network.target",
    "",
    "[Service]",
    "Type=simple",
    "ExecStart=$NEWARGS",
    "Restart=always",
    "RestartSec=3",
    "",
    "[Install]",
    "WantedBy=multi-user.target",
    "UNIT_EOF",
    "echo UNIT_FILE=$UF",
    "grep -m1 '^ExecStart=' \"$UF\"",
    "for f in /etc/systemd/system/*.service; do",
    "  [ -f \"$f\" ] || continue",
    "  grep -qi komari \"$f\" 2>/dev/null || continue",
    "  N=$(basename \"$f\")",
    "  [ \"$N\" = \"$SV\" ] && continue",
    "  if [ \"$(systemctl is-active \"$N\" 2>/dev/null)\" = active ]; then echo DUP=$N; fi",
    "done",
    // daemon-reload / enable / restart 必须放到独立 cgroup 里延迟执行：
    // 同步调用 systemctl enable + daemon-reload 会让 agent 的 stdout 管道挂住，
    // 任务结果回不来（面板显示"执行输出格式异常"或空白）。
    "if [ \"$MODE\" = reuse ]; then",
    "  systemd-run --unit=\"kmr-migrate-$(date +%s)\" --on-active=3 --collect /bin/sh -c \"systemctl daemon-reload; systemctl enable $SV >/dev/null 2>&1; systemctl restart $SV\" >/dev/null 2>&1 || nohup sh -c \"sleep 3; systemctl daemon-reload; systemctl enable $SV >/dev/null 2>&1; systemctl restart $SV\" >/dev/null 2>&1 &",
    "else",
    "  systemd-run --unit=\"kmr-migrate-$(date +%s)\" --on-active=3 --collect /bin/sh -c \"systemctl daemon-reload; systemctl enable $SV >/dev/null 2>&1; kill $AGENT_PID 2>/dev/null; sleep 1; systemctl start $SV\" >/dev/null 2>&1 || nohup sh -c \"sleep 3; systemctl daemon-reload; systemctl enable $SV >/dev/null 2>&1; kill $AGENT_PID 2>/dev/null; sleep 1; systemctl start $SV\" >/dev/null 2>&1 &",
    "fi",
    "echo KMRA_OK scheduled",
  ]).join("\n");
}

// 单引号包裹 shell 字符串（token 已被 TOKEN_RE 白名单校验，此处双保险）
function shellQuote(s) {
  return "'" + String(s).replace(/'/g, "'\\''") + "'";
}

/* ---------------- 输出解析 ---------------- */

function dayFromArgs(str) {
  if (!str) return null;
  const m = /--month-rotate(?:=|[ \t]+)(\d+)/.exec(String(str));
  return m ? parseInt(m[1], 10) : null;
}

function parseProbe(text) {
  const raw = String(text || "");
  const out = {
    ok: false,
    error: "",
    offline: false,
    init: "",
    unitFile: "",
    execStart: "",
    envDay: null,
    execDay: null,
    configDay: null,
    configManaged: false,
    configFile: "",
    psDay: null,
    psLine: "",
    svcActive: "",
    candidates: [],
    currentDay: 0,
    psOnly: false,
    container: false, // Agent 运行在容器中（Docker/LXC 等），无法通过 systemd 自动修改
    manual: false,   // Agent 非 systemd 服务管理（手动/其他方式运行），无法自动修改
    at: nowIso(),
  };

  if (raw.indexOf("Client offline!") >= 0) {
    out.offline = true;
    out.error = "节点不在线，无法探测";
    return out;
  }
  if (raw.indexOf("KMRD BEGIN") < 0) {
    out.error = "探测输出格式异常（节点可能不支持远程命令）";
    return out;
  }

  const lines = raw.split(/\r?\n/);
  for (let ln of lines) {
    const t = String(ln).trim();
    if (t.indexOf("INIT=") === 0) out.init = t.slice(5).trim();
    else if (t.indexOf("UNIT_FILE=") === 0 && out.unitFile === "") out.unitFile = t.slice(10).trim();
    else if (t.indexOf("ExecStart=") === 0 && out.execStart === "") out.execStart = String(ln).slice(10).trim();
    else if (t.indexOf("Environment=") === 0 && out.envDay === null) {
      const m = /MONTH_ROTATE[="' ]*(\d+)/i.exec(t);
      if (m) out.envDay = parseInt(m[1], 10);
    }
    else if (t.indexOf("CONFIG_FILE=") === 0) out.configFile = t.slice(12).trim();
    else if (t.indexOf("CONFIG_ROT=") === 0) out.configDay = toNum(t.slice(11).trim(), null);
    else if (t.indexOf("SVC_ACTIVE=") === 0) out.svcActive = t.slice(11).trim();
    else if (t.indexOf("PS=") === 0 && out.psLine === "") out.psLine = t.slice(3).trim();
    else if (t.indexOf("CAND=") === 0) out.candidates.push(t.slice(5).trim());
  }

  out.execDay = dayFromArgs(out.execStart);
  out.psDay = dayFromArgs(out.psLine);
  out.configManaged = out.configDay !== null;

  // agent 配置加载优先级：config 文件 > 环境变量 > 命令行
  if (out.configDay !== null) out.currentDay = out.configDay;
  else if (out.envDay !== null) out.currentDay = out.envDay;
  else if (out.execDay !== null) out.currentDay = out.execDay;
  else if (out.psDay !== null) out.currentDay = out.psDay;
  else out.currentDay = 0;

  // unit 定位成功但运行进程里没有 month-rotate，而 ps 有 -> 以 ps 为准并提示 unit 未同步
  if (out.psDay !== null && out.execDay === null && out.configDay === null && out.envDay === null) {
    out.psOnly = true; // agent 由旧命令行/手动方式启动，unit 文件还没带参数
  }

  // 环境分类：容器 / 手动运行（unit 没找到但进程在跑）
  out.container = out.init === "container";
  out.manual = out.unitFile === "none" && !!out.psLine && !out.container;

  if (out.unitFile === "none" && !out.psLine) {
    out.error = "未找到本节点的 Agent 服务（按 Token 定位失败）";
  } else if (out.init === "nosystemd" && out.unitFile === "none") {
    out.error = "该节点不使用 systemd，暂不支持自动修改";
  } else {
    out.ok = true;
  }
  return out;
}

function parseApply(text, day) {
  const raw = String(text || "");
  const out = {
    ok: false,
    error: "",
    offline: false,
    day: day,
    unitFile: "",
    backup: "",
    newExec: "",
    scheduled: false,
    failReason: "",
    mode: "",
    dup: [],
    note: "",
    at: nowIso(),
  };

  if (raw.indexOf("Client offline!") >= 0) {
    out.offline = true;
    out.error = "节点不在线，无法下发修改";
    return out;
  }
  if (!raw.trim()) {
    out.error = "节点未返回执行结果（Agent 可能刚好在重启），请稍后重新探测确认是否已生效";
    return out;
  }
  if (raw.indexOf("KMRA_BEGIN") < 0) {
    out.error = "执行输出格式异常（远程命令可能被禁用）";
    return out;
  }

  const lines = raw.split(/\r?\n/);
  const diagProcs = [];
  for (const ln of lines) {
    const t = String(ln).trim();
    if (t.indexOf("UNIT_FILE=") === 0 && out.unitFile === "") out.unitFile = t.slice(10).trim();
    else if (t.indexOf("BACKUP=") === 0) out.backup = t.slice(7).trim();
    else if (t.indexOf("ExecStart=") === 0 && out.newExec === "") out.newExec = t.slice(10).trim();
    else if (t.indexOf("KMRA_FAIL") === 0) out.failReason = t.slice(10).trim();
    else if (t.indexOf("MODE=") === 0 && !out.mode) out.mode = t.slice(5).trim();
    else if (t.indexOf("DUP=") === 0) out.dup.push(t.slice(4).trim());
    else if (t.indexOf("DIAG_PROC=") === 0) diagProcs.push(t.slice(10).trim());
  }
  out.diag = diagProcs;

  if (raw.indexOf("KMRA_OK") >= 0) {
    out.ok = true;
    out.scheduled = true;
    if (out.dup.length) {
      out.note = "同机还有其它 komari 服务处于运行状态（可能是历史遗留的重复 Agent，会导致同一节点双份上报）：" + out.dup.join("、");
    }
  } else {
    if (out.failReason.indexOf("config_managed") === 0) {
      out.error = "该节点使用 --config 配置文件管理参数，请手动修改其中的 month_rotate 字段";
    } else if (out.failReason === "container") {
      out.error = "Agent 运行在容器中（Docker/LXC 等），无法通过 systemd 修改；请在宿主机的容器启动参数中加入 --month-rotate";
    } else if (out.failReason === "no_unit") {
      out.error = "未找到本节点的 Agent systemd 服务文件（Agent 可能由容器或手动方式运行）";
    } else if (out.failReason === "not_running") {
      if (diagProcs.length) {
        out.error = "未找到含本节点 Token 的运行进程。但节点上存在以下疑似 Agent 进程（可能 Agent 以 --config 配置文件方式连接、Token 不在启动参数中，或 Token 已更换）：" + diagProcs.join(" | ");
      } else {
        out.error = "未找到运行中的 Agent 进程（节点上没有任何 komari/agent 相关进程，Agent 可能刚好停止或重启，可稍后重试）";
      }
    } else if (out.failReason.indexOf("no_binary") === 0) {
      out.error = "Agent 可执行文件不可用：" + out.failReason.slice(9).trim();
    } else if (out.failReason === "name_conflict") {
      out.error = "服务名冲突：komari-agent 与 komari-agent-2 均已被其他 Agent 占用";
    } else if (out.failReason === "backup") {
      out.error = "备份服务文件失败（Agent 可能以非 root 运行）";
    } else if (out.failReason === "daemon_reload") {
      out.error = "systemctl daemon-reload 失败";
    } else {
      out.error = "修改失败：" + (out.failReason || "未知原因");
    }
  }
  return out;
}

// 与 Komari 状态页「服务器列表」一致：按 weight 升序，同 weight 保持接口原始顺序
function sortForDisplay(list) {
  return (list || []).map(function (n, i) { return { n: n, i: i }; })
    .sort(function (a, b) {
      const wa = toNum(a.n && a.n.weight, 0), wb = toNum(b.n && b.n.weight, 0);
      return wa - wb || a.i - b.i;
    })
    .map(function (x) { return x.n; });
}

/* ---------------- 持久化 ---------------- */

function statePath() {
  return path.join(__storageDir__, "state.json");
}

function loadState() {
  try {
    const raw = fs.readFileSync(statePath(), "utf8");
    const st = JSON.parse(raw);
    if (st && st.probes) S.probes = st.probes;
    if (st && Array.isArray(st.history)) S.history = st.history;
    if (st && st.tokens) S.tokens = st.tokens;
  } catch (e) { /* 首次运行无状态文件 */ }
}

function saveState() {
  try {
    fs.writeFileSync(statePath(), JSON.stringify({
      probes: S.probes,
      history: S.history,
      tokens: S.tokens,
    }));
  } catch (e) {
    console.log("[month-rotate] 状态保存失败: " + e.message);
  }
}

// 防抖落盘：一次批量探测会触发 56 次状态变更，逐个全量写盘既慢又无意义。
let saveTimer = null;
function scheduleSave() {
  if (saveTimer) return;
  saveTimer = setTimeout(function () {
    saveTimer = null;
    saveState();
  }, SAVE_DEBOUNCE_MS);
  if (saveTimer.unref) saveTimer.unref();
}

function flushSave() {
  if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
  saveState();
}

/* ---------------- 任务回收 ---------------- */

let pruneTimer = null;
function pruneTasks() {
  const now = Date.now();
  for (const id of Object.keys(S.tasks)) {
    const t = S.tasks[id];
    if (t.done && t.doneAt && now - t.doneAt > TASK_KEEP_MS) delete S.tasks[id];
  }
}

/* ---------------- 节点与任务 ---------------- */

async function getNodes() {
  const now = Date.now();
  if (S.nodesCache && now - S.nodesCacheAt < 30 * 1000) return S.nodesCache;
  const list = await rpc("admin:listClients");
  S.nodesCache = Array.isArray(list) ? list : [];
  S.nodesCacheAt = now;
  return S.nodesCache;
}

async function getToken(uuid) {
  if (S.tokens[uuid]) return S.tokens[uuid];
  const r = await rpc("admin:getClientToken", { uuid: uuid });
  const token = r && r.token ? String(r.token) : "";
  if (token && TOKEN_RE.test(token)) {
    S.tokens[uuid] = token;
    scheduleSave();
  }
  return token;
}

// 下发一个任务；离线节点由面板直接写 "Client offline!" 结果，无需预检。
async function dispatch(kind, uuid, command, day) {
  const r = await rpc("admin:exec", { command: command, clients: [uuid] });
  const taskId = r && r.task_id ? String(r.task_id) : "";
  if (!taskId) throw new Error((r && r.message) || "任务下发失败");
  S.tasks[taskId] = {
    kind: kind,
    uuid: uuid,
    day: day,
    startedAt: nowIso(),
    result: null,
    done: false,
  };
  return taskId;
}

// 查询任务并解析结果；返回 {done, probe?, apply?, error?}
async function pollTask(taskId) {
  const t = S.tasks[taskId];
  if (!t) return { done: true, error: "unknown task" };
  if (t.done) return { done: true, probe: t.probe, apply: t.apply, error: t.error || "" };

  let resp;
  try {
    resp = await rpc("admin:getTaskById", { task_id: taskId });
  } catch (e) {
    // 任务刚创建时可能查不到结果，视为进行中
    if (String(e.message || "").indexOf("not found") >= 0) return { done: false };
    if (Date.now() - new Date(t.startedAt).getTime() > TASK_TIMEOUT_MS) {
      t.done = true;
      t.doneAt = Date.now();
      t.error = "任务超时未返回结果";
      return { done: true, error: t.error };
    }
    return { done: false };
  }

  const results = (resp && resp.results) || [];
  let mine = null;
  for (const r of results) {
    if (r && r.client === t.uuid) { mine = r; break; }
  }
  if (!mine) {
    if (Date.now() - new Date(t.startedAt).getTime() > TASK_TIMEOUT_MS) {
      t.done = true;
      t.doneAt = Date.now();
      t.error = "任务超时未返回结果";
      return { done: true, error: t.error };
    }
    return { done: false };
  }

  const text = String(mine.result || "");
  if (t.kind === "detect") {
    const p = parseProbe(text);
    t.probe = p;
    S.probes[t.uuid] = p;
    scheduleSave();
  } else {
    const a = parseApply(text, t.day);
    t.apply = a;
    if (a.ok) {
      S.history.unshift({
        time: nowIso(),
        kind: t.kind === "migrate" ? "migrate" : "day",
        uuid: t.uuid,
        day: t.day,
        unitFile: a.unitFile,
        backup: a.backup,
        mode: a.mode || "",
        dup: a.dup || [],
        note: a.note || "",
      });
      S.history = S.history.slice(0, HISTORY_KEEP);
      scheduleSave();
      if (t.kind === "migrate") S.probes[t.uuid] = null; // 迁移后旧探测结果失效，待重新探测
    }
  }
  t.done = true;
  t.doneAt = Date.now();
  t.exitCode = mine.exit_code;
  return { done: true, probe: t.probe, apply: t.apply };
}

/* ---------------- HTTP 路由 ---------------- */

function load() {
  loadState();
  pruneTasks();
  pruneTimer = setInterval(pruneTasks, 60 * 1000);
  if (pruneTimer.unref) pruneTimer.unref();

  // 总览：节点列表 + 探测缓存 + 任务进度 + 历史
  server.route("GET", "/month-rotate/status", async function (req, res) {
    if (!isAdmin(req)) return jsonReply(res, { status: "error", message: "forbidden" }, 403);
    try {
      pruneTasks();
      const nodes = sortForDisplay(await getNodes());
      // 只回吐未完成任务 + 最近完成的 10 个，避免响应体随历史任务无限膨胀
      const allTasks = Object.keys(S.tasks).map(function (id) {
        const t = S.tasks[id];
        return {
          task_id: id,
          kind: t.kind,
          uuid: t.uuid,
          day: t.day,
          startedAt: t.startedAt,
          done: t.done,
          error: t.error || "",
        };
      });
      const running = allTasks.filter(function (t) { return !t.done; })
        .concat(allTasks.filter(function (t) { return t.done; }).slice(-10));
      return jsonReply(res, {
        status: "success",
        nodes: nodes.map(function (n) {
          return {
            uuid: n.uuid,
            name: n.name,
            group: n.group || "",
            region: n.region || "",
            weight: n.weight || 0,
            hidden: !!n.hidden,
            traffic_limit: n.traffic_limit || 0,
            traffic_limit_type: n.traffic_limit_type || "",
            probe: S.probes[n.uuid] || null,
          };
        }),
        tasks: running,
        history: S.history.slice(0, HISTORY_RETURN),
      });
    } catch (e) {
      return jsonReply(res, { status: "error", message: e.message }, 500);
    }
  });

  // 探测：{clients: [uuid] | 缺省全部}
  server.route("POST", "/month-rotate/detect", async function (req, res) {
    if (!isAdmin(req)) return jsonReply(res, { status: "error", message: "forbidden" }, 403);
    try {
      const body = parseBody(req);
      let uuids = Array.isArray(body.clients) && body.clients.length ? body.clients : null;
      const nodes = await getNodes();
      if (!uuids) uuids = nodes.map(function (n) { return n.uuid; });
      const known = {};
      nodes.forEach(function (n) { known[n.uuid] = true; });

      const results = await mapLimit(uuids, DISPATCH_CONCURRENCY, async function (uuid) {
        if (!known[uuid]) return { skip: { uuid: uuid, reason: "节点不存在" } };
        try {
          const token = await getToken(uuid);
          if (!token) return { skip: { uuid: uuid, reason: "无法获取节点 Token" } };
          const taskId = await dispatch("detect", uuid, detectScript(token));
          return { started: { uuid: uuid, task_id: taskId } };
        } catch (e) {
          return { skip: { uuid: uuid, reason: e.message } };
        }
      });

      const started = [], skipped = [];
      results.forEach(function (r) {
        if (!r) return;
        if (r.started) started.push(r.started);
        if (r.skip) skipped.push(r.skip);
      });
      return jsonReply(res, { status: "success", started: started, skipped: skipped });
    } catch (e) {
      return jsonReply(res, { status: "error", message: e.message }, 500);
    }
  });

  // 应用：{targets: [{uuid, day?, limit?, limit_type?}]}
  //   day        可选，0-31：月重置日（远程任务改 agent 服务并重启）
  //   limit      可选，字节（0=不显示进度条）：流量阈值（面板字段，即时生效）
  //   limit_type 可选，sum/max/min/up/down：统计方式（面板字段，即时生效）
  server.route("POST", "/month-rotate/apply", async function (req, res) {
    if (!isAdmin(req)) return jsonReply(res, { status: "error", message: "forbidden" }, 403);
    try {
      const body = parseBody(req);
      const targets = Array.isArray(body.targets) ? body.targets : [];
      if (!targets.length) return jsonReply(res, { status: "error", message: "未选择任何节点" }, 400);

      const nodes = await getNodes();
      const started = [];
      const traffic = [];
      const skipped = [];
      for (const t of targets) {
        const uuid = String(t.uuid || "");
        const node = nodes.find(function (n) { return n.uuid === uuid; }) || null;
        if (!node) {
          skipped.push({ uuid: uuid, reason: "节点不存在" });
          continue;
        }

        // ---- 可选字段校验 ----
        let day = null;
        if (t.day !== undefined && t.day !== null && t.day !== "") {
          day = toNum(t.day, -1);
          if (!(day >= 0 && day <= 31 && Math.floor(day) === day)) {
            skipped.push({ uuid: uuid, reason: "重置日必须是 0-31 的整数（0=禁用）" });
            continue;
          }
        }
        let limit = null;
        if (t.limit !== undefined && t.limit !== null && t.limit !== "") {
          limit = toNum(t.limit, -1);
          if (!(limit >= 0 && limit <= MAX_LIMIT_BYTES && Math.floor(limit) === limit)) {
            skipped.push({ uuid: uuid, reason: "流量阈值必须是 0 到 1EiB 的整数字节数（0=不显示进度条）" });
            continue;
          }
        }
        let limitType = null;
        if (t.limit_type !== undefined && t.limit_type !== null && t.limit_type !== "") {
          limitType = String(t.limit_type);
          if (LIMIT_TYPES.indexOf(limitType) < 0) {
            skipped.push({ uuid: uuid, reason: "统计方式必须是 " + LIMIT_TYPES.join("/") });
            continue;
          }
        }
        if (day === null && limit === null && limitType === null) {
          skipped.push({ uuid: uuid, reason: "没有可应用的修改" });
          continue;
        }

        // ---- 面板字段：流量阈值/统计方式（admin:editClient 部分更新，即时生效）----
        if (limit !== null || limitType !== null) {
          const edit = { uuid: uuid };
          if (limit !== null) edit.traffic_limit = limit;
          if (limitType !== null) edit.traffic_limit_type = limitType;
          try {
            await rpc("admin:editClient", edit);
            const newLimit = limit !== null ? limit : (node.traffic_limit || 0);
            const newType = limitType !== null ? limitType : (node.traffic_limit_type || "");
            traffic.push({ uuid: uuid, limit: newLimit, limit_type: newType });
            S.history.unshift({
              time: nowIso(),
              kind: "traffic",
              uuid: uuid,
              from: { limit: node.traffic_limit || 0, limit_type: node.traffic_limit_type || "" },
              to: { limit: newLimit, limit_type: newType },
            });
          } catch (e) {
            skipped.push({ uuid: uuid, reason: "流量阈值修改失败：" + e.message });
            continue;
          }
        }

        // ---- 远程任务：月重置日（改 agent 服务并重启）----
        if (day !== null) {
          try {
            const token = await getToken(uuid);
            if (!token) { skipped.push({ uuid: uuid, reason: "无法获取节点 Token，月重置日未修改" }); continue; }
            const taskId = await dispatch("apply", uuid, applyScript(token, day), day);
            started.push({ uuid: uuid, day: day, task_id: taskId });
          } catch (e) {
            skipped.push({ uuid: uuid, reason: "月重置日修改失败：" + e.message });
          }
        }
      }
      if (traffic.length) {
        S.history = S.history.slice(0, HISTORY_KEEP);
        scheduleSave();
        S.nodesCache = null; // 节点流量字段已变，让下次 status 重新拉取
      }
      return jsonReply(res, { status: "success", started: started, traffic: traffic, skipped: skipped });
    } catch (e) {
      return jsonReply(res, { status: "error", message: e.message }, 500);
    }
  });

  // 迁移：{targets: [{uuid, day}]}——把「手动运行」的 agent 接管为 systemd 服务，day 为 0-31 必填
  server.route("POST", "/month-rotate/migrate", async function (req, res) {
    if (!isAdmin(req)) return jsonReply(res, { status: "error", message: "forbidden" }, 403);
    try {
      const body = parseBody(req);
      const targets = Array.isArray(body.targets) ? body.targets : [];
      if (!targets.length) return jsonReply(res, { status: "error", message: "未选择任何节点" }, 400);

      const nodes = await getNodes();
      const known = {};
      nodes.forEach(function (n) { known[n.uuid] = true; });

      const results = await mapLimit(targets, DISPATCH_CONCURRENCY, async function (t) {
        const uuid = String(t.uuid || "");
        const day = toNum(t.day, -1);
        if (!known[uuid]) return { skip: { uuid: uuid, reason: "节点不存在" } };
        if (!(day >= 0 && day <= 31 && Math.floor(day) === day)) {
          return { skip: { uuid: uuid, reason: "重置日必须是 0-31 的整数（0=禁用）" } };
        }
        try {
          const token = await getToken(uuid);
          if (!token) return { skip: { uuid: uuid, reason: "无法获取节点 Token" } };
          const taskId = await dispatch("migrate", uuid, migrateScript(token, day), day);
          return { started: { uuid: uuid, day: day, task_id: taskId } };
        } catch (e) {
          return { skip: { uuid: uuid, reason: e.message } };
        }
      });

      const started = [], skipped = [];
      results.forEach(function (r) {
        if (!r) return;
        if (r.started) started.push(r.started);
        if (r.skip) skipped.push(r.skip);
      });
      return jsonReply(res, { status: "success", started: started, skipped: skipped });
    } catch (e) {
      return jsonReply(res, { status: "error", message: e.message }, 500);
    }
  });

  // 轮询任务：{task_ids: [taskId]}
  server.route("POST", "/month-rotate/poll", async function (req, res) {
    if (!isAdmin(req)) return jsonReply(res, { status: "error", message: "forbidden" }, 403);
    try {
      const body = parseBody(req);
      const ids = Array.isArray(body.task_ids) ? body.task_ids : (body.task_id ? [body.task_id] : []);
      const items = [];
      for (const id of ids) {
        try {
          const r = await pollTask(String(id));
          items.push({ task_id: String(id), done: !!r.done, probe: r.probe || null, apply: r.apply || null, error: r.error || "" });
        } catch (e) {
          items.push({ task_id: String(id), done: true, error: e.message });
        }
      }
      return jsonReply(res, { status: "success", items: items });
    } catch (e) {
      return jsonReply(res, { status: "error", message: e.message }, 500);
    }
  });

  console.log("[month-rotate] 插件已加载：流量月重置日管理");
}

function unload() {
  if (pruneTimer) { clearInterval(pruneTimer); pruneTimer = null; }
  flushSave();
}
