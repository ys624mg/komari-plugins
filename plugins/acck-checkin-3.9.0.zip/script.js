// ACCK 自动签到（多账号）— Komari 插件
//
// 功能：
//   1) 支持 N 个 ACCK 账号（配置中每行一个），逐个自动签到；
//   2) 每个账号：求解登录页人机验证(altcha PoW) → 邮箱+密码登录 → TOTP 二次验证 → 换取 Token；
//   3) 每日定时批量签到，失败自动重试，账号之间按间隔顺序执行（避免并发触发风控）；
//   4) 结果通过 Komari 站点通知渠道 与/或 自定义 Telegram Bot 统一推送汇总；
//   5) 敏感数据保护：状态接口/管理页/日志/通知/持久化中均不出现密码与 TOTP 密钥，邮箱一律脱敏。
//
// 关键实现细节（已通过实测验证）：
//   - altcha 新版 PoW：counter 从 0 递增，password = hex(nonce) + BE32(counter)，
//     PBKDF2-HMAC-SHA256(salt=hex(salt), iterations=cost=5000, dkLen=32)，
//     derivedKey 的 hex 以 keyPrefix 开头即求解成功；
//   - 服务端通过 HttpOnly cookie acck_device 绑定设备指纹：challenge 响应 Set-Cookie，
//     插件必须把该 cookie 持久化并在所有请求中携带，否则验证不通过（多账号共用同一设备 cookie）；
//   - 登录成功 / 2FA 校验成功均返回顶层 token 字段；
//   - 2FA 触发响应可能只有 mfa_token 而无 requires_2fa 标志，两种都要识别；
//   - TOTP 用 ACCK 响应 Date 头校准时钟后再生成，避免面板服务器时钟漂移导致"验证码已过期"。
//
// Komari 插件运行时约束（goja）：
//   - 顶层脚本不是 CommonJS wrapper：不能使用 module/exports，load/unload 为全局函数；
//   - 纯算法已抽到 lib/acck-core.js（该文件被 require，支持 module.exports）；
//   - 不使用 Buffer.concat / BigInt / ?. / ?? / Object.assign 以保证 goja 兼容性。

var server = require("server");
var fs = require("fs");
var path = require("path");
var core = require("./lib/acck-core.js");

var HTTP_BASE = "https://acck.io";
var PLUGIN_VERSION = "3.9.0";

/* ---------------- 运行状态 ---------------- */

var S = {
  config: null,
  configSig: null,       // 配置签名（用于检测配置页改动后自动生效）
  configChanged: false,  // 批量签到进行中收到配置变更，待结束后重载
  accounts: [],          // 账号列表（含运行期状态）
  deviceCookie: "",      // acck_device（多账号共用同一设备标识，持久化）
  serverTimeOffsetMs: 0, // 本地时钟与 ACCK 服务端时钟偏差(ms)，用于 TOTP 校准
  busy: false,           // 批量签到执行中
  progress: { running: false, done: 0, total: 0, current: "", startedAt: null, reason: "" },
  lastBatch: null,       // 最近一次批量签到结果摘要
  notifyLog: [],         // 通知投递记录（全局，仅含脱敏标识）
  state: {},             // 持久化状态
  cronLoopStarted: false,
  lastCronDay: "",       // 已跑过每日签到的日期键（避免同一日重复触发）
  skippedLines: 0,       // 配置中被跳过的无效账号行数
  exPollBusy: false,     // 交易区轮询执行中
  exTestBusy: false,     // 测试推送执行中
  exPollLoopStarted: false, // 交易所自适应轮询循环已启动
  tgBuyBusy: false,      // TG 一键购买执行中
  tgPollLoopStarted: false,
  ipBlockedUntil: 0,     // 登录失败次数过多导致的 IP 限流截止时间（unix 秒）
  ipBlockNotified: 0,    // 已通知过的封禁截止时间（避免重复告警）
};

/* ---------------- 基础工具 ---------------- */

function toNum(v, def) {
  var n = Number(v);
  return isFinite(n) ? n : def;
}

function clampNum(v, min, max, def) {
  var n = toNum(v, def === undefined ? min : def);
  if (n < min) return min;
  if (n > max) return max;
  return n;
}

function toBool(v, def) {
  if (v === undefined || v === null || v === "") return def;
  if (typeof v === "string") {
    var s = v.trim().toLowerCase();
    if (s === "false" || s === "0" || s === "off" || s === "no") return false;
    if (s === "true" || s === "1" || s === "on" || s === "yes") return true;
  }
  return !!v;
}

function pad(n) {
  return (n < 10 ? "0" : "") + n;
}

function sleep(ms) {
  return new Promise(function (r) { setTimeout(r, ms); });
}

// 截断字符串（避免通知/日志超长）
function clip(s, n) {
  var t = String(s === undefined || s === null ? "" : s);
  return t.length > n ? t.slice(0, n) + "…" : t;
}

// 当前是否处于「登录失败次数过多导致的 IP 限流」期间
function isIpBlocked() {
  return S.ipBlockedUntil > Math.floor(Date.now() / 1000);
}

function ipBlockedMsg(prefix) {
  return (prefix || "") + "当前 IP 处于登录限流期（至 " + core.fmtUnixLocal(S.ipBlockedUntil) + "）";
}

// 记录 IP 限流（并在首次出现时推送一条告警，避免静默失败）
async function markIpBlocked(blockedUntil, message) {
  var until = toNum(blockedUntil, 0) || (Math.floor(Date.now() / 1000) + 600);
  var first = S.ipBlockNotified !== until;
  S.ipBlockedUntil = until;
  if (first) {
    S.ipBlockNotified = until;
    console.log("[acck-checkin] 检测到 IP 登录限流: " + message);
    try {
      await notifyRaw(
        "ACCK 登录被临时限制",
        "⚠️ " + message + "\n\n请检查配置中的账号密码是否正确（密码错误的账号反复登录会触发 IP 级限流，进而影响其他账号）。\n插件将在限制解除后自动恢复（期间跳过所有登录尝试）。"
      );
    } catch (e) {}
  }
}

function tsToLocal(ts) {
  var off = toNum(S.config ? S.config.timezone_offset : 8, 8) * 3600;
  var d = new Date((toNum(ts, 0) + off) * 1000);
  return {
    y: d.getUTCFullYear(),
    mo: d.getUTCMonth() + 1,
    d: d.getUTCDate(),
    h: d.getUTCHours(),
    mi: d.getUTCMinutes(),
    s: d.getUTCSeconds(),
  };
}

function nowStr() {
  var t = tsToLocal(Math.floor(Date.now() / 1000));
  return t.y + "-" + pad(t.mo) + "-" + pad(t.d) + " " + pad(t.h) + ":" + pad(t.mi) + ":" + pad(t.s);
}

function todayKey() {
  var t = tsToLocal(Math.floor(Date.now() / 1000));
  return t.y + "-" + pad(t.mo) + "-" + pad(t.d);
}

// 下一次自动签到的 unix 秒（未启用返回 0）
function nextCheckinAt() {
  var cfg = S.config || {};
  if (!toBool(cfg.checkin_enabled, true)) return 0;
  var m = /^(\d{1,2}):(\d{2})$/.exec(String(cfg.checkin_time || "09:00").trim());
  var hh = 9, mm = 0;
  if (m) {
    hh = clampNum(m[1], 0, 23, 9);
    mm = clampNum(m[2], 0, 59, 0);
  }
  var off = toNum(cfg.timezone_offset, 8) * 3600;
  var localNow = Math.floor(Date.now() / 1000) + off;
  var dayStart = Math.floor(localNow / 86400) * 86400;
  var target = dayStart + hh * 3600 + mm * 60;
  while (target <= localNow) target += 86400;
  return target - off;
}

/* ---------------- 持久化 ---------------- */

var saveTimer = null;

function storageFile() {
  try {
    if (typeof __storageDir__ !== "undefined" && __storageDir__) {
      return path.join(__storageDir__, "state.json");
    }
  } catch (e) {}
  return null;
}

function loadState() {
  var f = storageFile();
  if (!f) return {};
  try {
    if (fs.existsSync(f)) {
      var t = fs.readFileSync(f, "utf8");
      if (t) {
        var o = JSON.parse(t);
        return o && typeof o === "object" ? o : {};
      }
    }
  } catch (e) {
    console.log("[acck-checkin] loadState: " + e.message);
  }
  return {};
}

// 原子写入：先写 .tmp 再 rename，避免掉电/崩溃产生半截 JSON
function saveState() {
  var f = storageFile();
  if (!f) return;
  try {
    var dir = path.dirname(f);
    if (!fs.existsSync(dir)) {
      try { fs.mkdirSync(dir, { recursive: true }); } catch (e) {}
    }
    var json = JSON.stringify(S.state);
    var tmp = f + ".tmp";
    var renamed = false;
    try {
      fs.writeFileSync(tmp, json);
      try { fs.renameSync(tmp, f); renamed = true; } catch (e1) {}
    } catch (e0) {}
    if (!renamed) fs.writeFileSync(f, json);
  } catch (e) {
    console.error("[acck-checkin] saveState: " + e.message);
  }
}

// 合并写入：高频状态变更（每次签到记录/推送记录）不再逐次落盘，减少磁盘 IO
function scheduleSave() {
  if (saveTimer) return;
  saveTimer = setTimeout(function () {
    saveTimer = null;
    saveState();
  }, 400);
}

function flushSave() {
  if (saveTimer) {
    clearTimeout(saveTimer);
    saveTimer = null;
  }
  saveState();
}

// 持久化：仅保存脱敏后的账号信息（不含密码/TOTP/完整邮箱）
function persistCore() {
  var cfg = S.config || {};
  var keep = toNum(cfg.checkin_history_keep, 0);
  var hardCap = 500;                       // 绝对上限，避免配置为 0 时无限膨胀
  var perAccount = keep > 0 ? Math.min(keep, hardCap) : hardCap;
  S.state.deviceCookie = S.deviceCookie;
  S.state.accounts = {};
  for (var i = 0; i < S.accounts.length; i++) {
    var a = S.accounts[i];
    S.state.accounts[a.id] = {
      emailMasked: a.emailMasked,
      name: a.name,
      lastCheckinAt: a.lastCheckinAt,
      lastCheckinDate: a.lastCheckinDate,
      lastResult: a.lastResult,
      lastError: a.lastError,
      history: a.history.slice(0, perAccount),
    };
  }
  S.state.notifyLog = S.notifyLog.slice(0, clampNum(cfg.notify_log_keep, 1, 500, 30));
  if (S.lastBatch) S.state.lastBatch = S.lastBatch;
  scheduleSave();
}

/* ---------------- 账号装载 ---------------- */

// 从配置装载账号：优先多账号文本 accounts；为空时回退旧单账号字段（平滑升级）
function loadAccountsFromConfig() {
  var cfg = S.config || {};
  var parsed = core.parseAccounts(cfg.accounts || "");
  S.skippedLines = parsed.skipped;
  var list = parsed.accounts.slice();
  // 兼容旧单账号配置
  if (!list.length && cfg.acck_email && cfg.acck_password) {
    list.push({
      email: String(cfg.acck_email).trim(),
      password: String(cfg.acck_password),
      totpSecret: cfg.acck_totp_secret ? core.extractTotpSecret(cfg.acck_totp_secret) : "",
      name: "默认账号",
    });
  }
  var saved = S.state.accounts || {};
  S.accounts = [];
  for (var i = 0; i < list.length; i++) {
    var src = list[i];
    var id = "acc-" + (i + 1);
    var st = saved[id] || {};
    S.accounts.push({
      idx: i + 1,
      id: id,
      name: src.name || ("账号" + (i + 1)),
      email: src.email,
      emailMasked: core.maskEmail(src.email),
      password: src.password,
      totpSecret: src.totpSecret,
      hasTotp: !!src.totpSecret,
      // 运行期状态（从持久化恢复）
      token: null,
      tokenAt: 0,
      tokenExp: 0,
      tokenLifeSec: 0,
      lastCheckinAt: st.lastCheckinAt || null,
      lastCheckinDate: st.lastCheckinDate || "",
      lastResult: st.lastResult || null,
      lastError: st.lastError || "",
      history: Array.isArray(st.history) ? st.history.slice(0, 500) : [],
    });
  }
  return S.accounts;
}

function findAccount(id) {
  for (var i = 0; i < S.accounts.length; i++) {
    if (S.accounts[i].id === id) return S.accounts[i];
  }
  return null;
}

/* ---------------- HTTP 封装（acck_device cookie 管理） ---------------- */

function baseHeaders(extra) {
  var h = {
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36",
    accept: "application/json, text/plain, */*",
    "accept-language": "zh-CN,zh;q=0.9",
    referer: HTTP_BASE + "/login",
    origin: HTTP_BASE,
  };
  if (S.deviceCookie) {
    h.cookie = "acck_device=" + S.deviceCookie;
  }
  var keys = extra ? Object.keys(extra) : [];
  for (var i = 0; i < keys.length; i++) h[keys[i]] = extra[keys[i]];
  return h;
}

// 从响应头捕获 acck_device cookie
function captureDeviceCookie(resp) {
  var v = core.extractDeviceCookie(resp);
  if (v && v !== S.deviceCookie) {
    S.deviceCookie = v;
    persistCore();
    console.log("[acck-checkin] acck_device cookie updated");
  }
}

// 用响应 Date 头校准本地时钟与 ACCK 服务端时钟的偏差（TOTP 需要同源时间）
// 限制 ±300s：超过视为异常（Date 头解析失败/被篡改），不采用
function calibrateTime(res) {
  var dateStr = null;
  try {
    if (res && res.headers && typeof res.headers.get === "function") {
      dateStr = res.headers.get("date");
    }
  } catch (e) {
    return;
  }
  if (!dateStr) return;
  var serverMs = Date.parse(String(dateStr));
  if (!isFinite(serverMs)) return;
  var offset = serverMs - Date.now();
  if (Math.abs(offset) <= 300000) {
    var prev = S.serverTimeOffsetMs;
    S.serverTimeOffsetMs = offset;
    if (Math.abs(offset - prev) >= 1000) {
      console.log("[acck-checkin] clock offset vs ACCK: " + Math.round(offset / 1000) + "s");
    }
  } else {
    console.log("[acck-checkin] abnormal clock offset ignored: " + Math.round(offset / 1000) + "s");
  }
}

// 校准后的当前 Unix 秒（以 ACCK 服务端时钟为准）
function serverNowSec() {
  return Math.floor((Date.now() + S.serverTimeOffsetMs) / 1000);
}

function httpTimeoutMs() {
  return clampNum(S.config ? S.config.http_timeout : 30, 5, 120, 30) * 1000;
}

// 单次请求（带超时中断）
async function fetchOnce(url, opts) {
  var controller = new AbortController();
  var timer = setTimeout(function () { controller.abort(); }, httpTimeoutMs());
  try {
    return await fetch(url, {
      method: opts.method || "GET",
      headers: opts.headers,
      body: opts.body,
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timer);
  }
}

// 请求 ACCK API；自动管理 device cookie（多账号共用）；返回 {status, text, json}
//   GET 请求遇到网络错误会自动重试一次（读接口幂等，可提升弱网下的成功率）
async function acckReq(pathName, method, bodyObj, token) {
  var headers = baseHeaders();
  var hasBody = bodyObj !== undefined && bodyObj !== null;
  if (hasBody) headers["Content-Type"] = "application/json";
  if (token) headers.Authorization = "Bearer " + token;

  var verb = method || "GET";
  var res = null;
  var lastErr = null;
  var tries = verb === "GET" ? 2 : 1;
  for (var t = 0; t < tries; t++) {
    try {
      res = await fetchOnce(HTTP_BASE + pathName, {
        method: verb,
        headers: headers,
        body: hasBody ? JSON.stringify(bodyObj) : undefined,
      });
      lastErr = null;
      break;
    } catch (e) {
      lastErr = e;
      if (t < tries - 1) await sleep(800);
    }
  }
  if (!res) throw new Error("网络请求失败: " + (lastErr ? lastErr.message : "unknown"));

  captureDeviceCookie(res);
  calibrateTime(res);
  var text = await res.text();
  var j = null;
  try { j = JSON.parse(text); } catch (e) {}
  return { status: res.status, text: text, json: j };
}

/* ---------------- 登录流程（按账号） ---------------- */

async function fetchChallenge() {
  var r = await acckReq("/api/security/challenge?action=login");
  if (r.status !== 200 || !r.json || !r.json.parameters) {
    throw new Error("获取安全挑战失败: " + clip(r.text || ("HTTP " + r.status), 160));
  }
  return r.json;
}

// 提交 2FA 动态码：正常用当前窗口；若当前窗口仅剩极少秒数（易跨窗口失败）再补试上一窗口一次
async function submit2fa(acc, mfaToken) {
  var cfg = S.config || {};
  var period = clampNum(cfg.totp_period, 5, 300, 30);
  var opts = {
    algorithm: cfg.totp_algorithm || "SHA1",
    digits: cfg.totp_digits,
    period: period,
  };
  var nowSec = serverNowSec();
  var remain = core.totpRemainSec(period, nowSec);
  var times = [nowSec];
  if (remain <= 5) times.push(nowSec - period);   // 临界窗口：服务端可能仍在校验上一窗口

  var lastText = "";
  var lastStatus = 0;
  for (var i = 0; i < times.length; i++) {
    var code = core.generateTotp(acc.totpSecret, {
      algorithm: opts.algorithm, digits: opts.digits, period: opts.period, time: times[i],
    });
    var vf = await acckReq("/api/user/login/2fa", "POST", { mfa_token: mfaToken, code: code });
    var vbody = vf.json || {};
    if (vf.status === 200 && vbody.token) return { token: vbody.token, via2fa: true };
    lastText = vf.text;
    lastStatus = vf.status;
    var blocked = core.parseLoginError(vbody, vf.status);
    if (blocked) {
      await markIpBlocked(blocked.blockedUntil, blocked.message);
      throw new Error("2FA 验证受限: " + blocked.message);
    }
    if (times.length > 1 && i === 0) {
      console.log("[acck-checkin] 2FA 首次校验失败（窗口临界），尝试上一窗口");
    }
  }
  throw new Error(
    "2FA 验证失败: " + clip(lastText || ("HTTP " + lastStatus), 160) +
    "；已按 ACCK 服务器时间生成动态码(本地偏差 " + Math.round(S.serverTimeOffsetMs / 1000) + "s)，" +
    "若持续失败请在管理页用「时间与 TOTP 自检」核对密钥"
  );
}

// 登录指定账号（含自动 2FA），返回 {token, via2fa}
async function loginFlow(acc) {
  if (!acc.email || !acc.password) {
    throw new Error("账号未配置邮箱或密码");
  }
  // 登录前先检查是否处于 IP 限流期（避免加剧封禁并连累其他账号）
  if (isIpBlocked()) {
    throw new Error(ipBlockedMsg("") + "，已跳过登录尝试");
  }
  var challenge = await fetchChallenge();
  var solution = core.solveAltcha(challenge.parameters);
  var payload = core.buildAltchaPayload(challenge, solution);
  var login = await acckReq("/api/user/login", "POST", {
    email: acc.email,
    password: acc.password,
    turnstile_token: payload,
  });
  var body = login.json || {};

  // IP 级登录限流识别（同一 IP 登录失败次数过多）
  var blocked = core.parseLoginError(body, login.status);
  if (blocked) {
    await markIpBlocked(blocked.blockedUntil, blocked.message);
    throw new Error("登录受限: " + blocked.message);
  }
  if (login.status === 200 && body.token) {
    rememberToken(acc, body.token);
    return { token: body.token, via2fa: false };
  }

  // 2FA 判定（真实响应可能只有 mfa_token，无 requires_2fa 标志）
  var needs2fa = body.requires_2fa === "1" || body.requires_2fa === true || body.requires_2fa === "true" || !!body.mfa_token;
  if (needs2fa && body.mfa_token) {
    if (!acc.totpSecret) {
      throw new Error("账号开启了 2FA，但未配置 TOTP 密钥");
    }
    var r2 = await submit2fa(acc, body.mfa_token);
    rememberToken(acc, r2.token);
    return r2;
  }
  if (body.requires_2fa_setup === "1" || body.requires_2fa_setup === true) {
    throw new Error("账号要求先完成 2FA 绑定设置（请先在网站安全设置中绑定验证器）");
  }
  if (body.requires_password_upgrade === "1" || body.requires_password_upgrade === true) {
    throw new Error("账号要求升级密码（请先在网站完成密码升级）");
  }
  if (login.status === 401) {
    throw new Error("登录失败: 邮箱或密码错误");
  }
  throw new Error("登录失败: " + clip(login.text || ("HTTP " + login.status), 160));
}

// 记录账号 Token 及其实际有效期（解析 JWT 的 exp/iat，实测 ACCK 登录 Token 有效期为 7 天）
function rememberToken(acc, token) {
  acc.token = token;
  acc.tokenAt = Date.now();
  var info = null;
  try { info = core.jwtInfo(token); } catch (e) { info = null; }
  acc.tokenExp = info && info.exp ? info.exp : 0;                                  // unix 秒
  acc.tokenLifeSec = info && info.exp && info.iat ? Math.max(0, info.exp - info.iat) : 0;
}

// 获取有效 Token：优先按 Token 自身有效期（JWT exp）判断，留出提前刷新余量；
//   token_cache_min > 0 时作为缓存上限叠加约束；无法解析 JWT 时回退到固定时长
async function ensureToken(acc, force) {
  var cfg = S.config || {};
  var marginSec = Math.max(0, toNum(cfg.token_exp_margin_min, 10)) * 60;
  var cacheMin = toNum(cfg.token_cache_min, 0);
  if (!force && acc.token) {
    var nowSec = Math.floor(Date.now() / 1000);
    var ok = true;
    if (acc.tokenExp > 0) {
      ok = nowSec < acc.tokenExp - marginSec;   // 仍在 JWT 有效期内（留余量）
    } else {
      var fallbackMin = cacheMin > 0 ? cacheMin : 360; // 无法解析时回退（默认 6 小时）
      ok = (Date.now() - acc.tokenAt) < fallbackMin * 60 * 1000;
    }
    if (ok && cacheMin > 0) {
      ok = (Date.now() - acc.tokenAt) < cacheMin * 60 * 1000; // 用户设定的缓存上限
    }
    if (ok) return acc.token;
  }
  var r = await loginFlow(acc);
  return r.token;
}

/* ---------------- 签到（按账号） ---------------- */

function recordHistory(acc, parsed, status) {
  var entry = {
    at: new Date().toISOString(),
    kind: parsed.kind,
    message: parsed.message,
    status: status,
  };
  acc.history.unshift(entry);
  // 条数上限可配置：0 = 不限制（内部仍有 500 条硬上限，防止状态文件无限膨胀）
  var keep = toNum((S.config || {}).checkin_history_keep, 0);
  var cap = keep > 0 ? Math.min(keep, 500) : 500;
  if (acc.history.length > cap) acc.history.length = cap;
  acc.lastResult = { kind: parsed.kind, message: parsed.message, at: entry.at };
  acc.lastError = parsed.kind === "ok" || parsed.kind === "already" ? "" : parsed.message;
  persistCore();
}

// 执行单账号签到（不重试），返回解析结果
async function doCheckin(acc, force) {
  acc.lastCheckinAt = new Date().toISOString();
  var token;
  try {
    token = await ensureToken(acc, !!force);
  } catch (e) {
    throw new Error("登录失败: " + e.message);
  }
  var r = await acckReq("/api/auth/user/ac-shop/checkin", "POST", {}, token);
  if (r.status === 401) {
    // token 失效：强制重新登录后重试一次
    token = await ensureToken(acc, true);
    r = await acckReq("/api/auth/user/ac-shop/checkin", "POST", {}, token);
  }
  var parsed = core.parseCheckinResult(r.json, r.status);
  recordHistory(acc, parsed, r.status);
  return parsed;
}

/* ---------------- 通知 ---------------- */

function pushNotifyLog(entry) {
  var item = {
    at: entry.at || new Date().toISOString(),
    channel: entry.channel,
    title: clip(entry.title, 120),
    ok: !!entry.ok,
  };
  if (entry.error) item.error = clip(entry.error, 160);
  S.notifyLog.unshift(item);
  S.notifyLog = S.notifyLog.slice(0, 500);
  persistCore();
}

async function komariNotify(title, message) {
  try {
    await server.call("admin:sendNotification", {
      event: {
        event: title,
        clients: [],
        time: new Date().toISOString(),
        message: message,
        emoji: "",
      },
    });
    pushNotifyLog({ channel: "komari", title: title, ok: true });
  } catch (e) {
    pushNotifyLog({ channel: "komari", title: title, ok: false, error: e.message });
    throw e;
  }
}

// 按钮形态归一化：
//   1) [{label, url}]            —— 配置中的简单按钮
//   2) [[{text, url|callback_data}]] —— 原始 inline_keyboard（含 callback 按钮）
function normalizeKeyboard(buttons) {
  if (!buttons || !buttons.length) return [];
  if (Array.isArray(buttons[0])) return buttons;
  var rows = [];
  for (var i = 0; i < buttons.length; i++) {
    if (buttons[i] && buttons[i].label) rows.push([{ text: buttons[i].label, url: buttons[i].url }]);
  }
  return rows;
}

// Telegram 单条消息上限 4096 字符，超出会被接口拒绝
function tgClamp(text) {
  var t = String(text || "");
  return t.length > 3900 ? t.slice(0, 3900) + "\n…（内容过长已截断）" : t;
}

async function tgSend(text, buttons) {
  var cfg = S.config || {};
  if (!cfg.tg_bot_token || !cfg.tg_chat_id) return { skipped: true };
  var base = String(cfg.tg_api_base || "https://api.telegram.org").replace(/\/+$/, "");
  var body = { chat_id: cfg.tg_chat_id, text: tgClamp(text), disable_web_page_preview: true };
  var keyboard = normalizeKeyboard(buttons);
  if (keyboard.length) body.reply_markup = JSON.stringify({ inline_keyboard: keyboard });
  try {
    var res = await fetchOnce(base + "/bot" + cfg.tg_bot_token + "/sendMessage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    var txt = await res.text();
    if (!res.ok) {
      pushNotifyLog({ channel: "tg", title: text, ok: false, error: "HTTP " + res.status + ": " + clip(txt, 120) });
      throw new Error("TG HTTP " + res.status + ": " + clip(txt, 160));
    }
    pushNotifyLog({ channel: "tg", title: text, ok: true });
    return { ok: true };
  } catch (e) {
    if (String(e.message || "").indexOf("TG HTTP") !== 0) {
      pushNotifyLog({ channel: "tg", title: text, ok: false, error: clip(e.message, 120) });
    }
    throw e;
  }
}

function parseTgButtons(cfg) {
  var out = [];
  var raw = String(cfg.tg_buttons || "").trim();
  if (!raw) return out;
  var items = raw.split(",");
  for (var i = 0; i < items.length; i++) {
    var parts = items[i].split("|");
    if (parts.length >= 2 && parts[0].trim() && parts[1].trim()) {
      out.push({ label: parts[0].trim(), url: parts[1].trim() });
    }
  }
  return out;
}

// 统一推送入口（走现有通知渠道：Komari 站点通知 + 自定义 TG）
async function notifyRaw(title, text, tgButtons) {
  var cfg = S.config || {};
  if (toBool(cfg.use_komari_notify, true)) {
    try { await komariNotify(title, text); } catch (e) {
      console.log("[acck-checkin] komari notify failed: " + e.message);
    }
  }
  if (cfg.tg_bot_token && cfg.tg_chat_id) {
    try { await tgSend(text, tgButtons && tgButtons.length ? tgButtons : parseTgButtons(cfg)); } catch (e) {
      console.log("[acck-checkin] tg notify failed: " + e.message);
    }
  }
}

// 单账号签到结果通知（文案只出现脱敏邮箱，不含任何敏感字段）
async function notifyResult(acc, result) {
  var cfg = S.config || {};
  var emoji = result.kind === "ok" ? "🎉" : result.kind === "already" ? "📌" : "⚠️";
  var label = acc.emailMasked + (acc.name ? "（" + acc.name + "）" : "");
  var title = "ACCK 签到 " + (result.kind === "ok" ? "成功" : result.kind === "already" ? "已签到" : "失败");
  var text =
    emoji + " " + title +
    "\n账号: " + label +
    "\n结果: " + result.message +
    "\n时间: " + nowStr();

  if (toBool(cfg.use_komari_notify, true)) {
    try { await komariNotify(title, text); } catch (e) {
      console.log("[acck-checkin] komari notify failed: " + e.message);
    }
  }
  if (cfg.tg_bot_token && cfg.tg_chat_id) {
    try { await tgSend(text, parseTgButtons(cfg)); } catch (e) {
      console.log("[acck-checkin] tg notify failed: " + e.message);
    }
  }
}

// 签到汇总通知：无论 1 个还是多个账号，批量结束后统一发这一条（不再逐账号推送）
async function notifySummary(items) {
  var cfg = S.config || {};
  if (!toBool(cfg.notify_summary, true)) return;
  if (!items || !items.length) return;
  var ok = 0, already = 0, fail = 0;
  var okLines = [], failLines = [], alreadyNames = [];
  for (var i = 0; i < items.length; i++) {
    var acc = items[i].acc;
    var r = items[i].result || {};
    if (r.kind === "ok") {
      ok++;
      okLines.push("✅ " + acc.emailMasked + "：" + clip(r.message, 60));
    } else if (r.kind === "already") {
      already++;
      alreadyNames.push(acc.emailMasked);
    } else {
      fail++;
      failLines.push("❌ " + acc.emailMasked + "：" + clip(r.message, 120));
    }
  }
  var lines = ["📋 ACCK 批量签到汇总"];
  lines.push("成功 " + ok + " · 已签到 " + already + " · 失败 " + fail + " · 共 " + items.length + " 个账号");
  if (okLines.length) lines.push("");
  for (var a = 0; a < Math.min(okLines.length, 8); a++) lines.push(okLines[a]);
  if (okLines.length > 8) lines.push("…另有 " + (okLines.length - 8) + " 个账号成功");
  for (var j = 0; j < Math.min(failLines.length, 8); j++) lines.push(failLines[j]);
  if (failLines.length > 8) lines.push("…另有 " + (failLines.length - 8) + " 个账号失败");
  if (alreadyNames.length) lines.push("📌 今日已完成: " + alreadyNames.slice(0, 8).join("、") + (alreadyNames.length > 8 ? " 等" : ""));
  lines.push("");
  lines.push("🕒 " + nowStr());

  var title = "ACCK 批量签到汇总";
  var text = lines.join("\n");
  if (toBool(cfg.use_komari_notify, true)) {
    try { await komariNotify(title, text); } catch (e) {}
  }
  if (cfg.tg_bot_token && cfg.tg_chat_id) {
    try { await tgSend(text, parseTgButtons(cfg)); } catch (e) {}
  }
}

/* ---------------- 签到调度 ---------------- */

// 单账号签到（带重试，不发通知——通知统一由批量汇总发送，避免频繁推送）
// 返回 { kind, message }
async function attemptCheckinAccount(acc, reason) {
  var retryTimes = clampNum((S.config || {}).retry_times, 1, 10, 3);
  var retryInterval = clampNum((S.config || {}).retry_interval_sec, 5, 3600, 300);

  var result = null;
  var attempts = 0;
  for (var i = 0; i < retryTimes; i++) {
    attempts = i + 1;
    // IP 限流期间不重试（避免加剧封禁），并保留原始限流信息（含解封时间）
    if (isIpBlocked()) {
      var baseMsg = (result && result.message) ? result.message : ipBlockedMsg("");
      if (baseMsg.indexOf("限流") < 0 && baseMsg.indexOf("受限") < 0) {
        baseMsg += "（IP 限流期至 " + core.fmtUnixLocal(S.ipBlockedUntil) + "，已停止重试）";
      } else if (baseMsg.indexOf("停止重试") < 0) {
        baseMsg += "（已停止重试，解封后自动恢复）";
      }
      result = { kind: "fail", message: baseMsg };
      break;
    }
    try {
      // 允许复用缓存 Token（仅在 Token 过期/无效时才重新登录），避免每次签到都登录触发风控
      var parsed = await doCheckin(acc, false);
      result = parsed;
      if (parsed.kind === "ok" || parsed.kind === "already") break;
    } catch (e) {
      result = { kind: "fail", message: e.message };
      acc.lastResult = { kind: "fail", message: e.message, at: new Date().toISOString() };
      acc.lastError = e.message;
      persistCore();
      // 触发 IP 限流后立即停止重试，不必空等重试间隔
      if (isIpBlocked()) continue;
    }
    if (i < retryTimes - 1) {
      console.log("[acck-checkin] " + acc.emailMasked + " attempt " + attempts + " failed (" + clip(result.message, 100) + "), retry in " + retryInterval + "s");
      await sleep(retryInterval * 1000);
    }
  }

  if (result && (result.kind === "ok" || result.kind === "already")) {
    acc.lastCheckinDate = todayKey();
    persistCore();
  }
  if (attempts > 1 && result && result.kind !== "ok" && result.kind !== "already") {
    recordHistory(acc, { kind: "fail", message: "重试 " + attempts + " 次后失败: " + result.message }, null);
  }

  // 不在这里逐账号发通知：全部账号完成后由 notifySummary 统一发一条汇总（含单账号场景）
  return result;
}

function summarizeBatch(items, reason) {
  var ok = 0, already = 0, fail = 0;
  for (var i = 0; i < items.length; i++) {
    var k = items[i].result && items[i].result.kind;
    if (k === "ok") ok++;
    else if (k === "already") already++;
    else fail++;
  }
  return { at: new Date().toISOString(), reason: reason || "manual", total: items.length, ok: ok, already: already, fail: fail };
}

// 批量签到：顺序执行，账号之间留间隔；返回 {items:[{acc,result}]}
async function runAllAccounts(reason) {
  if (S.busy) return { skipped: true, items: [] };
  S.busy = true;
  var interval = clampNum((S.config || {}).account_interval_sec, 0, 3600, 10);
  var onlyPending = reason === "cron" || reason === "catchup";
  var key = todayKey();
  var items = [];
  S.progress = {
    running: true, done: 0, total: S.accounts.length, current: "",
    startedAt: new Date().toISOString(), reason: reason || "manual",
  };
  try {
    for (var i = 0; i < S.accounts.length; i++) {
      var acc = S.accounts[i];
      // 定时/补跑跳过今日已完成的账号（但记入汇总，保证汇总数字准确）
      if (onlyPending && acc.lastCheckinDate === key) {
        items.push({ acc: acc, result: { kind: "already", message: "今日已完成" } });
        S.progress.done = items.length;
        continue;
      }
      // IP 限流期间直接跳过剩余账号（避免继续失败，连累其他账号）
      if (isIpBlocked()) {
        items.push({ acc: acc, result: { kind: "fail", message: ipBlockedMsg("") + "，已跳过" } });
        S.progress.done = items.length;
        continue;
      }
      if (items.length > 0 && interval > 0) await sleep(interval * 1000);
      S.progress.current = acc.emailMasked + (acc.name ? "（" + acc.name + "）" : "");
      var r = null;
      try {
        r = await attemptCheckinAccount(acc, reason);
      } catch (e) {
        r = { kind: "fail", message: e.message };
      }
      items.push({ acc: acc, result: r || { kind: "fail", message: "未知错误" } });
      S.progress.done = items.length;
    }
    // 统一汇总通知：不论账号多少，每次批量只发这一条
    try { await notifySummary(items); } catch (e) {}
    S.lastBatch = summarizeBatch(items, reason);
    console.log("[acck-checkin] batch(" + reason + ") done: " + items.length + " 账号，" +
      "成功 " + S.lastBatch.ok + " 已签到 " + S.lastBatch.already + " 失败 " + S.lastBatch.fail);
  } finally {
    S.busy = false;
    S.progress.running = false;
    S.progress.current = "";
    persistCore();
    applyPendingConfigReload();
  }
  return { items: items };
}

// 每日签到调度：自适应循环（每 60 秒检查一次）
// 好处：checkin_time / timezone_offset / checkin_enabled 改动即时生效，无需重启插件
function applySchedules() {
  if (S.cronLoopStarted) return;
  S.cronLoopStarted = true;

  // 当前时刻（按配置时区）是否已到达今日签到时间
  function checkinDue(cfg) {
    if (!toBool(cfg.checkin_enabled, true)) return false;
    var m = String(cfg.checkin_time || "09:00").match(/^(\d{1,2}):(\d{2})$/);
    var hh = 9, mm = 0;
    if (m) {
      hh = clampNum(m[1], 0, 23, 9);
      mm = clampNum(m[2], 0, 59, 0);
    }
    var d = new Date(Date.now() + toNum(cfg.timezone_offset, 8) * 3600 * 1000);
    return d.getUTCHours() * 60 + d.getUTCMinutes() >= hh * 60 + mm;
  }

  function tick() {
    refreshConfig().then(function () {
      var cfg = S.config || {};
      var key = todayKey();
      if (checkinDue(cfg) && S.lastCronDay !== key) {
        // 只有仍有余下未签到账号时才跑（全部已完成时跳过，避免重复发汇总）
        var need = false;
        for (var i = 0; i < S.accounts.length; i++) {
          if (S.accounts[i].lastCheckinDate !== key) { need = true; break; }
        }
        if (need && !S.busy) {
          S.lastCronDay = key;
          runAllAccounts("cron").then(function (r) {
            console.log("[acck-checkin] cron batch done: " + (r && r.items ? r.items.length : 0));
          }).catch(function (e) {
            console.log("[acck-checkin] cron batch error: " + e.message);
          });
        }
      }
    }).catch(function (e) {
      console.log("[acck-checkin] cron tick error: " + e.message);
    }).then(function () {
      setTimeout(tick, 60 * 1000);
    });
  }

  setTimeout(tick, 10 * 1000);
}

/* ---------------- 交易所监控（AC 交易区） ---------------- */

// 拉取交易区上架列表（公开接口，无需登录）
async function fetchExchangeListings(limit, offset) {
  var q = "?limit=" + clampNum(limit, 1, 200, 100) + "&offset=" + Math.max(0, toNum(offset, 0));
  var r = await acckReq("/api/exchange/listings" + q);
  if (r.status !== 200 || !r.json || !Array.isArray(r.json.listings)) {
    throw new Error("获取交易区列表失败: " + clip(r.text || ("HTTP " + r.status), 160));
  }
  var out = [];
  for (var i = 0; i < r.json.listings.length; i++) {
    var l = core.parseListing(r.json.listings[i]);
    if (l && l.id && l.status === "active") out.push(l);
  }
  return { items: out, hasMore: !!r.json.has_more, nextOffset: r.json.next_offset };
}

function exchangeState() {
  if (!S.state.exchange || typeof S.state.exchange !== "object") S.state.exchange = {};
  var e = S.state.exchange;
  if (!Array.isArray(e.seenIds)) e.seenIds = [];
  if (!Array.isArray(e.boughtIds)) e.boughtIds = [];
  if (!Array.isArray(e.newLog)) e.newLog = [];
  if (!Array.isArray(e.buyLog)) e.buyLog = [];
  if (!Array.isArray(e.pendingBuys)) e.pendingBuys = [];   // 待购队列（本轮未及购买，下轮补买）
  if (typeof e.baselineDone !== "boolean") e.baselineDone = false;
  if (!e.lastPollAt) e.lastPollAt = null;
  if (typeof e.lastPollCount !== "number") e.lastPollCount = 0;
  if (typeof e.lastNewCount !== "number") e.lastNewCount = 0;
  if (typeof e.lastNotifiedCount !== "number") e.lastNotifiedCount = 0;
  if (!e.lastError) e.lastError = "";
  return e;
}

function exchangeCfg() {
  var cfg = S.config || {};
  var scope = String(cfg.exchange_notify_scope || "all").trim().toLowerCase();
  if (scope !== "rules") scope = "all";
  return {
    enabled: toBool(cfg.exchange_enabled, false),
    pollSec: clampNum(cfg.exchange_poll_sec, 30, 3600, 60),
    // ---- 推送 ----
    notifyNew: toBool(cfg.exchange_notify_new, true),
    notifyScope: scope,   // all=推送所有新上架；rules=仅推送命中「推送规则」的
    ignoreBlocked: toBool(cfg.exchange_ignore_blocked, true),   // 推送：是否跳过被墙机器
    baseline: toBool(cfg.exchange_first_run_baseline, true),
    keep: clampNum(cfg.exchange_keep, 20, 2000, 200),
    buyLink: String(cfg.exchange_buy_link || "").trim() || "https://acck.io/console/exchange?q={q}",
    // ---- 自动交易（与推送独立）----
    tradeIgnoreBlocked: toBool(cfg.auto_trade_ignore_blocked, true),   // 交易：是否跳过被墙机器
    autoBuy: toBool(cfg.exchange_auto_buy, true),   // 总闸默认开启；日常控制由规则的「自动购买=是」决定
    autoBuyAccount: String(cfg.exchange_auto_buy_account || "").trim(),
    maxBuyPerPoll: clampNum(cfg.exchange_max_buy_per_poll, 1, 5, 1),
    // ---- TG 内联购买按钮 ----
    tgBuy: toBool(cfg.tg_buy_enabled, true),
    tgConfirm: toBool(cfg.tg_confirm_buy, true),   // 二次确认防误点
  };
}

// 是否已成功购买过该上架（以成功记录为准，失败允许重试）
function hasBought(es, id) {
  var n = toNum(id, 0);
  for (var i = 0; i < es.boughtIds.length; i++) {
    if (toNum(es.boughtIds[i], -1) === n) return true;
  }
  for (var j = 0; j < es.buyLog.length; j++) {
    var b = es.buyLog[j];
    if (b && toNum(b.id, -1) === n && b.ok) return true;
  }
  return false;
}

function markBought(es, id) {
  var n = toNum(id, 0);
  if (!n) return;
  if (!hasBought(es, n)) es.boughtIds.push(n);
  if (es.boughtIds.length > 500) es.boughtIds = es.boughtIds.slice(-500);
}

// 新上架推送文案；withLink=true 时在正文附购买链接（用于无按钮的 Komari 通知渠道），
// TG 渠道由按钮承载链接，传 false 以避免与按钮重复
function formatNewListingText(l, ec, ruleName, withLink) {
  var lines = [];
  lines.push("🆕 ACCK 交易区新上架机器");
  if (ruleName) lines.push("命中规则: " + ruleName);
  lines.push("节点: " + (l.nodeName || "-") + (l.areaName ? "（" + l.areaName + "）" : ""));
  lines.push("套餐: " + (l.planName || "-"));
  var conf = core.formatListingConfig(l);
  if (conf) lines.push("配置: " + conf);
  lines.push("价格: ¥" + core.centsToYuan(l.priceCents).toFixed(2) +
    (l.renewPriceCents ? "（续费 ¥" + core.centsToYuan(l.renewPriceCents).toFixed(2) + "）" : ""));
  if (l.ipStatus) lines.push("IP状态: " + (l.ipStatus === "blocked" ? "⚠️ 已被墙" : "正常"));
  if (l.dueTimeUnix) lines.push("到期: " + core.fmtUnixLocal(l.dueTimeUnix).slice(0, 10));
  if (l.introText) lines.push("介绍: " + String(l.introText).replace(/\n/g, " ").slice(0, 120));
  lines.push("上架: " + core.fmtListingTime(l.createdAt));
  lines.push("上架ID: " + l.id);
  if (withLink) lines.push("🔗 " + core.buildBuyLink(ec.buyLink, l));
  return lines.join("\n");
}

// 自动购买成功/失败文案
function formatBuyResultText(l, acc, ok, message, ruleName) {
  var title = ok ? "✅ ACCK 交易区自动购买成功" : "❌ ACCK 交易区自动购买失败";
  var lines = [title];
  if (ruleName) lines.push("命中规则: " + ruleName);
  lines.push("节点: " + (l.nodeName || "-") + (l.areaName ? "（" + l.areaName + "）" : ""));
  lines.push("套餐: " + (l.planName || "-"));
  var conf = core.formatListingConfig(l);
  if (conf) lines.push("配置: " + conf);
  lines.push(ok ? "成交价: ¥" + core.centsToYuan(l.priceCents).toFixed(2) : "标价: ¥" + core.centsToYuan(l.priceCents).toFixed(2));
  lines.push("账号: " + (acc ? acc.emailMasked : "-"));
  lines.push("机器ID: " + (l.serverId || l.id));
  lines.push("结果: " + message);
  return lines.join("\n");
}

// 选择用于自动购买的账号（配置指定 id 或 邮箱，为空则取第一个）
function pickBuyAccount(ec) {
  if (!S.accounts.length) return null;
  var key = String(ec.autoBuyAccount || "").trim().toLowerCase();
  if (!key) return S.accounts[0];
  for (var i = 0; i < S.accounts.length; i++) {
    var a = S.accounts[i];
    if (a.id.toLowerCase() === key || a.email.toLowerCase() === key || a.emailMasked.toLowerCase() === key) return a;
  }
  return null;
}

// 执行自动购买（返回 {ok, message, priceCents}）
async function autoBuyListing(l, acc) {
  var token;
  try {
    token = await ensureToken(acc, false);
  } catch (e) {
    return { ok: false, message: "登录失败: " + e.message };
  }
  var r = await acckReq("/api/auth/user/exchange/listing/" + l.id + "/buy", "POST", {}, token);
  var j = r.json || {};
  if (r.status === 200) {
    var msg = j.message && typeof j.message === "string" ? j.message : "购买成功";
    return { ok: true, message: msg, priceCents: l.priceCents };
  }
  if (r.status === 401) {
    // token 失效：强制重新登录再试一次
    try {
      token = await ensureToken(acc, true);
      r = await acckReq("/api/auth/user/exchange/listing/" + l.id + "/buy", "POST", {}, token);
      j = r.json || {};
      if (r.status === 200) {
        return { ok: true, message: (j.message && String(j.message)) || "购买成功", priceCents: l.priceCents };
      }
    } catch (e) {
      return { ok: false, message: "重试登录失败: " + e.message };
    }
  }
  var errMsg = (j.error || j.message || ("HTTP " + r.status));
  return { ok: false, message: clip(errMsg, 200) };
}

// 统一的自动购买执行（记录 + 通知），被"新上架即时购买"与"待购队列补买"共用
async function doAutoBuy(l, hit, acc, source) {
  var es = exchangeState();
  var br = await autoBuyListing(l, acc);
  if (br.ok) markBought(es, l.id);
  es.buyLog.unshift({
    at: new Date().toISOString(), id: l.id, node: l.nodeName, plan: l.planName,
    priceCents: l.priceCents, serverId: l.serverId, account: acc.emailMasked,
    ok: br.ok, message: br.message, rule: hit && hit.name ? hit.name : "", source: source || "auto",
  });
  if (es.buyLog.length > 50) es.buyLog.length = 50;
  persistCore();
  try {
    await notifyRaw(
      br.ok ? "ACCK 交易区自动购买成功" : "ACCK 交易区自动购买失败",
      formatBuyResultText(l, acc, br.ok, br.message, hit && hit.name)
    );
  } catch (e) {}
  console.log("[acck-checkin] 自动购买 " + (br.ok ? "成功" : "失败") +
    " 规则=" + (hit && hit.name ? hit.name : "-") + " listing=" + l.id + " " + clip(br.message, 80));
  return br;
}

// 入队「待购」（本轮未及购买：每轮上限已满、或签到批量进行中），下一轮优先补买
function enqueuePendingBuy(es, l, hit) {
  for (var i = 0; i < es.pendingBuys.length; i++) {
    if (toNum(es.pendingBuys[i].id, 0) === l.id) return;
  }
  es.pendingBuys.push({ id: l.id, at: Date.now(), rule: hit && hit.name ? hit.name : "" });
}

// 交易所轮询主流程
async function runExchangePoll(reason) {
  var ec = exchangeCfg();
  if (!ec.enabled && reason !== "manual") return { skipped: true };
  if (S.exPollBusy) return { skipped: true, busy: true };
  S.exPollBusy = true;
  var es = exchangeState();
  var result = { checked: 0, newItems: 0, notified: 0, bought: 0, deferred: 0, baseline: false };
  try {
    // 取最新一批（交易所按价格升序返回，故同时按 created_at 排序取最新）
    var res = await fetchExchangeListings(100, 0);
    var items = res.items;
    result.checked = items.length;
    var seen = {};
    for (var i = 0; i < es.seenIds.length; i++) seen[String(es.seenIds[i])] = true;

    // 首轮：建立基线（默认不推送历史机器；可在配置中关闭「首轮仅建立基线」改为直接推送）
    if (!es.baselineDone) {
      if (ec.baseline) {
        for (var b = 0; b < items.length; b++) seen[String(items[b].id)] = true;
        es.seenIds = Object.keys(seen).slice(-Math.max(200, ec.keep * 5));
        es.baselineDone = true;
        es.lastPollAt = new Date().toISOString();
        es.lastPollCount = items.length;
        es.lastNewCount = 0;
        es.lastNotifiedCount = 0;
        es.lastError = "";
        persistCore();
        result.baseline = true;
        console.log("[acck-checkin] 交易区监控已建立基线（" + items.length + " 条，不推送历史）");
        return result;
      }
      // 未开启「首轮仅建立基线」：把当前在架机器也视为新上架，直接推送
      console.log("[acck-checkin] 「首轮仅建立基线」已关闭：本轮将当前在架 " + items.length + " 台机器按新上架处理");
    }

    // 新上架 = 未在 seenIds 中的条目；按上架时间升序处理，保证先到先得
    var fresh = [];
    for (var k = 0; k < items.length; k++) {
      if (!seen[String(items[k].id)]) fresh.push(items[k]);
    }
    fresh.sort(function (x, y) { return String(x.createdAt).localeCompare(String(y.createdAt)); });
    result.newItems = fresh.length;

    // 双规则集（互不干扰）：
    //   tradeRules = 自动交易规则列表（ex_rules），只决定是否自动购买
    //   notify     = 推送规则列表（ex_notify_rules 优先；未填写则回退 ex_rules），只决定是否推送
    var tradeRules = exchangeRules();
    var tradeFallback = fallbackRuleCond(ec);
    var notifySet = notifyRules();
    var notifyFallback = notifyFallbackCond();
    var buyAcc = ec.autoBuy ? pickBuyAccount(ec) : null;
    var buyAttempts = 0;   // 本轮购买尝试计数（含失败，受每轮上限约束）

    // ---------- A) 先补处理上几轮「未及购买」的机器（每轮上限或签到进行中而延后） ----------
    if (ec.autoBuy && buyAcc) {
      var pending = es.pendingBuys.slice();
      es.pendingBuys = [];
      for (var p = 0; p < pending.length; p++) {
        var pitem = pending[p];
        if (hasBought(es, pitem.id)) continue;                          // 已买过 → 丢弃
        if (Date.now() - (pitem.at || 0) > 2 * 3600 * 1000) continue;   // 超 2 小时 → 丢弃
        var pl = null;
        for (var q = 0; q < items.length; q++) {
          if (items[q].id === toNum(pitem.id, 0)) { pl = items[q]; break; }
        }
        if (!pl) continue;                                              // 已售出/下架 → 丢弃
        var phit = tradeRules.length ? core.matchFirstRule(pl, tradeRules, tradeFallback, false) : null;
        if (!phit || !phit.autoBuy) continue;                            // 交易规则不再允许 → 丢弃
        if (ec.tradeIgnoreBlocked && pl.ipStatus === "blocked") continue; // 自动交易的被墙过滤
        if (S.busy) { es.pendingBuys.push(pitem); continue; }           // 签到进行中 → 继续延后
        if (buyAttempts >= ec.maxBuyPerPoll) { es.pendingBuys.push(pitem); continue; }
        buyAttempts++;
        var pb = await doAutoBuy(pl, phit, buyAcc, "auto");
        if (pb && pb.ok) result.bought++;
      }
    }

    // ---------- B) 处理本轮新上架（推送 + 购买 / 入队） ----------
    for (var n = 0; n < fresh.length; n++) {
      var l = fresh[n];
      seen[String(l.id)] = true;
      es.seenIds.push(l.id);

      // 推送匹配：按「推送规则」判定；规则列表为空时依赖「推送范围=all」兜底
      var notifyHit = notifySet.rules.length
        ? core.matchFirstRule(l, notifySet.rules, notifyFallback, false) : null;
      // 交易匹配：按「自动交易」规则判定，不影响推送
      var tradeHit = tradeRules.length
        ? core.matchFirstRule(l, tradeRules, tradeFallback, false) : null;

      // 推送：按「推送范围」决定——all=推送所有新上架；rules=仅推送命中推送规则的机器。
      // 被墙过滤分两套：推送用「忽略已被墙的机器（推送）」，交易用「自动交易」内的同名开关。
      var notifyBlockedSkip = ec.ignoreBlocked && l.ipStatus === "blocked";
      var doNotify = ec.notifyNew && !notifyBlockedSkip &&
        (ec.notifyScope === "rules" ? !!notifyHit : true);
      var ruleName = notifyHit ? notifyHit.name : (tradeHit ? tradeHit.name : "");
      if (doNotify) {
        try {
          await notifyNewListing(l, ec, ruleName, null);
          es.newLog.unshift({
            at: new Date().toISOString(), id: l.id, node: l.nodeName, plan: l.planName,
            priceCents: l.priceCents, area: l.areaName, ipStatus: l.ipStatus,
            renewPriceCents: l.renewPriceCents, rule: ruleName,
          });
          if (es.newLog.length > 50) es.newLog.length = 50;
          result.notified++;
        } catch (e) {
          console.log("[acck-checkin] 交易区新上架通知失败: " + e.message);
        }
        persistCore();
      }

      // 自动购买：仅当命中自动交易规则且该规则标记「自动购买=是」且总闸开启
      var tradeBlockedSkip = ec.tradeIgnoreBlocked && l.ipStatus === "blocked";
      if (ec.autoBuy && tradeHit && tradeHit.autoBuy && !tradeBlockedSkip && !hasBought(es, l.id)) {
        if (!buyAcc) {
          console.log("[acck-checkin] 自动购买跳过：未找到可用账号");
        } else if (S.busy) {
          enqueuePendingBuy(es, l, tradeHit);   // 签到批量进行中：延后到下一轮，避免并发登录
          result.deferred++;
        } else if (buyAttempts < ec.maxBuyPerPoll) {
          buyAttempts++;
          var nb = await doAutoBuy(l, tradeHit, buyAcc, "auto");
          if (nb && nb.ok) result.bought++;
        } else {
          enqueuePendingBuy(es, l, tradeHit);   // 本轮上限已满：排队到下一轮继续抢
          result.deferred++;
        }
      }
    }

    // pending 队列过期清理（避免无限累积）
    var alivePending = [];
    for (var t = 0; t < es.pendingBuys.length; t++) {
      if (Date.now() - (es.pendingBuys[t].at || 0) <= 2 * 3600 * 1000) alivePending.push(es.pendingBuys[t]);
    }
    es.pendingBuys = alivePending.slice(-200);

    var allSeen = Object.keys(seen);
    es.seenIds = allSeen.slice(-Math.max(200, ec.keep * 5));
    es.baselineDone = true;
    es.lastPollAt = new Date().toISOString();
    es.lastPollCount = items.length;
    es.lastNewCount = fresh.length;
    es.lastNotifiedCount = result.notified;
    es.lastError = "";
    persistCore();
    console.log("[acck-checkin] 交易区轮询(" + reason + ") 完成：检查 " + result.checked + " 条，新上架 " +
      result.newItems + " 条，推送 " + result.notified + " 条，成交 " + result.bought + " 单，待购 " +
      es.pendingBuys.length + " 台");
  } catch (e) {
    es.lastError = e.message;
    persistCore();
    console.log("[acck-checkin] 交易区轮询失败: " + e.message);
    result.error = e.message;
  } finally {
    S.exPollBusy = false;
  }
  return result;
}

// 新上架推送：Komari 渠道在正文附链接；TG 渠道用按钮承载链接（避免正文与按钮重复）
//   opts.test = true 时为"测试推送"（标题标注、不带购买按钮，仅用于检测通知链路）
async function notifyNewListing(l, ec, ruleName, opts) {
  var cfg = S.config || {};
  var isTest = !!(opts && opts.test);
  var title = isTest ? "ACCK 交易区测试推送" : "ACCK 交易区新上架";
  var head = isTest ? "🧪 测试推送（用于检测通知链路）\n" : "";
  var tail = isTest && opts.note ? "\n" + opts.note : "";
  var textWithLink = head + formatNewListingText(l, ec, ruleName, true) + tail;
  var textNoLink = head + formatNewListingText(l, ec, ruleName, false) + tail;

  if (toBool(cfg.use_komari_notify, true)) {
    try { await komariNotify(title, textWithLink); } catch (e) {
      console.log("[acck-checkin] komari notify failed: " + e.message);
    }
  }
  if (cfg.tg_bot_token && cfg.tg_chat_id) {
    var buttons = isTest ? tgViewOnlyButtons(l, ec) : tgBuyButtons(l, ec);
    try { await tgSend(textNoLink, buttons); } catch (e) {
      console.log("[acck-checkin] tg notify failed: " + e.message);
    }
  }
}

// 仅"打开交易区查看"按钮（测试推送用，避免误触下单）
function tgViewOnlyButtons(l, ec) {
  return [[{ text: "📄 打开交易区查看", url: core.buildBuyLink(ec.buyLink, l) }]];
}

/* ---------------- TG 一键购买（内联按钮 + 回调轮询） ---------------- */

// Telegram Bot API 通用调用（带超时中断）；
// useGet=true 时以 GET + query 参数调用（getUpdates 必须用 GET）
async function tgApiCall(method, payload, useGet) {
  var cfg = S.config || {};
  if (!cfg.tg_bot_token) throw new Error("未配置 tg_bot_token");
  var base = String(cfg.tg_api_base || "https://api.telegram.org").replace(/\/+$/, "");
  var url = base + "/bot" + cfg.tg_bot_token + "/" + method;
  var res;
  if (useGet) {
    var qs = [];
    var pk = payload ? Object.keys(payload) : [];
    for (var i = 0; i < pk.length; i++) {
      qs.push(encodeURIComponent(pk[i]) + "=" + encodeURIComponent(String(payload[pk[i]])));
    }
    res = await fetchOnce(url + (qs.length ? "?" + qs.join("&") : ""), { method: "GET" });
  } else {
    res = await fetchOnce(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload || {}),
    });
  }
  var txt = await res.text();
  var j = null;
  try { j = JSON.parse(txt); } catch (e) {}
  if (!res.ok || !j || j.ok === false) {
    throw new Error("TG " + method + " 失败: " + clip((j && j.description) || txt, 160));
  }
  return j.result;
}

// 回调轮询状态（持久化 offset，避免重复处理）
function tgState() {
  if (!S.state.tg || typeof S.state.tg !== "object") S.state.tg = {};
  var t = S.state.tg;
  if (typeof t.offset !== "number") t.offset = 0;
  if (!t.lastPollAt) t.lastPollAt = null;
  if (!t.lastError) t.lastError = "";
  if (typeof t.buyCount !== "number") t.buyCount = 0;
  return t;
}

// 允许触发一键购买的会话白名单（tg_buy_allowed_chats 与 tg_chat_id；未配置则拒绝）
function isAllowedChat(chatId, username) {
  var cfg = S.config || {};
  var raw = String(cfg.tg_buy_allowed_chats || "") + "," + String(cfg.tg_chat_id || "");
  var arr = raw.split(/[,，;；\s]+/);
  var list = [];
  for (var i = 0; i < arr.length; i++) {
    var s = arr[i].trim().toLowerCase();
    if (s) list.push(s);
  }
  if (!list.length) return false;
  var id = String(chatId);
  var uname = username ? ("@" + String(username).toLowerCase()) : "";
  for (var j = 0; j < list.length; j++) {
    if (list[j] === id) return true;
    if (uname && list[j] === uname) return true;
  }
  return false;
}

async function tgAnswerCallback(callbackId, text, alert) {
  try {
    await tgApiCall("answerCallbackQuery", { callback_query_id: callbackId, text: clip(text, 190), show_alert: !!alert }, false);
  } catch (e) {
    console.log("[acck-checkin] answerCallbackQuery 失败: " + e.message);
  }
}

// 推送消息的 TG 内联按钮：
//   开启「二次确认」时首按钮为 confirmbuy:<id>（先点它弹出确认按钮，再点确认才下单），防误点；
//   关闭时首按钮直接为 buy:<id>（一键下单）。
function tgBuyButtons(l, ec) {
  var cfg = S.config || {};
  var rows = [];
  var priceTxt = "¥" + core.centsToYuan(l.priceCents).toFixed(2);
  if (toBool(cfg.tg_buy_enabled, true)) {
    if (ec.tgConfirm) {
      rows.push([{ text: "🛒 购买 " + priceTxt + "（需二次确认）", callback_data: "confirmbuy:" + l.id }]);
    } else {
      rows.push([{ text: "🛒 一键购买 " + priceTxt, callback_data: "buy:" + l.id }]);
    }
  }
  rows.push([{ text: "📄 打开交易区查看", url: core.buildBuyLink(ec.buyLink, l) }]);
  return rows;
}

// 修改推送消息的按钮（二次确认 / 取消 / 下单后收尾）。
// extra=追加到原消息正文末尾的说明；keepView=true 时保留「打开交易区查看」按钮（需要 ec+listing）。
// 失败只记日志：不影响下单或取消本身的结果。
async function tgEditConfirmButtons(cqMsg, extra, keepView, ec, listing) {
  if (!cqMsg || !cqMsg.message_id || !cqMsg.chat) return false;
  var body = String(cqMsg.text || "").replace(/\s+$/, "") + (extra ? "\n\n" + extra : "");
  var payload = { chat_id: cqMsg.chat.id, message_id: cqMsg.message_id, text: tgClamp(body) };
  if (keepView && ec && listing) {
    payload.reply_markup = { inline_keyboard: tgViewOnlyButtons(listing, ec) };
  }
  try {
    await tgApiCall("editMessageText", payload, false);
    return true;
  } catch (e) {
    console.log("[acck-checkin] 更新原消息按钮失败（不影响操作结果）: " + e.message);
    return false;
  }
}

// 处理 TG 回调（一键购买）
async function handleTgCallback(cq) {
  var data = String((cq && cq.data) || "");
  var from = (cq && cq.from) ? cq.from : {};
  var chatId = (cq && cq.message && cq.message.chat && cq.message.chat.id) || from.id;
  if (!isAllowedChat(chatId, from.username)) {
    await tgAnswerCallback(cq.id, "无权限：该会话不在允许列表中", true);
    return;
  }

  // ---- 取消：删除原消息按钮（无需二次确认） ----
  var mc = /^cancel:(\d+)$/.exec(data);
  if (mc) {
    await tgAnswerCallback(cq.id, "已取消：未执行购买。若该机器仍在架，可重新点击「🛒 购买」再下单");
    await tgEditConfirmButtons(cq.message, "ℹ️ 已取消下单（未扣费）", false);
    return;
  }

  // ---- 二次确认第一步：把「🛒 购买」按钮换成「✅ 确认下单 / ❌ 取消」 ----
  var mcc = /^confirmbuy:(\d+)$/.exec(data);
  if (mcc) {
    var confirmId = toNum(mcc[1], 0);
    if (!cq.message || !cq.message.message_id || !cq.message.chat) {
      await tgAnswerCallback(cq.id, "无法更新原消息按钮：请直接点「📄 打开交易区查看」下单", true);
      return;
    }
    var esPre = exchangeState();
    if (hasBought(esPre, confirmId)) {
      await tgAnswerCallback(cq.id, "该机器已经购买过了", true);
      return;
    }
    await tgApiCall("editMessageText", {
      chat_id: cq.message.chat.id, message_id: cq.message.message_id,
      text: tgClamp(String(cq.message.text || "").replace(/\s+$/, "") + "\n\n⚠️ 请再次确认是否下单购买上架 " + confirmId + "："),
      reply_markup: {
        inline_keyboard: [[
          { text: "✅ 确认下单：" + confirmId, callback_data: "buy:" + confirmId },
          { text: "❌ 取消", callback_data: "cancel:" + cq.message.message_id },
        ]],
      },
    }, false);
    await tgAnswerCallback(cq.id, "请点击「✅ 确认下单」执行购买，或点「❌ 取消」放弃");
    return;
  }

  var m = /^buy:(\d+)$/.exec(data);
  if (!m) {
    await tgAnswerCallback(cq.id, "未知操作");
    return;
  }
  var id = toNum(m[1], 0);
  var es = exchangeState();
  var ec = exchangeCfg();

  // 幂等：已成功购买过该上架则拒绝（失败记录不阻止重试）
  if (hasBought(es, id)) {
    await tgAnswerCallback(cq.id, "该机器已经购买过了", true);
    return;
  }
  if (S.tgBuyBusy) {
    await tgAnswerCallback(cq.id, "上一笔购买正在处理中，请稍候", true);
    return;
  }
  S.tgBuyBusy = true;
  try {
    await tgAnswerCallback(cq.id, "已收到，正在执行购买…");
    var res = await fetchExchangeListings(200, 0);
    var target = null;
    for (var i = 0; i < res.items.length; i++) {
      if (res.items[i].id === id) { target = res.items[i]; break; }
    }
    if (!target) {
      es.buyLog.unshift({
        at: new Date().toISOString(), id: id, node: "-", plan: "-", priceCents: 0, serverId: 0,
        account: "-", ok: false, message: "点击购买失败：该上架已不存在（可能已被购买或下架）", source: "tg",
      });
      if (es.buyLog.length > 50) es.buyLog.length = 50;
      persistCore();
      await tgEditConfirmButtons(cq.message, "❌ 下单失败：上架 " + id + " 已不存在（可能已被购买或下架）", false);
      await notifyRaw("ACCK 交易区点击购买失败", "上架 ID " + id + " 已不存在（可能已被购买或下架）");
      return;
    }
    // 安全校验：上架仍存在于交易区 + 未被购买过 + 会话在允许列表。
    // 注意：规则列表只决定「自动购买」与「按规则推送」，不拦截人工点击——
    // 推送范围可能为「全部」，此时被推送的机器未必命中规则，但点击是明确的购买意图。
    var rules = exchangeRules();
    var fallback = fallbackRuleCond(ec);
    var hit = rules.length ? core.matchFirstRule(target, rules, fallback, ec.autoBuy) : null;
    var acc = pickBuyAccount(ec);
    if (!acc) {
      await tgAnswerCallback(cq.id, "无可用账号", true);
      return;
    }
    var br = await autoBuyListing(target, acc);
    if (br.ok) markBought(es, target.id);
    es.buyLog.unshift({
      at: new Date().toISOString(), id: target.id, node: target.nodeName, plan: target.planName,
      priceCents: target.priceCents, serverId: target.serverId, account: acc.emailMasked,
      ok: br.ok, message: br.message, rule: hit ? hit.name : "", source: "tg",
    });
    if (es.buyLog.length > 50) es.buyLog.length = 50;
    var ts = tgState();
    if (br.ok) ts.buyCount++;
    persistCore();
    // 下单收尾：把推送消息的购买按钮收掉，避免重复点击（失败不影响结果）
    await tgEditConfirmButtons(cq.message,
      (br.ok ? "✅ 已下单：" : "❌ 下单失败：") + br.message, true, ec, target);
    await tgAnswerCallback(cq.id,
      br.ok ? ("购买成功：" + target.nodeName + " ¥" + core.centsToYuan(target.priceCents).toFixed(2))
        : ("购买失败：" + br.message), !br.ok);
    await notifyRaw(br.ok ? "ACCK 交易区点击购买成功" : "ACCK 交易区点击购买失败",
      formatBuyResultText(target, acc, br.ok, br.message, hit ? hit.name : ""));
  } catch (e) {
    console.log("[acck-checkin] 点击购买异常: " + e.message);
    await tgAnswerCallback(cq.id, "执行异常: " + e.message, true);
  } finally {
    S.tgBuyBusy = false;
  }
}

// 轮询 TG updates（仅处理 callback_query），处理一键购买点击
async function tgPollUpdates() {
  var cfg = S.config || {};
  if (!cfg.tg_bot_token || !toBool(cfg.tg_buy_enabled, true)) return { skipped: true };
  var ts = tgState();
  try {
    var updates = await tgApiCall("getUpdates", {
      offset: ts.offset,
      timeout: 0,
      limit: 20,
      allowed_updates: JSON.stringify(["callback_query"]),
    }, true);
    ts.lastPollAt = new Date().toISOString();
    ts.lastError = "";
    if (Array.isArray(updates) && updates.length) {
      for (var i = 0; i < updates.length; i++) {
        var u = updates[i];
        if (u.update_id !== undefined) ts.offset = u.update_id + 1;
        if (u.callback_query) {
          try { await handleTgCallback(u.callback_query); } catch (e) {
            console.log("[acck-checkin] 回调处理失败: " + e.message);
          }
        }
      }
      persistCore();
    }
    return { ok: true, handled: updates ? updates.length : 0 };
  } catch (e) {
    ts.lastError = e.message;
    persistCore();
    // webhook 冲突等错误只在变化时打印，避免刷日志
    if (String(ts.lastError).indexOf("webhook") >= 0) {
      console.log("[acck-checkin] TG 回调轮询失败（该 Bot 已设置 webhook，一键购买不可用）: " + clip(ts.lastError, 120));
    } else {
      console.log("[acck-checkin] TG 回调轮询失败: " + e.message);
    }
    return { error: e.message };
  }
}

/* ---------------- 交易区规则与筛选 ---------------- */

// 交易规则列表（自动交易专用：只决定是否自动购买，不影响推送）
// 解析失败/为空时返回空数组
function exchangeRules() {
  var cfg = S.config || {};
  try {
    return core.parseRules(cfg.ex_rules || "");
  } catch (e) {
    console.log("[acck-checkin] 交易规则列表解析失败: " + e.message);
    return [];
  }
}

// 推送规则列表（只决定是否推送，不影响自动交易）
// 优先级：ex_notify_rules（推送规则）> ex_rules（交易规则）——
//   仅当「推送范围=rules」且未填写「推送规则」时，才回退匹配交易规则列表
// 返回 {rules, source}：source 为 "notify"(推送规则) / "trade"(回退交易规则) / "none"
function notifyRules() {
  var cfg = S.config || {};
  try {
    var nr = core.parseRules(cfg.ex_notify_rules || "");
    if (nr.length) return { rules: nr, source: "notify" };
    var tr = core.parseRules(cfg.ex_rules || "");
    return { rules: tr, source: tr.length ? "trade" : "none" };
  } catch (e) {
    console.log("[acck-checkin] 推送规则解析失败: " + e.message);
    return { rules: [], source: "none" };
  }
}

// 规则列表为空/未命中时的兜底条件。
// 仅用于交易匹配——把 tradeIgnoreBlocked 注入规则条目，使配置了交易规则后
// 被墙过滤开关依然生效（推送的被墙过滤由主循环 blockedSkip 显式处理）
function fallbackRuleCond(ec) {
  return { ignoreBlocked: !!ec.tradeIgnoreBlocked };
}

// 推送匹配用的空条件：被墙过滤由主循环 blockedSkip 显式处理，避免重复判定
function notifyFallbackCond() {
  return {};
}

// 条件摘要文本（管理页展示）
function summarizeCond(c) {
  var parts = [];
  if (c.area) parts.push("地区:" + c.area);
  if (c.node) parts.push("节点:" + c.node);
  if (c.plan) parts.push("套餐:" + c.plan);
  if (c.network) parts.push("网络:" + c.network);
  if (c.keywords) parts.push("关键字:" + c.keywords);
  if (c.cpu) parts.push("CPU" + c.cpu + "核");
  if (c.mem) parts.push("内存" + c.mem + "MB");
  if (c.disk) parts.push("硬盘" + c.disk + "GB");
  if (c.flow) parts.push("流量" + c.flow + "GB");
  if (c.bw) parts.push("带宽" + c.bw + "Mbps");
  if (c.buyPrice) parts.push("购买价" + c.buyPrice + "元");
  if (c.renewPrice) parts.push("续费价" + c.renewPrice + "元");
  if (c.ignoreBlocked) parts.push("忽略被墙");
  return parts.length ? parts.join(" · ") : "不限（全部上架）";
}

// 交易所推送链路自检：把「为什么没收到推送」的可能原因直接列出来
function exchangeDiagnose(ec, es) {
  var out = [];
  var cfg = S.config || {};
  var tradeRules = exchangeRules();
  var notifySet = notifyRules();
  if (!ec.enabled) {
    out.push({ level: "error", text: "「启用交易所监控」处于关闭状态：不会轮询交易区，也不会有任何推送。请在插件配置中打开该开关（开启即生效，无需重启插件）" });
    return out;
  }
  out.push({ level: "ok", text: "监控已启用，每 " + ec.pollSec + " 秒检查一次交易区" });

  if (ec.baseline && !es.baselineDone) {
    out.push({ level: "warn", text: "基线尚未建立：首轮检查只记录当前在架机器、不推送；请等待下一轮检查完成后再有新上架推送（或点「重建基线」立即刷新）" });
  } else if (!ec.baseline && !es.baselineDone) {
    out.push({ level: "ok", text: "「首轮仅建立基线」已关闭：首次检查即把当前在架机器按新上架推送" });
  }

  if (es.lastPollAt) {
    out.push({ level: "ok", text: "最近一次检查：" + core.fmtUnixLocal(Math.floor(new Date(es.lastPollAt).getTime() / 1000)) +
      "，在架 " + (es.lastPollCount || 0) + " 台，新上架 " + (es.lastNewCount || 0) + " 台，已推送 " + (es.lastNotifiedCount || 0) + " 台" });
  } else {
    out.push({ level: "warn", text: "还没有任何一次检查记录：轮询可能尚未启动，请稍等 30 秒后刷新，或点「立即检查交易区」手动触发一次" });
  }

  if (!ec.notifyNew) {
    out.push({ level: "error", text: "「推送新上架机器」处于关闭状态：即使发现新上架也不会发送通知" });
  }

  // 推送范围 + 推送规则来源
  if (ec.notifyScope === "rules") {
    if (notifySet.source === "notify") {
      out.push({ level: "ok", text: "推送范围：仅命中「推送规则」的机器（已配置 " + notifySet.rules.length + " 条推送规则）" });
    } else if (notifySet.source === "trade") {
      out.push({ level: "ok", text: "推送范围：仅命中「自动交易」规则的机器（未填写推送规则，已回退使用 " + notifySet.rules.length + " 条自动交易规则）" });
    } else {
      out.push({ level: "warn", text: "推送范围：按规则，但推送规则与自动交易规则均为空：不会推送任何机器" });
    }
  } else {
    out.push({ level: "ok", text: "推送范围：所有新上架机器（推送规则与自动交易规则均不影响推送）" });
  }
  out.push({ level: "ok", text: "忽略已被墙的机器：推送=" + (ec.ignoreBlocked ? "开启" : "关闭") +
    "｜自动交易=" + (ec.tradeIgnoreBlocked ? "开启" : "关闭") });

  if (!toBool(cfg.use_komari_notify, true) && !(cfg.tg_bot_token && cfg.tg_chat_id)) {
    out.push({ level: "error", text: "Komari 站点通知与自定义 TG Bot 均未开启：没有任何可用的推送渠道" });
  }

  // TG 内联购买与二次确认
  if (cfg.tg_bot_token && cfg.tg_chat_id && toBool(cfg.tg_buy_enabled, true)) {
    out.push({ level: "ok", text: "TG 内联购买按钮已开启：" + (ec.tgConfirm
      ? "二次确认模式（先点「🛒 购买」弹出「✅ 确认下单 / ❌ 取消」，防误点）"
      : "一键下单模式（点击即下单，无二次确认）") });
    if (String(tgState().lastError || "").indexOf("webhook") >= 0) {
      out.push({ level: "warn", text: "TG 回调轮询报 webhook 相关错误：该 Bot 已设置 webhook，内联购买按钮将无响应" });
    }
  } else {
    out.push({ level: "warn", text: "TG 内联购买按钮未启用或未配置 Bot/Chat ID：推送消息中不会出现「🛒 购买」按钮，只能点「📄 打开交易区查看」" });
  }

  // 自动交易规则
  var buyCnt = 0;
  for (var i = 0; i < tradeRules.length; i++) if (tradeRules[i].autoBuy) buyCnt++;
  if (tradeRules.length) {
    out.push({ level: "ok", text: "已配置 " + tradeRules.length + " 条自动交易规则，其中 " + buyCnt + " 条标记「自动购买=是」" });
  } else {
    out.push({ level: ec.autoBuy ? "warn" : "ok", text: "自动交易规则为空：任何机器都不会自动购买" +
      (ec.autoBuy ? "（但「自动购买」总闸处于开启状态，请补充规则）" : "") });
  }
  if (ec.autoBuy && buyCnt === 0 && tradeRules.length) {
    out.push({ level: "warn", text: "「自动购买」总闸已开启，但没有任何交易规则标记「自动购买=是」：实际不会下单" });
  }

  if (es.lastNewCount > 0 && es.lastNotifiedCount === 0 && es.lastPollAt) {
    var causes = [];
    if (!ec.notifyNew) causes.push("「推送新上架机器」开关关闭");
    if (ec.notifyScope === "rules" && !notifySet.rules.length) {
      causes.push("推送范围「按规则」，但推送规则与自动交易规则均为空");
    } else if (ec.notifyScope === "rules" && notifySet.rules.length) {
      causes.push("推送范围「按规则」，新上架均未命中" + (notifySet.source === "notify" ? "任何推送规则" : "任何回退的自动交易规则") + "（请检查规则条件是否过于严格）");
    }
    if (ec.ignoreBlocked) causes.push("新上架均被标记为被墙，且「忽略已被墙的机器（推送）」处于开启");
    out.push({ level: "warn", text: "上一轮发现 " + es.lastNewCount + " 台新上架但推送 0 台：可能原因——" +
      (causes.length ? causes.join("；") : "通知渠道未配置") });
  }
  if (es.lastError) {
    out.push({ level: "error", text: "上一轮检查报错：" + es.lastError });
  }
  return out;
}

// 交易区监控状态摘要（管理页用，脱敏）
function exchangeStatusPayload() {
  var ec = exchangeCfg();
  var es = exchangeState();
  var cfg = S.config || {};
  var ts = tgState();
  var tradeRules = exchangeRules();
  var notifySet = notifyRules();
  var ruleRows = [];
  for (var i = 0; i < tradeRules.length; i++) {
    ruleRows.push({ name: tradeRules[i].name || ("规则" + (i + 1)), autoBuy: !!tradeRules[i].autoBuy, condSummary: summarizeCond(tradeRules[i].cond) });
  }
  var notifyRows = [];
  for (var j = 0; j < notifySet.rules.length; j++) {
    notifyRows.push({ name: notifySet.rules[j].name || ("规则" + (j + 1)), autoBuy: !!notifySet.rules[j].autoBuy, condSummary: summarizeCond(notifySet.rules[j].cond) });
  }
  return {
    status: "success",
    enabled: ec.enabled,
    pollSec: ec.pollSec,
    busy: S.exPollBusy,
    baselineDone: es.baselineDone,
    lastPollAt: es.lastPollAt,
    lastPollCount: es.lastPollCount || 0,
    lastNewCount: es.lastNewCount || 0,
    lastNotifiedCount: es.lastNotifiedCount || 0,
    lastError: es.lastError,
    baselineMode: ec.baseline,
    diagnose: exchangeDiagnose(ec, es),
    seenCount: es.seenIds.length,
    notifyScope: ec.notifyScope,
    notifyRulesCount: notifySet.rules.length,
    notifyRulesSource: notifySet.source,
    notifyRules: notifyRows,          // 推送规则（含回退来源标记）
    filterSource: ec.notifyScope === "rules"
      ? (notifySet.source === "notify" ? ("按推送规则推送（" + notifySet.rules.length + " 条）")
        : (notifySet.source === "trade" ? ("推送规则为空，回退按自动交易规则推送（" + notifySet.rules.length + " 条）")
        : "按规则推送（推送规则与自动交易规则均为空：不推送任何机器）"))
      : "推送全部新上架（推送规则与自动交易规则均不影响推送）",
    ignoreBlocked: ec.ignoreBlocked,
    notifyNew: ec.notifyNew,
    autoBuy: ec.autoBuy,
    autoBuyAccount: ec.autoBuyAccount || (S.accounts[0] ? S.accounts[0].emailMasked : ""),
    autoTradeIgnoreBlocked: ec.tradeIgnoreBlocked,
    pendingBuys: (es.pendingBuys || []).slice(0, 20).map(function (p) {
      return { id: p.id, rule: p.rule || "", at: new Date(p.at || 0).toISOString() };
    }),
    pendingCount: (es.pendingBuys || []).length,
    buyLink: ec.buyLink,
    maxBuyPerPoll: ec.maxBuyPerPoll,
    rules: ruleRows,                 // 自动交易规则列表
    rulesCount: tradeRules.length,
    checkinHistoryKeep: toNum(cfg.checkin_history_keep, 0),
    tgBuy: {
      enabled: toBool(cfg.tg_buy_enabled, true),
      confirm: !!ec.tgConfirm,
      pollSec: clampNum(cfg.tg_buy_poll_sec, 3, 120, 10),
      busy: S.tgBuyBusy,
      lastPollAt: ts.lastPollAt,
      lastError: ts.lastError || "",
      buyCount: ts.buyCount,
      allowedChats: String(cfg.tg_buy_allowed_chats || "") || "(沿用 TG 接收 Chat ID)",
      configured: !!(cfg.tg_bot_token && cfg.tg_chat_id),
    },
    newLog: es.newLog,
    buyLog: es.buyLog,
    accounts: S.accounts.map(function (a) { return { id: a.id, emailMasked: a.emailMasked, name: a.name }; }),
  };
}

// 配置签名：用于检测配置页改动后自动生效（账号列表 / 交易所开关与间隔 / TG 一键购买）
function configSignature(cfg) {
  cfg = cfg || {};
  return [
    cfg.accounts || "", cfg.acck_email || "", cfg.acck_password || "", cfg.acck_totp_secret || "",
    cfg.checkin_enabled, cfg.checkin_time || "", cfg.timezone_offset, cfg.account_interval_sec,
    cfg.retry_times, cfg.retry_interval_sec, cfg.checkin_history_keep,
    cfg.totp_algorithm || "", cfg.totp_digits, cfg.totp_period,
    cfg.token_cache_min, cfg.token_exp_margin_min,
    cfg.exchange_enabled, cfg.exchange_poll_sec, cfg.exchange_notify_new, cfg.exchange_notify_scope,
    cfg.exchange_first_run_baseline, cfg.exchange_ignore_blocked, cfg.exchange_keep,
    cfg.exchange_auto_buy, cfg.exchange_auto_buy_account, cfg.exchange_max_buy_per_poll,
    cfg.auto_trade_ignore_blocked, cfg.ex_rules || "", cfg.ex_notify_rules || "",
    cfg.tg_buy_enabled, cfg.tg_confirm_buy, cfg.tg_buy_poll_sec, cfg.tg_bot_token ? "s" : "", cfg.tg_chat_id || "",
    cfg.exchange_buy_link || "", cfg.tg_buy_allowed_chats || "",
    cfg.notify_summary, cfg.use_komari_notify, cfg.notify_log_keep, cfg.http_timeout,
  ].join("|");
}

// 重载账号列表（保留已缓存的有效 Token，避免重载后被迫重新登录）
function reloadAccountsKeepTokens() {
  var old = {};
  for (var i = 0; i < S.accounts.length; i++) {
    if (S.accounts[i].token) {
      old[S.accounts[i].id] = {
        token: S.accounts[i].token, tokenAt: S.accounts[i].tokenAt,
        tokenExp: S.accounts[i].tokenExp, tokenLifeSec: S.accounts[i].tokenLifeSec,
      };
    }
  }
  S.accounts = [];
  loadAccountsFromConfig();
  for (var j = 0; j < S.accounts.length; j++) {
    var o = old[S.accounts[j].id];
    if (o) {
      S.accounts[j].token = o.token;
      S.accounts[j].tokenAt = o.tokenAt;
      S.accounts[j].tokenExp = o.tokenExp;
      S.accounts[j].tokenLifeSec = o.tokenLifeSec;
    }
  }
}

// 周期性刷新配置：配置页保存后立即生效，无需重启插件
// 解决：启用「交易所监控」/ 修改轮询间隔 / 增删账号后不重启插件就不生效的问题
// 注意：签到批量进行中不重载账号（重载发生在批量结束后，避免中途打断正在执行的签到）
var cfgRefreshPromise = null;
var cfgRefreshedAt = 0;

async function refreshConfig() {
  // 8 秒内重复调用直接复用结果（三个调度循环都会调用，避免并发拉配置）
  if (cfgRefreshedAt && Date.now() - cfgRefreshedAt < 8000) return S.config;
  if (cfgRefreshPromise) return cfgRefreshPromise;
  cfgRefreshPromise = (async function () {
    try {
      var cfg = await server.getConfig();
      if (!cfg) return S.config;
      S.config = cfg;
      var sig = configSignature(cfg);
      if (sig === S.configSig) return cfg;
      S.configSig = sig;
      if (S.busy) {
        S.configChanged = true;   // 待批量签到结束后再重载账号
        return cfg;
      }
      reloadAccountsKeepTokens();
      console.log("[acck-checkin] 配置已更新生效：账号 " + S.accounts.length + " 个，交易所监控 " +
        (toBool(cfg.exchange_enabled, false) ? "开" : "关") + "（每 " + toNum(cfg.exchange_poll_sec, 60) + "s）");
      return cfg;
    } catch (e) {
      console.log("[acck-checkin] 配置刷新失败: " + e.message);
      return S.config;
    } finally {
      cfgRefreshedAt = Date.now();
      cfgRefreshPromise = null;
    }
  })();
  return cfgRefreshPromise;
}

// 批量签到结束后应用期间发生的配置变更（重载账号列表）
function applyPendingConfigReload() {
  if (!S.configChanged) return;
  S.configChanged = false;
  reloadAccountsKeepTokens();
  console.log("[acck-checkin] 批量签到结束，已重载最新账号列表（" + S.accounts.length + " 个）");
}

// 交易所轮询调度：自适应循环（每次重新读取配置，故开关/间隔改动即时生效，无需重启插件）
function applyExchangeSchedule() {
  if (S.exPollLoopStarted) return;
  S.exPollLoopStarted = true;

  function tick() {
    refreshConfig().then(function () {
      if (!toBool((S.config || {}).exchange_enabled, false)) {
        // 未启用时低频复查配置（开关一打开立即生效）
        setTimeout(tick, 30 * 1000);
        return;
      }
      runExchangePoll("cron").then(function () {
        var next = clampNum((S.config || {}).exchange_poll_sec, 30, 3600, 60) * 1000;
        setTimeout(tick, next);
      }).catch(function () {
        setTimeout(tick, 30 * 1000);
      });
    }).catch(function () {
      setTimeout(tick, 30 * 1000);
    });
  }

  setTimeout(tick, 5 * 1000);
}

// 轮询调度：TG 回调轮询（处理「一键购买」按钮点击）——自适应循环，配置改动即时生效
function applyTgSchedule() {
  if (S.tgPollLoopStarted) return;
  S.tgPollLoopStarted = true;

  function tick() {
    var cfg = S.config || {};
    if (cfg.tg_bot_token && cfg.tg_chat_id && toBool(cfg.tg_buy_enabled, true)) {
      tgPollUpdates().catch(function (e) {
        console.log("[acck-checkin] TG 回调轮询异常: " + e.message);
      });
    }
    setTimeout(tick, clampNum((S.config || {}).tg_buy_poll_sec, 3, 120, 10) * 1000);
  }

  setTimeout(tick, 3 * 1000);
}

/* ---------------- 路由与生命周期 ---------------- */

function isAdmin(req) {
  var p = req.context && req.context.principal;
  return !!(p && (p.type === "user" || p.type === "api_key" || (p.roles && p.roles.indexOf("admin") >= 0)));
}

function sendJson(res, code, obj) {
  res.statusCode = code;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.end(JSON.stringify(obj));
}

function forbid(res) {
  sendJson(res, 403, { status: "error", message: "forbidden" });
}

// 脱敏后的账号摘要（不含密码 / TOTP / 完整邮箱）
function accountSummary(acc) {
  var nowSec = Math.floor(Date.now() / 1000);
  var tokenValid = !!(acc.token && acc.tokenExp > nowSec);
  return {
    id: acc.id,
    idx: acc.idx,
    name: acc.name,
    emailMasked: acc.emailMasked,
    hasPassword: !!acc.password,
    hasTotp: acc.hasTotp,
    lastCheckinDate: acc.lastCheckinDate,
    lastCheckinAt: acc.lastCheckinAt,
    lastResult: acc.lastResult,
    lastError: acc.lastError,
    tokenCached: tokenValid,
    tokenExpireIn: tokenValid ? (acc.tokenExp - nowSec) : 0,
    tokenExp: acc.tokenExp || 0,
    tokenExpStr: acc.tokenExp ? core.fmtUnixLocal(acc.tokenExp) : "",
    tokenLifeDays: acc.tokenLifeSec ? Math.round(acc.tokenLifeSec / 864) / 100 : 0,
    historyCount: acc.history.length,
    history: acc.history.slice(0, 20),
  };
}

function statusPayload() {
  var cfg = S.config || {};
  var summaries = [];
  var doneToday = 0;
  var tokenCached = 0;
  var today = todayKey();
  for (var i = 0; i < S.accounts.length; i++) {
    var a = S.accounts[i];
    summaries.push(accountSummary(a));
    if (a.lastCheckinDate === today) doneToday++;
    if (a.token && a.tokenExp > Math.floor(Date.now() / 1000)) tokenCached++;
  }
  var nextAt = nextCheckinAt();
  return {
    status: "success",
    app: "acck-checkin",
    version: PLUGIN_VERSION,
    serverTime: new Date().toISOString(),
    todayKey: today,
    accountCount: S.accounts.length,
    accountDoneToday: doneToday,
    tokenCachedCount: tokenCached,
    skippedLines: S.skippedLines,
    busy: S.busy,
    progress: S.progress,
    lastBatch: S.lastBatch || S.state.lastBatch || null,
    nextCheckinAt: nextAt ? new Date(nextAt * 1000).toISOString() : null,
    nextCheckinInSec: nextAt ? Math.max(0, nextAt - Math.floor(Date.now() / 1000)) : 0,
    deviceCookieSet: !!(S.deviceCookie || S.state.deviceCookie),
    clockOffsetSec: Math.round(S.serverTimeOffsetMs / 1000),
    ipBlocked: isIpBlocked(),
    ipBlockedUntil: isIpBlocked() ? core.fmtUnixLocal(S.ipBlockedUntil) : "",
    accounts: summaries,
    notifyLog: S.notifyLog,
    config: {
      accountsConfigured: S.accounts.length,
      legacySingleAccount: !String(cfg.accounts || "").trim() && !!cfg.acck_email,
      totp_algorithm: cfg.totp_algorithm || "SHA1",
      totp_period: clampNum(cfg.totp_period, 5, 300, 30),
      checkin_enabled: toBool(cfg.checkin_enabled, true),
      checkin_time: cfg.checkin_time || "09:00",
      timezone_offset: toNum(cfg.timezone_offset, 8),
      retry_times: toNum(cfg.retry_times, 3),
      retry_interval_sec: toNum(cfg.retry_interval_sec, 300),
      account_interval_sec: toNum(cfg.account_interval_sec, 10),
      token_cache_min: toNum(cfg.token_cache_min, 0),
      token_exp_margin_min: toNum(cfg.token_exp_margin_min, 10),
      use_komari_notify: toBool(cfg.use_komari_notify, true),
      tg_bot_token_set: !!(cfg.tg_bot_token && cfg.tg_bot_token.length),
      tg_chat_id: cfg.tg_chat_id || "",
      notify_summary: toBool(cfg.notify_summary, true),
      exchange_enabled: toBool(cfg.exchange_enabled, false),
      exchange_poll_sec: clampNum(cfg.exchange_poll_sec, 30, 3600, 60),
      checkin_history_keep: toNum(cfg.checkin_history_keep, 0),
    },
  };
}

// 从请求体提取账号 id（兼容：已解析对象 / JSON 字符串 / form 编码）
function extractBodyId(req) {
  var b = req && req.body;
  if (!b) return "";
  if (typeof b === "object") {
    if (b.id) return String(b.id);
    if (b.account_id) return String(b.account_id);
    return "";
  }
  var s = String(b);
  var t = s.trim();
  if (t.charAt(0) === "{") {
    try {
      var o = JSON.parse(t);
      if (o && typeof o === "object") {
        if (o.id) return String(o.id);
        if (o.account_id) return String(o.account_id);
      }
    } catch (e) {}
  }
  var m = /(?:^|&)id=([^&]+)/.exec(s);
  if (m) return decodeURIComponent(m[1]);
  m = /(?:^|&)account_id=([^&]+)/.exec(s);
  return m ? decodeURIComponent(m[1]) : "";
}

function queryParam(req, name) {
  var url = String((req && req.url) || "");
  var qs = url.indexOf("?") >= 0 ? url.slice(url.indexOf("?") + 1) : "";
  if (!qs) return "";
  var parts = qs.split("&");
  for (var i = 0; i < parts.length; i++) {
    var kv = parts[i].split("=");
    if (kv[0] === name) return decodeURIComponent(kv.slice(1).join("=") || "");
  }
  return "";
}

async function load() {
  S.config = await server.getConfig();
  if (!S.config) S.config = {};
  S.state = loadState();
  if (!Array.isArray(S.state.notifyLog)) S.state.notifyLog = [];
  if (!S.state.accounts || typeof S.state.accounts !== "object") S.state.accounts = {};
  S.notifyLog = S.state.notifyLog.slice(0, clampNum(S.config.notify_log_keep, 1, 500, 30));
  S.deviceCookie = S.state.deviceCookie || "";
  S.lastBatch = S.state.lastBatch || null;
  S.configSig = configSignature(S.config);

  loadAccountsFromConfig();
  if (S.skippedLines > 0) {
    console.log("[acck-checkin] 配置中有 " + S.skippedLines + " 行账号格式无效被跳过（需为 邮箱|密码|TOTP密钥|备注）");
  }

  // 状态接口（全量脱敏）
  server.route("GET", "/acck-checkin/status", function (req, res) {
    if (!isAdmin(req)) return forbid(res);
    sendJson(res, 200, statusPayload());
  });

  // 手动批量签到（全部账号）
  server.route("POST", "/acck-checkin/checkin", function (req, res) {
    if (!isAdmin(req)) return forbid(res);
    if (S.busy) {
      sendJson(res, 409, { status: "busy", message: "已有批量签到在执行中，请等它结束后再试" });
      return;
    }
    if (!S.accounts.length) {
      sendJson(res, 400, { status: "error", message: "未配置任何账号" });
      return;
    }
    sendJson(res, 200, { status: "started", note: "批量签到已在后台启动", accountCount: S.accounts.length });
    runAllAccounts("manual").then(function (r) {
      console.log("[acck-checkin] manual batch done: " + (r && r.items ? r.items.length : 0));
    }).catch(function (e) {
      console.log("[acck-checkin] manual batch error: " + e.message);
    });
  });

  // 手动单账号签到（body {"id":"acc-2"}）
  server.route("POST", "/acck-checkin/checkin-one", function (req, res) {
    if (!isAdmin(req)) return forbid(res);
    var id = extractBodyId(req);
    var acc = findAccount(id);
    if (!acc) {
      sendJson(res, 400, { status: "error", message: "未找到账号 " + id });
      return;
    }
    if (S.busy) {
      sendJson(res, 409, { status: "busy", message: "已有批量签到在执行中，请等它结束后再试" });
      return;
    }
    sendJson(res, 200, { status: "started", note: "该账号签到已启动", id: acc.id });
    attemptCheckinAccount(acc, "manual").then(function (r) {
      console.log("[acck-checkin] manual one(" + acc.emailMasked + ") done: " + (r ? r.kind : "?"));
      // 单账号签到同样汇总一条通知，保持与批量签到一致的推送节奏
      notifySummary([{ acc: acc, result: r || { kind: "fail", message: "未知错误" } }]).catch(function () {});
    }).catch(function (e) {
      console.log("[acck-checkin] manual one error: " + e.message);
    });
  });

  // 测试通知（使用第一个账号的脱敏信息）
  server.route("POST", "/acck-checkin/test-notify", function (req, res) {
    if (!isAdmin(req)) return forbid(res);
    var acc = S.accounts[0] || { emailMasked: "（未配置账号）", name: "" };
    notifyResult(acc, { kind: "ok", message: "这是一条测试通知" }).then(function () {
      sendJson(res, 200, { status: "ok", message: "通知已发送" });
    }).catch(function (e) {
      sendJson(res, 500, { status: "error", message: e.message });
    });
  });

  // 时间与 TOTP 自检：每个账号输出脱敏标识与动态码，便于与验证器 App 比对
  server.route("GET", "/acck-checkin/diag", async function (req, res) {
    if (!isAdmin(req)) return forbid(res);
    var cfg = S.config || {};
    var out = {
      status: "success",
      localUnix: Math.floor(Date.now() / 1000),
      localTime: new Date().toISOString(),
      acckUnix: null,
      acckTime: null,
      offsetSec: null,
      acckReachable: false,
      totpPeriod: clampNum(cfg.totp_period, 5, 300, 30),
      totpExpiresIn: null,
      accounts: [],
      error: null,
    };
    try {
      var r = await acckReq("/api/site/settings");
      out.acckReachable = r.status === 200;
      out.acckUnix = serverNowSec();
      out.acckTime = new Date(out.acckUnix * 1000).toISOString();
      out.offsetSec = Math.round(S.serverTimeOffsetMs / 1000);
    } catch (e) {
      out.error = "ACCK 探测失败: " + e.message;
    }
    var now = out.acckUnix || Math.floor(Date.now() / 1000);
    var period = out.totpPeriod;
    out.totpExpiresIn = core.totpRemainSec(period, now);
    for (var i = 0; i < S.accounts.length; i++) {
      var acc = S.accounts[i];
      var row = { id: acc.id, name: acc.name, emailMasked: acc.emailMasked, hasTotp: acc.hasTotp, totpCurrent: null, totpNext: null };
      if (acc.totpSecret) {
        try {
          var base = { algorithm: cfg.totp_algorithm || "SHA1", digits: cfg.totp_digits, period: period };
          row.totpCurrent = core.generateTotp(acc.totpSecret, {
            algorithm: base.algorithm, digits: base.digits, period: base.period, time: now,
          });
          row.totpNext = core.generateTotp(acc.totpSecret, {
            algorithm: base.algorithm, digits: base.digits, period: base.period, time: now + period,
          });
        } catch (e) {
          row.error = "TOTP 生成失败: " + e.message;
        }
      }
      out.accounts.push(row);
    }
    sendJson(res, 200, out);
  });

  // ---- 交易区监控路由 ----

  // 交易区监控状态（脱敏）
  server.route("GET", "/acck-checkin/exchange", function (req, res) {
    if (!isAdmin(req)) return forbid(res);
    sendJson(res, 200, exchangeStatusPayload());
  });

  // 当前在架列表（供管理页"手动购买"弹窗选择，只读）
  server.route("GET", "/acck-checkin/exchange-list", async function (req, res) {
    if (!isAdmin(req)) return forbid(res);
    try {
      var limit = clampNum(queryParam(req, "limit"), 1, 50, 20);
      var r = await fetchExchangeListings(limit, 0);
      var items = r.items.map(function (l) {
        return {
          id: l.id,
          node: l.nodeName,
          plan: l.planName,
          area: l.areaName,
          priceCents: l.priceCents,
          renewPriceCents: l.renewPriceCents,
          ipStatus: l.ipStatus,
          config: core.formatListingConfig(l),
          bought: hasBought(exchangeState(), l.id),
        };
      });
      sendJson(res, 200, { status: "success", items: items });
    } catch (e) {
      sendJson(res, 500, { status: "error", message: e.message });
    }
  });

  // 立即检查一次交易区（手动触发，忽略启用开关）
  server.route("POST", "/acck-checkin/exchange-check", function (req, res) {
    if (!isAdmin(req)) return forbid(res);
    if (S.exPollBusy) {
      sendJson(res, 200, { status: "busy", message: "检查正在进行中，请稍候" });
      return;
    }
    sendJson(res, 200, { status: "started", message: "交易区检查已启动" });
    runExchangePoll("manual").then(function (r) {
      console.log("[acck-checkin] 手动交易区检查完成: " + JSON.stringify(r));
    }).catch(function (e) {
      console.log("[acck-checkin] 手动交易区检查失败: " + e.message);
    });
  });

  // 手动购买指定上架（body {"id": <listingId>}）
  server.route("POST", "/acck-checkin/exchange-buy", function (req, res) {
    if (!isAdmin(req)) return forbid(res);
    var id = toNum(extractBodyId(req), 0);
    if (!id) {
      sendJson(res, 400, { status: "error", message: "缺少上架 ID" });
      return;
    }
    var ec = exchangeCfg();
    var acc = pickBuyAccount(ec);
    if (!acc) {
      sendJson(res, 400, { status: "error", message: "无可用账号" });
      return;
    }
    // 幂等：已成功购买过的上架不重复下单（避免重复扣费）
    if (hasBought(exchangeState(), id)) {
      sendJson(res, 200, { status: "duplicate", message: "该上架已购买过，已阻止重复下单", id: id });
      return;
    }
    sendJson(res, 200, { status: "started", message: "购买已启动", id: id, account: acc.emailMasked });
    (async function () {
      try {
        var res2 = await fetchExchangeListings(200, 0);
        var target = null;
        for (var i = 0; i < res2.items.length; i++) {
          if (res2.items[i].id === id) { target = res2.items[i]; break; }
        }
        if (!target) {
          await notifyRaw("ACCK 交易区手动购买失败", "未找到上架 ID " + id + "（可能已被购买或下架）");
          return;
        }
        var br = await autoBuyListing(target, acc);
        var es = exchangeState();
        if (br.ok) markBought(es, target.id);
        es.buyLog.unshift({
          at: new Date().toISOString(), id: target.id, node: target.nodeName, plan: target.planName,
          priceCents: target.priceCents, serverId: target.serverId, account: acc.emailMasked,
          ok: br.ok, message: br.message, rule: "", source: "manual",
        });
        if (es.buyLog.length > 50) es.buyLog.length = 50;
        persistCore();
        await notifyRaw(br.ok ? "ACCK 交易区手动购买成功" : "ACCK 交易区手动购买失败",
          formatBuyResultText(target, acc, br.ok, br.message, ""));
      } catch (e) {
        console.log("[acck-checkin] 手动购买失败: " + e.message);
      }
    })();
  });

  // 重建基线（清空已见记录与待购队列，下轮重新建立基线；用于改规则后重新开始）
  server.route("POST", "/acck-checkin/exchange-reset", function (req, res) {
    if (!isAdmin(req)) return forbid(res);
    var es = exchangeState();
    es.seenIds = [];
    es.pendingBuys = [];
    es.baselineDone = false;
    persistCore();
    sendJson(res, 200, { status: "ok", message: "已重建基线：下一轮检查将把当前在架的机器作为基线（不推送历史）" });
    console.log("[acck-checkin] 交易区基线已重建（seenIds/pendingBuys 已清空）");
  });

  // 测试推送：取交易区最新一条上架（优先能被当前规则命中的）发一条测试通知，用于检测通知链路
  server.route("POST", "/acck-checkin/exchange-test-push", function (req, res) {
    if (!isAdmin(req)) return forbid(res);
    if (S.exTestBusy) {
      sendJson(res, 200, { status: "busy", message: "测试推送正在进行中，请稍候" });
      return;
    }
    sendJson(res, 200, { status: "started", message: "测试推送已启动，请查看通知渠道（Komari 站点通知 / 自定义 TG）" });
    (async function () {
      S.exTestBusy = true;
      try {
        var ec = exchangeCfg();
        var listRes = await fetchExchangeListings(20, 0);
        var list = listRes.items || [];
        if (!list.length) {
          await notifyRaw("ACCK 交易区测试推送", "当前交易区没有在架机器，无法测试推送");
          console.log("[acck-checkin] 测试推送：交易区无在架机器");
          return;
        }
        // 测试推送按「推送范围」选样：rules 时优先取命中推送规则的机器（规则来源为推送规则或回退的自动交易规则）
        var ns = notifyRules();
        var chosen = null;
        var hit = null;
        if (ec.notifyScope === "rules" && ns.rules.length) {
          for (var i = 0; i < list.length; i++) {
            var h = core.matchFirstRule(list[i], ns.rules, notifyFallbackCond(), false);
            if (h) { chosen = list[i]; hit = h; break; }
          }
        }
        var note = "";
        if (!chosen) {
          chosen = list[0];
          if (ec.notifyScope === "rules" && ns.rules.length) {
            note = "注意：当前在架机器均未命中" + (ns.source === "notify" ? "推送规则" : "回退的自动交易规则") + "，本次取最新一条仅作通知链路测试（不会触发购买）";
          } else if (ec.notifyScope === "rules" && !ns.rules.length) {
            note = "注意：推送范围为「按规则」，但推送规则与自动交易规则均为空（实际不会推送任何机器）；本次取最新一条仅作通知链路测试";
          } else {
            note = "提示：当前推送范围为「全部新上架」，本次取最新一条仅作通知链路测试";
          }
        }
        await notifyNewListing(chosen, ec, hit ? hit.name : "", { test: true, note: note });
        console.log("[acck-checkin] 测试推送已发送：listing=" + chosen.id + " 规则=" + (hit ? hit.name : "-") + " 来源=" + ns.source);
      } catch (e) {
        console.log("[acck-checkin] 测试推送失败: " + e.message);
        try { await notifyRaw("ACCK 交易区测试推送失败", "测试推送执行失败: " + e.message); } catch (e2) {}
      } finally {
        S.exTestBusy = false;
      }
    })();
  });

  applySchedules();
  applyExchangeSchedule();
  applyTgSchedule();

  console.log(
    "[acck-checkin] loaded " + PLUGIN_VERSION + ", " + S.accounts.length + " 个账号, daily checkin at " +
    (S.config.checkin_time || "09:00") +
    " (UTC" + (toNum(S.config.timezone_offset, 8) > 0 ? "+" : "") + toNum(S.config.timezone_offset, 8) + ")"
  );
}

async function unload() {
  persistCore();
  flushSave();
  console.log("[acck-checkin] unloaded");
}
